# =============================================================================
# banc_elm_pid.py
#
# VERSION
#   1 (4 octobre 2026), ELM-PID sur la base commune v2 (banc commun 2.1).
#
# OBJECTIF
#   Faire tourner l'ELM-PID sur le banc commun, sur les onze essais, a cote
#   des trois references (PID de Ziegler-Nichols, meilleur PID fige, version
#   R0), mesurer ce que chaque piece du regulateur apporte (ablations), et
#   ecrire ce que Simulink doit retrouver :
#     - predictions_banc_elm_pid.json : resultats attendus de l'ELM-PID sur
#       les onze essais, au format des autres fichiers de predictions (lu
#       par Simuler_ELM_PID.m) ;
#     - elm_pid_reglages.mat : les reglages du bloc MATLAB (boite des gains,
#       pas d'adaptation, porte...), lus par elm_pid_adaptatif.m, pour que le
#       bloc et ce banc utilisent les memes nombres ;
#     - reference_rejeu_elm_pid.mat : erreur, mesure, commande et gains pas
#       par pas sur quatre essais, que Tester_ELM_PID_Rejeu.m rejoue dans le
#       bloc MATLAB.
#
# L'ELM-PID, TEL QU'IL EST CODE ICI ET DANS elm_pid_adaptatif.m
#   A chaque periode Tc = 1/220 000 s, le regulateur recoit l'erreur
#   e = consigne - mesure et la mesure de Vout (sortie du capteur, jamais
#   100 - e, regle du protocole).
#   1. Loi PID incrementale de Lu et al. (eq. 13-14), terme derive calcule
#      sur l'erreur filtree (meme filtre que le PID de reference : premier
#      ordre de pole N = 64 122.9 rad/s, Forward Euler) :
#        g(k) = Tc N (e(k) - ef(k)),   ef(k+1) = ef(k) + Tc N (e(k) - ef(k)),
#        u(k) = sat( u(k-1) + Kp (e(k) - e(k-1)) + Ki e(k) + Kd (g(k) - g(k-1)) ),
#      sat = [0.01 ; 0.99], seule saturation du rapport cyclique ; depart
#      u = 0.5, premier pas sans a-coup (e(k-1) = e(0), ef(0) = e(0)).
#   2. Fenetres de 0.5 ms (110 periodes Tc, 11 periodes de decoupage) : on y
#      accumule la mesure moyenne ybar, le rapport cyclique moyen dbar,
#      l'erreur moyenne ebar et la sensibilite moyenne s de u aux trois gains
#      (somme cumulee des increments [e - e1, e, g - g1] depuis le debut de
#      la fenetre). Une fenetre ou la loi a sature est suspecte.
#   3. En fin de fenetre, l'ELM retenu a l'etape 2 (elm_pid_modele.mat)
#      predit ybar(n) a partir de [ybar(n-1), ybar(n-2), dbar(n), dbar(n-1),
#      dbar(n-2)] et donne le jacobien J = d ybar(n) / d dbar(n). Si
#      |ybar - prediction| depasse le seuil, la fenetre est suspecte.
#   4. Porte : seulement si la fenetre et les deux precedentes sont propres,
#      a. mise a jour en ligne des poids de sortie de l'ELM (OS-ELM, moindres
#         carres recursifs, oubli lambda) ;
#      b. si |ebar| depasse la zone morte et si J > 0, gradient normalise
#         (eq. 16 de Lu a l'echelle de la fenetre) sur les gains normalises
#         theta (0 au bord bas de la boite, 1 au bord haut) :
#           phi = J (s .* dK),
#           theta <- theta + eta ebar phi / (eps + phi.phi) + alpha (theta - theta_prec),
#         puis projection sur [0 ; 1] et K = K_min + theta .* dK.
#
# LES REGLAGES (fixes avant les essais de ce script)
#   Boite des gains : boite_gains_elm.json (boite_gains_elm.py) ; depart a
#     Ziegler-Nichols, coin (Kp min, Ki max, Kd min) de la boite.
#   eta = 0.5 : a l'etape 2, le jacobien de l'ELM vaut au pire 0.515 fois le
#     vrai. Avec eta = 1, le pas reel atteindrait presque deux fois le pas
#     voulu, au bord de l'instabilite du gradient normalise (0 < eta < 2) ;
#     avec 0.5, il reste sous le pas voulu.
#   lambda = 1 (pas d'oubli) : a l'etape 2, l'oubli rendait le jacobien
#     negatif sur ELM_V2 et sur les trois enregistrements a 98 ohms.
#   Seuil de la porte 0.5 V, zone morte 0.1 V, alpha = 0.001 (Lu, eq. 16),
#     eps = 1e-3 : valeurs de la version precedente, gardees.
#   Transparence : un essai exploratoire avec une boite provisoire, fait
#   avant d'ecrire ce script, a montre que le seuil de la porte change
#   beaucoup le resultat. La valeur de la version precedente est gardee ;
#   l'essai sans seuil est rapporte comme ablation, et il n'est pas choisi
#   apres coup.
#
# CE QUE LE SCRIPT MESURE (memes grandeurs que Simulink, banc commun 2.1)
#   Pour chaque regulateur et chaque essai : grandeurs de banc_commun.py
#   (depassement, IAE, ecart efficace, evenements et retours, activite de
#   la commande, conduction discontinue, courant de la bobine observe).
#   Cout J du meilleur PID fige (moyenne de 13 rapports au PID de
#   Ziegler-Nichols : IAE de 30 ms a la fin sur S1, S3 a S9, et IAE du
#   demarrage sur S1, S8a, S8b) et contrainte "tous les evenements
#   reviennent dans la bande". Le meilleur PID fige est une reference
#   oracle (gains choisis sur ces essais) ; l'ELM-PID ne l'est pas.
#
# LES ABLATIONS ET LA SENSIBILITE
#   R0 : meme loi, gains de Ziegler-Nichols figes (pas d'adaptation).
#   Jacobien constant : J remplace par le coefficient de dbar(n) de la
#     regression lineaire de l'etape 2 (11.07), lu dans
#     entrainement_elm_resultats.json.
#   Sans OS-ELM ; sans seuil de porte ; sans ELM (jacobien constant et sans
#   seuil : plus rien ne vient du reseau) ; eta = 1 ; lambda = 0.99.
#   Sensibilite : ELM-PID et jacobien constant refaits avec L ou C changes
#   de +-0.1 %. A charge legere, les decisions d'adaptation dependent de
#   seuils (porte, zone morte) franchis a quelques mV pres : cette etape
#   dit quels ecarts de J sont du bruit, et a quoi s'attendre entre
#   Simulink et le banc sur S8a, S8b et S9.
#
# FICHIERS NECESSAIRES (dans le meme dossier que ce script)
#   banc_commun.py (version 2.1), scenarios_communs.json, scenario_S*.mat,
#   predictions_banc_pid_fige.json (gains du meilleur PID fige),
#   elm_pid_modele.mat et entrainement_elm_resultats.json (etape 2),
#   boite_gains_elm.json (boite_gains_elm.py).
#
# CE QUE PRODUIT CE SCRIPT
#   predictions_banc_elm_pid.json, elm_pid_reglages.mat,
#   reference_rejeu_elm_pid.mat, banc_elm_pid_resultats.json,
#   banc_elm_pid.png (tension, gains et courant sur S8b et S9).
#
# BIBLIOTHEQUES NECESSAIRES (pip install numpy scipy matplotlib)
#
# COMMENT LANCER CE SCRIPT
#   python banc_elm_pid.py
#   (ou le notebook banc_elm_pid.ipynb, meme code). Trois minutes environ.
#
# ORDRE D'EXECUTION (etape 3 de l'ELM-PID)
#   1. boite_gains_elm.py ; 2. ce script ; 3. Tester_ELM_PID_Rejeu.m ;
#   4. Construction_ELM_PID.m ; 5. verifier_modele_elm_pid.py ;
#   6. Simuler_ELM_PID.m.
# =============================================================================


# %% ETAPE 0 : bibliotheques, reglages et definitions du banc commun

import os                                     # chemins de fichiers
import json                                   # lecture et ecriture au format texte
import time                                   # duree d'execution
import numpy as np                            # calcul numerique
from scipy.io import loadmat, savemat         # fichiers .mat
import matplotlib.pyplot as plt               # figure

try:                                          # dossier du script (ou dossier courant dans un notebook)
    DOSSIER_ELM = os.path.dirname(os.path.abspath(__file__))
except NameError:
    DOSSIER_ELM = os.getcwd()

with open(os.path.join(DOSSIER_ELM, "banc_commun.py"), encoding="utf-8") as f:
    SOURCE_BANC = f.read()
MARQUE = "# === FIN DES DEFINITIONS DU BANC COMMUN ==="
if MARQUE not in SOURCE_BANC or "iL_max_dem_A" not in SOURCE_BANC:
    raise RuntimeError("banc_commun.py n'est pas la version 2.1 (observation du courant) : prendre la version a jour.")
exec(SOURCE_BANC[:SOURCE_BANC.index(MARQUE)])  # constantes, essais, Circuit, simuler, grandeurs, PIDClassique

T_DEBUT = time.time()                         # pour la duree totale
ESSAIS = {sc["code"]: sc for sc in SCENARIOS}  # les onze essais, par code
CODES_IAE = ["S1", "S3", "S4", "S5", "S6", "S7a", "S7b", "S8a", "S8b", "S9"]   # IAE de 30 ms a la fin
CODES_DEM = ["S1", "S8a", "S8b"]              # IAE du demarrage (5, 25 et 98 ohms)
K30 = int(round(0.03 / TC))                   # instant 30 ms (numero de pas Tc)
NF = 110                                      # periodes Tc par fenetre de 0.5 ms
CODES_REJEU = ["S1", "S7b", "S8b", "S9"]      # essais rejoues dans le bloc MATLAB

# Boite des gains (boite_gains_elm.py)
with open(os.path.join(DOSSIER_ELM, "boite_gains_elm.json"), encoding="utf-8") as f:
    BOITE = json.load(f)
K_MIN = np.array(BOITE["K_min"])              # bord bas [Kp, Ki, Kd]
K_MAX = np.array(BOITE["K_max"])              # bord haut
K_ZN = np.array([PID_P, PID_I * TC, PID_D / TC])   # Ziegler-Nichols, forme incrementale
if np.max(np.abs(np.array(BOITE["K_depart"]) - K_ZN) / K_ZN) > 1e-12:
    raise RuntimeError("boite_gains_elm.json n'a pas ete calcule avec les gains de Ziegler-Nichols de ce banc.")

# Reglages de l'ELM-PID (voir l'en-tete)
REGLAGES = {"ETA": 0.5, "SEUIL_PORTE": 0.5, "ZONE_MORTE": 0.1, "ALPHA": 0.001, "EPS_PHI": 1e-3,
            "LAMBDA": 1.0, "APPRENDRE": 1.0, "JACOBIEN_CONSTANT": float("nan")}

# Jacobien constant de l'ablation : coefficient de dbar(n) de la regression lineaire (etape 2)
with open(os.path.join(DOSSIER_ELM, "entrainement_elm_resultats.json"), encoding="utf-8") as f:
    ETAPE2 = json.load(f)
J_REGRESSION = float(ETAPE2["etape5_evaluations"]["Regression lineaire (5 entrees)"]["controle"]["J_moyen"])

# Meilleur PID fige (deuxieme reference, oracle)
with open(os.path.join(DOSSIER_ELM, "predictions_banc_pid_fige.json"), encoding="utf-8") as f:
    GAINS_FIGE = json.load(f)["gains"]

# Modele ELM de l'etape 2
MODELE = loadmat(os.path.join(DOSSIER_ELM, "elm_pid_modele.mat"))
if int(MODELE["NF"].item()) != NF or abs(float(MODELE["TC"].item()) - TC) > 1e-18:
    raise RuntimeError("elm_pid_modele.mat n'a pas ete appris avec les fenetres de ce banc (NF ou TC differents).")
print(f"Boite : Kp de {K_MIN[0]:.6f} a {K_MAX[0]:.6f}, Ki de {K_MIN[1]:.4e} a {K_MAX[1]:.4e}, "
      f"Kd de {K_MIN[2]:.4f} a {K_MAX[2]:.4f} ; depart a Ziegler-Nichols.")
print(f"ELM : {MODELE['W'].shape[1]} neurones, variante {str(MODELE['VARIANTE'][0])} ; jacobien constant des "
      f"ablations : {J_REGRESSION:.4f}.")


def titre(texte):
    """Bandeau de titre dans la console."""
    print("\n" + "=" * 78 + "\n " + texte + "\n" + "=" * 78)


# %% ETAPE 1 : la loi de Lu (version R0) et l'ELM-PID (copie de elm_pid_adaptatif.m)

TCN = TC * PID_N                              # Tc x N du filtre de derivee (meme produit dans le bloc MATLAB)


class LoiLu:
    """Loi incrementale de Lu a derivee filtree, gains figes (version R0).
    Memes operations, dans le meme ordre, que l'etape 1 de l'ELM-PID."""

    def __init__(self, K):
        self.Kp, self.Ki, self.Kd = (float(x) for x in K)   # gains figes
        self.u = 0.5                          # commande de depart
        self.premier = True                   # premier pas : sans a-coup

    def pas(self, e):
        if self.premier:
            self.e1, self.ef, self.g1, self.premier = e, e, 0.0, False
        g = TCN * (e - self.ef)                           # derivee filtree (x Tc)
        brut = self.u + self.Kp * (e - self.e1) + self.Ki * e + self.Kd * (g - self.g1)
        u = min(max(brut, D_MIN), D_MAX)                  # seule saturation du rapport cyclique
        self.ef = self.ef + TCN * (e - self.ef)           # filtre, Forward Euler
        self.e1, self.g1, self.u = e, g, u
        return u


class ELMPID:
    """Copie Python de elm_pid_adaptatif.m (memes reglages, memes noms,
    meme ordre des operations : Tester_ELM_PID_Rejeu.m compare les deux pas
    par pas). Les arguments servent aux ablations ; leurs valeurs par defaut
    sont celles du bloc (REGLAGES)."""
    utilise_mesure = True                     # le banc commun passe aussi la mesure

    def __init__(self, **modif):
        r = dict(REGLAGES, **modif)           # reglages, eventuellement modifies pour une ablation
        self.eta, self.seuil, self.zm = r["ETA"], r["SEUIL_PORTE"], r["ZONE_MORTE"]
        self.alpha, self.eps, self.lam = r["ALPHA"], r["EPS_PHI"], r["LAMBDA"]
        self.apprendre, self.Jc = bool(r["APPRENDRE"]), r["JACOBIEN_CONSTANT"]
        self.adapter = r.get("ADAPTER", True)  # False : gains figes (controle de l'egalite avec R0)
        # Modele ELM (copies : l'OS-ELM modifie BETA et P)
        self.W = MODELE["W"].astype(float)
        self.B = MODELE["B"].astype(float).ravel()
        self.BETA = MODELE["BETA"].astype(float).ravel().copy()
        self.P = MODELE["P0"].astype(float).copy()
        self.XM = MODELE["X_MOY"].astype(float).ravel()
        self.XE = MODELE["X_EC"].astype(float).ravel()
        self.TM = float(MODELE["T_MOY"].item())
        self.TE_ = float(MODELE["T_EC"].item())
        self.n = self.W.shape[1]
        # Gains : depart a Ziegler-Nichols, exprime dans la boite
        self.dK = K_MAX - K_MIN
        self.theta = np.minimum(np.maximum((K_ZN - K_MIN) / self.dK, 0.0), 1.0)
        self.theta_prec = self.theta.copy()
        self.K = K_MIN + self.theta * self.dK
        # Loi PID
        self.u, self.premier = 0.5, True
        # Fenetre courante
        self.cpt, self.sy, self.sd, self.se, self.hors = 0, 0.0, 0.0, 0.0, False
        self.S1 = self.S2 = self.S3 = 0.0     # sommes cumulees des increments depuis le debut de la fenetre
        self.sS1 = self.sS2 = self.sS3 = 0.0  # sommes de ces sommes (moyenne = sensibilite)
        # Deux fenetres precedentes (suspectes tant qu'elles n'existent pas)
        self.yb1 = self.yb2 = self.db1 = self.db2 = 0.0
        self.sus1 = self.sus2 = True
        self.nfen = 0
        self.journal = []                     # une ligne par fenetre
        self.K_pas = []                       # gains utilises a chaque pas (pour le rejeu et les figures)

    def modele(self, x):
        """Prediction ybar(n), jacobien d ybar(n) / d dbar(n) et vecteur h
        (memes formules que evaluer_modele du bloc MATLAB)."""
        xn = (x - self.XM) / self.XE                      # entrees normalisees
        gg = 1.0 / (1.0 + np.exp(-(xn @ self.W + self.B)))   # neurones (logsig)
        h = np.concatenate([gg, xn, [1.0]])               # neurones, liaisons directes, constante
        y = (h @ self.BETA) * self.TE_ + self.TM
        dy = ((gg * (1.0 - gg)) * self.BETA[:self.n]) @ self.W.T + self.BETA[self.n:self.n + 5]
        return y, dy[2] / self.XE[2] * self.TE_, h

    def pas(self, e, mesure):
        self.K_pas.append(self.K)             # gains utilises pour ce pas
        if self.premier:
            self.e1, self.ef, self.g1, self.premier = e, e, 0.0, False
        g = TCN * (e - self.ef)
        x1, x2, x3 = e - self.e1, e, g - self.g1          # increments de Kp, Ki, Kd
        brut = self.u + self.K[0] * x1 + self.K[1] * x2 + self.K[2] * x3
        u = min(max(brut, D_MIN), D_MAX)
        self.ef = self.ef + TCN * (e - self.ef)
        self.e1, self.g1, self.u = e, g, u
        # Fenetre
        self.S1, self.S2, self.S3 = self.S1 + x1, self.S2 + x2, self.S3 + x3
        self.sS1, self.sS2, self.sS3 = self.sS1 + self.S1, self.sS2 + self.S2, self.sS3 + self.S3
        self.sy, self.sd, self.se = self.sy + mesure, self.sd + u, self.se + e
        if brut < D_MIN or brut > D_MAX:
            self.hors = True                  # la loi a sature : fenetre suspecte
        self.cpt += 1
        if self.cpt >= NF:
            self.fin_de_fenetre()
        return u

    def fin_de_fenetre(self):
        yb, db, eb = self.sy / NF, self.sd / NF, self.se / NF       # moyennes de la fenetre
        s = np.array([self.sS1, self.sS2, self.sS3]) / NF           # sensibilite moyenne de u aux gains
        sus, porte, err, J, adapte = self.hors, False, float("nan"), float("nan"), False
        if self.nfen >= 2:
            x = np.array([self.yb1, self.yb2, db, self.db1, self.db2])
            yhat, J, h = self.modele(x)
            if not np.isnan(self.Jc):
                J = self.Jc                   # ablation : jacobien constant
            err = yb - yhat                   # erreur de prediction (V)
            if abs(err) > self.seuil:
                sus = True
            porte = (not sus) and (not self.sus1) and (not self.sus2)
            if porte:
                if self.apprendre:            # a. OS-ELM
                    Ph = self.P @ h
                    gain = Ph / (self.lam + h @ Ph)
                    self.BETA = self.BETA + gain * (err / self.TE_)
                    self.P = (self.P - np.outer(gain, Ph)) / self.lam
                th_ancien = self.theta.copy()
                if self.adapter and abs(eb) > self.zm and J > 0:   # b. gains
                    phi = J * (s * self.dK)
                    self.theta = (self.theta + self.eta * eb * phi / (self.eps + phi @ phi)
                                  + self.alpha * (self.theta - self.theta_prec))
                    adapte = True
                self.theta = np.minimum(np.maximum(self.theta, 0.0), 1.0)   # projection sur la boite
                self.theta_prec = th_ancien
                self.K = K_MIN + self.theta * self.dK
        self.journal.append({"ybar": yb, "dbar": db, "ebar": eb, "err": err, "J": J, "porte": porte,
                             "adapte": adapte, "K": self.K.copy()})
        self.yb2, self.yb1 = self.yb1, yb
        self.db2, self.db1 = self.db1, db
        self.sus2, self.sus1 = self.sus1, sus
        self.nfen += 1
        self.cpt, self.sy, self.sd, self.se, self.hors = 0, 0.0, 0.0, 0.0, False
        self.S1 = self.S2 = self.S3 = self.sS1 = self.sS2 = self.sS3 = 0.0


# Controle 1 : le modele relu redonne les vecteurs de test de l'etape 2
essai = ELMPID()
ecart_y = max(abs(essai.modele(MODELE["X_TEST"][i].astype(float))[0] - MODELE["Y_TEST"][i, 0])
              for i in range(MODELE["X_TEST"].shape[0]))
ecart_J = max(abs(essai.modele(MODELE["X_TEST"][i].astype(float))[1] - MODELE["J_TEST"][i, 2])
              for i in range(MODELE["X_TEST"].shape[0]))
print(f"Vecteurs de test du modele : ecart {ecart_y:.1e} V sur ybar, {ecart_J:.1e} sur le jacobien.")
if ecart_y > 1e-9 or ecart_J > 1e-9:
    raise RuntimeError("elm_pid_modele.mat ne redonne pas ses vecteurs de test.")


# %% ETAPE 2 : evaluation d'un regulateur sur les onze essais

def evaluer(fabrique, codes=None):
    """Simule un nouveau regulateur (fabrique()) sur chaque essai et renvoie,
    par essai : grandeurs du banc commun, IAE du demarrage, retours, et le
    regulateur (pour son journal)."""
    res = {}
    for code in (codes or list(ESSAIS)):
        reg = fabrique()
        sim = simuler(reg, ESSAIS[code])
        o = grandeurs(sim, ESSAIS[code])
        e = sim["consigne"] - sim["v"]
        res[code] = {"o": o, "IAE_dem": float(np.sum(np.abs(e[:K30])) * TC),
                     "revenus": bool(all(ev["revenu"] for ev in o["evenements"])), "reg": reg, "sim": sim}
    return res


def termes(res):
    """Les 13 termes du cout du meilleur PID fige."""
    return np.array([res[c]["o"]["IAE"] for c in CODES_IAE] + [res[c]["IAE_dem"] for c in CODES_DEM])


class PIDParallele(PIDClassique):
    """PID du bloc Simulink (forme Parallel, clamping) avec d'autres gains P, I, D."""

    def __init__(self, P, I, D):
        super().__init__()
        self.P, self.I, self.D = P, I, D

    def pas(self, e):
        derivee = PID_N * (self.D * e - self.xF)
        u = self.P * e + self.xI + derivee
        u_sat = min(max(u, D_MIN), D_MAX)
        entree_I = self.I * e
        if not ((u != u_sat) and (np.sign(entree_I) == np.sign(u - u_sat))):
            self.xI += TC * entree_I
        self.xF += TC * derivee
        return u_sat


titre("ETAPE 2 : les references")
REF = {}
REF["Ziegler-Nichols"] = evaluer(lambda: PIDClassique())
REF["meilleur PID fige"] = evaluer(lambda: PIDParallele(GAINS_FIGE["P"], GAINS_FIGE["I"], GAINS_FIGE["D"]))
T_ZN = termes(REF["Ziegler-Nichols"])
J_FIGE = float(np.mean(termes(REF["meilleur PID fige"]) / T_ZN))
print(f"  Meilleur PID fige : J = {J_FIGE:.3f} (recherche_pid_fige.py : 0.738).")


# %% ETAPE 3 : version R0 et ELM-PID sur les onze essais

titre("ETAPE 3 : version R0 (gains de Ziegler-Nichols figes) et ELM-PID")


def bilan(nom, res):
    """Cout J, retours et une ligne par essai."""
    J = float(np.mean(termes(res) / T_ZN))
    non = [c for c in CODES_IAE if not res[c]["revenus"]]
    print(f"\n  {nom} : J = {J:.3f} ; {'tous les evenements reviennent' if not non else 'pas revenus : ' + ', '.join(non)}")
    for code, r in res.items():
        o = r["o"]
        ligne = (f"    {code:4s} depassement {o['depassement_pct']:5.1f} %, IAE {o['IAE'] * 1e3:7.2f} mV.s, "
                 f"efficace {o['e_eff_V'] * 1e3:7.1f} mV, |dd| {o['dd_moyen']:.4f}, iL crete {o['iL_max_dem_A']:5.1f} A")
        if hasattr(r["reg"], "journal"):
            jr = r["reg"].journal
            Kf = jr[-1]["K"] / K_ZN
            ligne += (f" ; porte {100 * np.mean([x['porte'] for x in jr]):3.0f} %, gains changes sur "
                      f"{sum(x['adapte'] for x in jr):2d} fenetres, gains finaux x({Kf[0]:.2f}, {Kf[1]:.2f}, {Kf[2]:.2f})")
        print(ligne)
    return J


R0 = evaluer(lambda: LoiLu(K_ZN))
J_R0 = bilan("R0", R0)
ELM = evaluer(lambda: ELMPID())
J_ELM = bilan("ELM-PID", ELM)

# Controle 2 : sans adaptation, l'ELM-PID redonne exactement R0
fige = evaluer(lambda: ELMPID(ADAPTER=False), ["S1", "S8b"])
ecart_r0 = max(float(np.max(np.abs(fige[c]["sim"]["d"] - R0[c]["sim"]["d"]))) for c in fige)
print(f"\n  Controle : ELM-PID sans adaptation contre R0, ecart maximal sur d : {ecart_r0:.1e}.")
if ecart_r0 > 1e-12:
    raise RuntimeError("Sans adaptation, l'ELM-PID ne redonne pas la loi R0.")

print("\n  Evenements de l'ELM-PID sur S8b et S9 :")
for code in ("S8b", "S9"):
    for ev in ELM[code]["o"]["evenements"]:
        etat = ("reste dans la bande" if ev["reste_dans_bande"] else
                f"retour en {ev['t_retour_ms']:.2f} ms" if ev["revenu"] else "PAS REVENU")
        print(f"    {code} a {ev['t_ms']:6.1f} ms : IAE {ev['IAE'] * 1e3:7.2f} mV.s, ecart max {ev['e_max_V']:6.2f} V, "
              f"crete a crete en fin {ev['e_crete_a_crete_fin_V']:5.2f} V, {etat}")


# %% ETAPE 4 : ablations

titre("ETAPE 4 : ce que chaque piece apporte (ablations)")
ABLATIONS = {"Jacobien constant": {"JACOBIEN_CONSTANT": J_REGRESSION},
             "Sans OS-ELM": {"APPRENDRE": 0.0},
             "Sans seuil de porte": {"SEUIL_PORTE": float("inf")},
             "Sans ELM (J constant, sans seuil)": {"JACOBIEN_CONSTANT": J_REGRESSION, "SEUIL_PORTE": float("inf")},
             "eta = 1": {"ETA": 1.0},
             "lambda = 0.99": {"LAMBDA": 0.99}}
RES_ABL, J_ABL = {}, {}
for nom, modif in ABLATIONS.items():
    RES_ABL[nom] = evaluer(lambda: ELMPID(**modif))
    J_ABL[nom] = float(np.mean(termes(RES_ABL[nom]) / T_ZN))
print(f"\n  {'variante':36s} {'J':>6s}  {'non revenus':12s} {'S8a':>7s} {'S8b':>7s} {'S9':>8s} {'S7b eff':>8s} "
      f"{'gains changes':>13s}")
for nom, res, J in ([("ELM-PID (reglages fixes)", ELM, J_ELM), ("R0", R0, J_R0)]
                    + [(n, RES_ABL[n], J_ABL[n]) for n in ABLATIONS]):
    non = [c for c in CODES_IAE if not res[c]["revenus"]]
    nb = sum(sum(x["adapte"] for x in res[c]["reg"].journal) for c in res) if hasattr(res["S1"]["reg"], "journal") else 0
    print(f"  {nom:36s} {J:6.3f}  {(','.join(non) or '-'):12s} {res['S8a']['o']['IAE'] * 1e3:7.2f} "
          f"{res['S8b']['o']['IAE'] * 1e3:7.2f} {res['S9']['o']['IAE'] * 1e3:8.2f} {res['S7b']['o']['e_eff_V'] * 1e3:8.1f} "
          f"{nb:13d}")
print("  (IAE de 30 ms a la fin en mV.s ; ecart efficace en mV ; gains changes : total des fenetres sur les onze essais)")


# %% ETAPE 4b : sensibilite a de tres petits ecarts du circuit

titre("ETAPE 4b : sensibilite a de tres petits ecarts du circuit (L ou C a +-0.1 %)")
L_NOM, C_NOM = L_BOB, C_CONV                  # valeurs nominales, retablies a la fin
SENSIBILITE = []
print(f"  {'circuit':12s} {'J ELM-PID':>9s} {'J J const.':>10s} {'S8a : fenetres adaptees':>24s} "
      f"{'S8b : Kp final':>15s} {'S8b IAE':>8s} {'tous revenus':>13s}")
for nom_p, fl, fc in (("nominal", 1.0, 1.0), ("L - 0.1 %", 0.999, 1.0), ("L + 0.1 %", 1.001, 1.0),
                      ("C - 0.1 %", 1.0, 0.999), ("C + 0.1 %", 1.0, 1.001)):
    L_BOB, C_CONV = L_NOM * fl, C_NOM * fc   # le banc lit ces constantes a chaque nouveau circuit
    if nom_p == "nominal":
        r_e, r_c = ELM, RES_ABL["Jacobien constant"]
    else:
        r_e = evaluer(lambda: ELMPID())
        r_c = evaluer(lambda: ELMPID(JACOBIEN_CONSTANT=J_REGRESSION))
    J_e, J_c = float(np.mean(termes(r_e) / T_ZN)), float(np.mean(termes(r_c) / T_ZN))
    fen = [i for i, x in enumerate(r_e["S8a"]["reg"].journal) if x["adapte"]]
    kp = r_e["S8b"]["reg"].journal[-1]["K"][0] / K_ZN[0]
    rev = all(r_e[c]["revenus"] for c in CODES_IAE)
    SENSIBILITE.append({"circuit": nom_p, "J_elm": J_e, "J_constant": J_c, "S8a_fenetres_adaptees": fen,
                        "S8b_Kp_final_sur_ZN": float(kp), "S8b_IAE": r_e["S8b"]["o"]["IAE"], "tous_revenus": rev})
    print(f"  {nom_p:12s} {J_e:9.3f} {J_c:10.3f} {str(fen):>24s} {kp:15.3f} {r_e['S8b']['o']['IAE'] * 1e3:8.2f} "
          f"{'oui' if rev else 'NON':>13s}")
L_BOB, C_CONV = L_NOM, C_NOM                  # circuit nominal retabli
J_E_SENS = [x["J_elm"] for x in SENSIBILITE]
J_C_SENS = [x["J_constant"] for x in SENSIBILITE]
print(f"\n  J de l'ELM-PID entre {min(J_E_SENS):.3f} et {max(J_E_SENS):.3f} ; avec le jacobien constant, entre "
      f"{min(J_C_SENS):.3f} et {max(J_C_SENS):.3f}.")
print("  Lecture : un ecart de 0.1 % sur L ou C, invisible en nominal, fait apparaitre ou disparaitre une")
print("  adaptation a charge legere et change le gain final et l'IAE de S8a et S8b. Les ecarts de J de l'ordre")
print("  de 0.01 entre variantes ne sont donc pas significatifs. Entre Simulink et le banc, on attend la meme")
print("  chose : S1 a S7b se comparent point par point ; S8a, S8b et S9 se lisent comme une sensibilite.")


# %% ETAPE 5 : comparaison avec les references

titre("ETAPE 5 : ELM-PID face aux references")
TOUS = {"Ziegler-Nichols": REF["Ziegler-Nichols"], "meilleur PID fige": REF["meilleur PID fige"], "R0": R0,
        "ELM-PID": ELM}
J_TOUS = {nom: float(np.mean(termes(res) / T_ZN)) for nom, res in TOUS.items()}
print("  " + " " * 28 + "".join(f"{nom:>20s}" for nom in TOUS))
print("  " + f"{'cout J':28s}" + "".join(f"{J_TOUS[n]:20.3f}" for n in TOUS))
print("  " + f"{'evenements non revenus':28s}" + "".join(
    f"{(','.join(c for c in CODES_IAE if not TOUS[n][c]['revenus']) or '-'):>20s}" for n in TOUS))
for code in ESSAIS:
    for cle, etiquette, fmt, k in (("depassement_pct", "depassement %", "{:.1f}", 1.0), ("IAE", "IAE mV.s", "{:.2f}", 1e3),
                                   ("e_eff_V", "ecart efficace mV", "{:.1f}", 1e3), ("iL_max_dem_A", "iL crete dem. A", "{:.1f}", 1.0)):
        if cle == "depassement_pct" and code not in ("S1", "S8a", "S8b"):
            continue
        if cle == "iL_max_dem_A" and code not in ("S1", "S8b"):
            continue
        print("  " + f"{code + ' ' + etiquette:28s}" + "".join(f"{fmt.format(TOUS[n][code]['o'][cle] * k):>20s}" for n in TOUS))
print("  " + f"{'activite |dd| (S1)':28s}" + "".join(f"{TOUS[n]['S1']['o']['dd_moyen']:20.4f}" for n in TOUS))
print("\n  Lecture :")
print("  - En nominal, l'ELM-PID ne change pas ses gains (porte fermee ou erreur dans la zone morte) et se comporte")
print("    comme R0. A charge legere, il augmente Kp ; c'est ce qui ramene S8b et S9 dans la bande.")
print("  - Ce gain sur R0 vient de la loi d'adaptation et de la boite, pas de l'ELM : avec un jacobien constant,")
print(f"    J vaut {J_ABL['Jacobien constant']:.3f} (ecart dans le bruit de l'etape 4b), sans OS-ELM "
      f"{J_ABL['Sans OS-ELM']:.3f}.")
print("    La seule action mesurable de l'ELM passe par la porte (erreur de prediction), qui bloque la plupart")
print(f"    des adaptations : sans seuil, J = {J_ABL['Sans seuil de porte']:.3f} ; sans rien du reseau, "
      f"J = {J_ABL['Sans ELM (J constant, sans seuil)']:.3f},")
print(f"    autant que le meilleur PID fige ({J_FIGE:.3f}), reference oracle. Ces variantes sont des ablations,")
print("    pas des reglages choisis : les choisir maintenant serait regler le regulateur sur les essais.")
print("  - Au demarrage, R0 et l'ELM-PID depassent moins que Ziegler-Nichols pour deux raisons : a 5 ohms surtout,")
print("    le bloc Simulink part avec un a-coup de ses conditions initiales (u colle a 0.01, puis l'integrateur")
print("    s'emballe) ; a charge legere surtout, la forme incrementale sort plus tot de la saturation.")
print("  Sur S2 (F1 a la consigne), la forme incrementale saturee ecrete l'a-coup derive a la montee et pas a la")
print(f"  descente : ecart maximal {ELM['S2']['o']['e_max_V']:.2f} V contre "
      f"{REF['Ziegler-Nichols']['S2']['o']['e_max_V']:.2f} V pour Ziegler-Nichols.")


# %% ETAPE 6 : fichiers pour Simulink et MATLAB, resultats et figure

titre("ETAPE 6 : fichiers pour Simulink et MATLAB")
pas_1ms = int(round(1e-3 / TC))               # 220 periodes Tc
# 1. Resultats attendus de l'ELM-PID (format des autres fichiers de predictions)
predictions = {"version": 2, "Te": TC,
               "regulateur": "ELM-PID (loi de Lu a derivee filtree, ELM de l'etape 2, boite boite_gains_elm.json)",
               "reglages": {k: (None if (isinstance(v, float) and np.isnan(v)) else v) for k, v in REGLAGES.items()},
               "boite": {"K_min": K_MIN.tolist(), "K_max": K_MAX.tolist(), "K_depart": K_ZN.tolist()},
               "controle": {"ecart_vecteurs_test_V": ecart_y, "ecart_sans_adaptation_R0": ecart_r0},
               "essais": {}}
for code, r in ELM.items():
    Kp = np.array(r["reg"].K_pas)             # gains utilises a chaque pas
    predictions["essais"][code] = {"grandeurs": r["o"],
                                   "v_toutes_les_ms": r["sim"]["v"][::pas_1ms].tolist(),
                                   "iL_toutes_les_ms": r["sim"]["iL"][::pas_1ms].tolist(),
                                   "d_moyen_par_ms": [float(np.mean(r["sim"]["d"][i:i + pas_1ms]))
                                                      for i in range(0, len(r["sim"]["d"]) - pas_1ms + 1, pas_1ms)],
                                   "K_toutes_les_ms": Kp[::pas_1ms].tolist()}
with open(os.path.join(DOSSIER_ELM, "predictions_banc_elm_pid.json"), "w", encoding="utf-8") as f:
    json.dump(predictions, f, indent=1, allow_nan=False)
print("  predictions_banc_elm_pid.json ecrit.")

# 2. Reglages du bloc MATLAB
savemat(os.path.join(DOSSIER_ELM, "elm_pid_reglages.mat"),
        {"K_MIN": K_MIN.reshape(1, 3), "K_MAX": K_MAX.reshape(1, 3), "K_DEPART": K_ZN.reshape(1, 3),
         "ETA": REGLAGES["ETA"], "SEUIL_PORTE": REGLAGES["SEUIL_PORTE"], "ZONE_MORTE": REGLAGES["ZONE_MORTE"],
         "ALPHA": REGLAGES["ALPHA"], "EPS_PHI": REGLAGES["EPS_PHI"], "LAMBDA": REGLAGES["LAMBDA"],
         "APPRENDRE": REGLAGES["APPRENDRE"], "JACOBIEN_CONSTANT": REGLAGES["JACOBIEN_CONSTANT"],
         "NF": float(NF), "TC": TC, "N_FILTRE": PID_N, "D_MIN": D_MIN, "D_MAX": D_MAX, "U_DEPART": 0.5,
         "VERSION": 1.0})
print("  elm_pid_reglages.mat ecrit (reglages du bloc).")

# 3. Reference du test de rejeu MATLAB
rejeu = {}
for code in CODES_REJEU:
    r = ELM[code]
    jr = r["reg"].journal
    rejeu[code] = {"e": (r["sim"]["consigne"] - r["sim"]["mesure"]).reshape(-1, 1),
                   "mesure": r["sim"]["mesure"].reshape(-1, 1), "u": r["sim"]["d"].reshape(-1, 1),
                   "K": np.array(r["reg"].K_pas), "porte": np.array([x["porte"] for x in jr], float).reshape(-1, 1),
                   "adapte": np.array([x["adapte"] for x in jr], float).reshape(-1, 1)}
savemat(os.path.join(DOSSIER_ELM, "reference_rejeu_elm_pid.mat"), rejeu, do_compression=True)
print(f"  reference_rejeu_elm_pid.mat ecrit ({', '.join(CODES_REJEU)}).")

# 4. Resultats pour le memoire
def resume_essais(res):
    return {c: {"grandeurs": res[c]["o"], "IAE_dem": res[c]["IAE_dem"], "revenus": res[c]["revenus"]} for c in res}


sortie = {"version": 1, "reglages": predictions["reglages"], "boite": predictions["boite"],
          "J": J_TOUS, "J_ablations": J_ABL, "J_regression": J_REGRESSION, "sensibilite": SENSIBILITE,
          "references": {n: resume_essais(TOUS[n]) for n in TOUS},
          "ablations": {n: resume_essais(RES_ABL[n]) for n in RES_ABL},
          "gains_elm": {c: [x["K"].tolist() for x in ELM[c]["reg"].journal] for c in ELM},
          "porte_elm": {c: float(np.mean([x["porte"] for x in ELM[c]["reg"].journal])) for c in ELM},
          "duree_s": round(time.time() - T_DEBUT, 1)}
with open(os.path.join(DOSSIER_ELM, "banc_elm_pid_resultats.json"), "w", encoding="utf-8") as f:
    json.dump(sortie, f, indent=1, allow_nan=False, default=lambda x: None)
print("  banc_elm_pid_resultats.json ecrit.")

# 5. Figure : tension, gains et courant sur S8b et S9
fig, axes = plt.subplots(3, 2, figsize=(13, 9), sharex="col")
for col, code in enumerate(("S8b", "S9")):
    for nom, couleur in (("Ziegler-Nichols", "0.6"), ("R0", "tab:orange"), ("meilleur PID fige", "tab:green"),
                         ("ELM-PID", "tab:blue")):
        sim = TOUS[nom][code]["sim"]
        axes[0, col].plot(sim["t"] * 1e3, sim["v"], lw=0.6, color=couleur, label=nom)
        axes[2, col].plot(sim["t"] * 1e3, sim["iL"], lw=0.4, color=couleur)
    axes[0, col].plot(sim["t"] * 1e3, sim["consigne"], "k--", lw=0.6)
    Kp = np.array(ELM[code]["reg"].K_pas) / K_ZN
    t_ms = ELM[code]["sim"]["t"] * 1e3
    for i, nom in enumerate(("Kp", "Ki", "Kd")):
        axes[1, col].plot(t_ms, Kp[:, i], lw=1.0, label=nom)
    axes[0, col].set_ylim(30, 200)
    axes[0, col].set_title(f"{code} : tension de sortie", fontsize=9, loc="left")
    axes[1, col].set_title(f"{code} : gains de l'ELM-PID (multiples de Ziegler-Nichols)", fontsize=9, loc="left")
    axes[2, col].set_title(f"{code} : courant de la bobine (observe)", fontsize=9, loc="left")
    axes[2, col].set_xlabel("temps (ms)")
    for ax in axes[:, col]:
        ax.grid(alpha=0.3)
axes[0, 0].legend(fontsize=7)
axes[1, 0].legend(fontsize=7)
axes[0, 0].set_ylabel("V")
axes[2, 0].set_ylabel("A")
fig.tight_layout()
fig.savefig(os.path.join(DOSSIER_ELM, "banc_elm_pid.png"), dpi=110)
plt.close(fig)
print(f"  banc_elm_pid.png ecrit. Duree totale : {time.time() - T_DEBUT:.0f} s.")
