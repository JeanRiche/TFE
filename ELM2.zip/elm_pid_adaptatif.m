classdef elm_pid_adaptatif < matlab.System
    %% ELM_PID_ADAPTATIF -- bloc MATLAB System de l'ELM-PID (base commune v2)
    %
    % VERSION
    % -------
    % 2 (4 octobre 2026) : base commune v2 (L = 10 mH, C = 47 uF, 22 kHz,
    % regulateur a Tc = 1/(22000*10) s), loi de Lu a derivee filtree, boite
    % des gains de boite_gains_elm.py, ELM de l'etape 2 (entrainement_elm.py).
    % Remplace la version 1 du 2 octobre 2026 (ancien circuit).
    %
    % CE QUE FAIT CE BLOC
    % -------------------
    % Regulateur PID incremental (loi de Lu et al., eq. 13-14, terme derive
    % sur l'erreur filtree) dont les gains Kp, Ki, Kd sont ajustes toutes les
    % 0.5 ms par un gradient normalise. Le sens et l'amplitude de chaque
    % ajustement viennent du jacobien d'un modele ELM du convertisseur,
    % lui-meme mis a jour en ligne (OS-ELM). C'est la copie exacte de la
    % classe ELMPID de banc_elm_pid.py : memes reglages, memes noms, meme
    % ordre des operations. Tester_ELM_PID_Rejeu.m verifie que les deux
    % donnent la meme commande et les memes gains pas par pas.
    %
    % ENTREES ET SORTIES (une fois par periode Tc, imposee par deux
    % Zero-Order Hold a 1/(22000*10) s places devant le bloc)
    %   entree 1 : e      = consigne - mesure (sortie de Sum1)
    %   entree 2 : mesure = tension mesuree (sortie de "Quantification
    %              Mesure") : le regulateur lit le capteur, jamais 100 - e
    %   sortie 1 : u      = rapport cyclique, deja borne a [0.01 ; 0.99]
    %              (seule saturation du rapport cyclique), vers le PWM
    %   sortie 2 : K      = gains [Kp Ki Kd] utilises pour ce pas (1 x 3),
    %              enregistres par Simuler_ELM_PID.m
    %
    % L'ALGORITHME, A CHAQUE PERIODE Tc
    % ---------------------------------
    % 1. g(k) = Tc N (e(k) - ef(k)) ; ef(k+1) = ef(k) + Tc N (e(k) - ef(k)) ;
    %    u(k) = sat( u(k-1) + Kp (e(k) - e(k-1)) + Ki e(k) + Kd (g(k) - g(k-1)) ),
    %    depart u = 0.5, premier pas sans a-coup (e(k-1) = e(0), ef = e(0)).
    % 2. Sur chaque fenetre de 110 periodes (0.5 ms) : moyennes de la mesure
    %    (ybar), du rapport cyclique (dbar) et de l'erreur (ebar), et
    %    sensibilite moyenne s de u aux trois gains. Une saturation de la loi
    %    rend la fenetre suspecte.
    % 3. Fin de fenetre : l'ELM predit ybar(n) depuis [ybar(n-1) ybar(n-2)
    %    dbar(n) dbar(n-1) dbar(n-2)] et donne J = d ybar(n) / d dbar(n).
    %    Ecart de prediction au-dela de SEUIL_PORTE : fenetre suspecte.
    % 4. Si la fenetre et les deux precedentes sont propres (porte) :
    %    a. OS-ELM (moindres carres recursifs, oubli LAMBDA) si APPRENDRE ;
    %    b. si |ebar| > ZONE_MORTE et J > 0 :
    %       phi = J (s .* dK) ;
    %       theta = theta + ETA ebar phi / (EPS_PHI + phi phi')
    %                     + ALPHA (theta - theta_prec) ;
    %       projection de theta sur [0 ; 1] ; K = K_MIN + theta .* dK.
    %
    % FICHIERS LUS (dans le dossier courant, un seul exemplaire)
    %   elm_pid_modele.mat   : modele ELM (entrainement_elm.py)
    %   elm_pid_reglages.mat : boite des gains, gains de depart, ETA,
    %                          SEUIL_PORTE, ZONE_MORTE, ALPHA, EPS_PHI, LAMBDA,
    %                          APPRENDRE, JACOBIEN_CONSTANT (NaN : celui de
    %                          l'ELM), NF, TC, N_FILTRE, D_MIN, D_MAX,
    %                          U_DEPART (banc_elm_pid.py)
    % Aucun nombre de l'algorithme n'est ecrit dans ce fichier : tout vient
    % de ces deux fichiers, pour que le bloc et le banc ne puissent pas
    % diverger.
    %
    % Utilise dans Simulink en execution interpretee (Construction_ELM_PID.m).
    % Compatible MATLAB R2024a.

    properties (Nontunable)
        FichierModele = 'elm_pid_modele.mat';      % modele ELM
        FichierReglages = 'elm_pid_reglages.mat';  % reglages du bloc
        AfficherBilan (1,1) logical = true;        % une ligne de bilan a la fin de chaque simulation
    end

    properties (Access = private)
        % Modele ELM (charge une fois ; BETA et P sont modifies par l'OS-ELM)
        W; B; BETA0; P0; XM; XE; TM; TE_; n
        BETA; P
        % Reglages
        KMIN; KMAX; dK; K0; ETA; SEUIL; ZM; ALPHA; EPS; LAMBDA; APPRENDRE; JC
        NF; TCN; DMIN; DMAX; U0
        % Etat de la loi PID
        K; theta; theta_prec; u; e1; ef; g1; premier
        % Fenetre courante
        cpt; sy; sd; se; hors; S; sS
        % Deux fenetres precedentes
        yb1; yb2; db1; db2; sus1; sus2; nfen
        % Diagnostic
        der_porte; der_adapte; nb_portes; nb_adapt
    end

    methods
        function obj = elm_pid_adaptatif(varargin)
            setProperties(obj, nargin, varargin{:});
        end

        function info = lire_fenetre(obj)
            % Etat de la derniere fenetre terminee (pour le test de rejeu).
            info = struct('nfen', obj.nfen, 'porte', obj.der_porte, 'adapte', obj.der_adapte);
        end
    end

    methods (Access = protected)

        function setupImpl(obj)
            m = elm_pid_adaptatif.charger(obj.FichierModele);
            r = elm_pid_adaptatif.charger(obj.FichierReglages);
            obj.W = double(m.W);                      % 5 x n
            obj.B = double(m.B(:)');                  % 1 x n
            obj.BETA0 = double(m.BETA(:));            % (n+6) x 1
            obj.P0 = double(m.P0);                    % (n+6) x (n+6)
            obj.XM = double(m.X_MOY(:)');             % 1 x 5
            obj.XE = double(m.X_EC(:)');              % 1 x 5
            obj.TM = double(m.T_MOY);
            obj.TE_ = double(m.T_EC);
            obj.n = size(obj.W, 2);
            if size(obj.W, 1) ~= 5 || numel(obj.BETA0) ~= obj.n + 6 || ~isequal(size(obj.P0), [obj.n + 6, obj.n + 6])
                error('elm_pid_adaptatif : tailles inattendues dans %s.', obj.FichierModele);
            end
            obj.KMIN = double(r.K_MIN(:)');           % 1 x 3
            obj.KMAX = double(r.K_MAX(:)');
            obj.dK = obj.KMAX - obj.KMIN;
            obj.K0 = double(r.K_DEPART(:)');
            obj.ETA = double(r.ETA);
            obj.SEUIL = double(r.SEUIL_PORTE);
            obj.ZM = double(r.ZONE_MORTE);
            obj.ALPHA = double(r.ALPHA);
            obj.EPS = double(r.EPS_PHI);
            obj.LAMBDA = double(r.LAMBDA);
            obj.APPRENDRE = double(r.APPRENDRE) ~= 0;
            obj.JC = double(r.JACOBIEN_CONSTANT);
            obj.NF = double(r.NF);
            obj.TCN = double(r.TC) * double(r.N_FILTRE);   % meme produit que TCN dans le banc
            obj.DMIN = double(r.D_MIN);
            obj.DMAX = double(r.D_MAX);
            obj.U0 = double(r.U_DEPART);
            if isfield(m, 'NF') && (double(m.NF) ~= obj.NF || abs(double(m.TC) - double(r.TC)) > 1e-18)
                error('elm_pid_adaptatif : %s et %s n''ont pas les memes fenetres (NF ou TC).', ...
                      obj.FichierModele, obj.FichierReglages);
            end
        end

        function resetImpl(obj)
            obj.BETA = obj.BETA0;
            obj.P = obj.P0;
            obj.theta = min(max((obj.K0 - obj.KMIN) ./ obj.dK, 0), 1);   % depart dans la boite
            obj.theta_prec = obj.theta;
            obj.K = obj.KMIN + obj.theta .* obj.dK;
            obj.u = obj.U0;
            obj.e1 = 0; obj.ef = 0; obj.g1 = 0;
            obj.premier = true;
            obj.cpt = 0; obj.sy = 0; obj.sd = 0; obj.se = 0; obj.hors = false;
            obj.S = [0 0 0]; obj.sS = [0 0 0];
            obj.yb1 = 0; obj.yb2 = 0; obj.db1 = 0; obj.db2 = 0;
            obj.sus1 = true; obj.sus2 = true;
            obj.nfen = 0;
            obj.der_porte = false; obj.der_adapte = false; obj.nb_portes = 0; obj.nb_adapt = 0;
        end

        function [u, Kout] = stepImpl(obj, e, mesure)
            Kout = obj.K;                             % gains utilises pour ce pas
            if obj.premier
                obj.e1 = e; obj.ef = e; obj.g1 = 0;   % premier pas sans a-coup
                obj.premier = false;
            end
            g = obj.TCN * (e - obj.ef);               % derivee filtree (x Tc)
            x1 = e - obj.e1;                          % increment de Kp
            x2 = e;                                   % increment de Ki
            x3 = g - obj.g1;                          % increment de Kd
            brut = obj.u + obj.K(1) * x1 + obj.K(2) * x2 + obj.K(3) * x3;
            u = min(max(brut, obj.DMIN), obj.DMAX);   % seule saturation du rapport cyclique
            obj.ef = obj.ef + obj.TCN * (e - obj.ef); % filtre, Forward Euler
            obj.e1 = e; obj.g1 = g; obj.u = u;
            % Fenetre
            obj.S = obj.S + [x1, x2, x3];
            obj.sS = obj.sS + obj.S;
            obj.sy = obj.sy + mesure;
            obj.sd = obj.sd + u;
            obj.se = obj.se + e;
            if brut < obj.DMIN || brut > obj.DMAX
                obj.hors = true;                      % la loi a sature : fenetre suspecte
            end
            obj.cpt = obj.cpt + 1;
            if obj.cpt >= obj.NF
                fin_de_fenetre(obj);
            end
        end

        function releaseImpl(obj)
            if obj.AfficherBilan && ~isempty(obj.nfen) && obj.nfen > 0
                fprintf(['  ELM-PID : %d fenetres, porte ouverte sur %d, gains changes sur %d ; ' ...
                         'gains finaux Kp=%.5f Ki=%.4e Kd=%.4f\n'], obj.nfen, obj.nb_portes, obj.nb_adapt, ...
                        obj.K(1), obj.K(2), obj.K(3));
            end
        end

        function n = getNumInputsImpl(~)
            n = 2;
        end
        function n = getNumOutputsImpl(~)
            n = 2;
        end
        function [n1, n2] = getInputNamesImpl(~)
            n1 = 'e';
            n2 = 'mesure';
        end
        function [n1, n2] = getOutputNamesImpl(~)
            n1 = 'u';
            n2 = 'K';
        end
        function [s1, s2] = getOutputSizeImpl(~)
            s1 = [1 1];
            s2 = [1 3];
        end
        function [d1, d2] = getOutputDataTypeImpl(~)
            d1 = 'double';
            d2 = 'double';
        end
        function [c1, c2] = isOutputComplexImpl(~)
            c1 = false;
            c2 = false;
        end
        function [f1, f2] = isOutputFixedSizeImpl(~)
            f1 = true;
            f2 = true;
        end
    end

    methods (Access = private)

        function fin_de_fenetre(obj)
            yb = obj.sy / obj.NF;                     % mesure moyenne de la fenetre
            db = obj.sd / obj.NF;                     % rapport cyclique moyen
            eb = obj.se / obj.NF;                     % erreur moyenne
            s = obj.sS / obj.NF;                      % sensibilite moyenne de u aux gains (1 x 3)
            sus = obj.hors;
            porte = false;
            adapte = false;
            if obj.nfen >= 2
                x = [obj.yb1, obj.yb2, db, obj.db1, obj.db2];
                [yhat, J, h] = elm_pid_adaptatif.evaluer_modele(obj.W, obj.B, obj.BETA, ...
                    obj.XM, obj.XE, obj.TM, obj.TE_, x);
                if ~isnan(obj.JC)
                    J = obj.JC;                       % ablation : jacobien constant
                end
                err = yb - yhat;                      % erreur de prediction (V)
                if abs(err) > obj.SEUIL
                    sus = true;
                end
                porte = ~sus && ~obj.sus1 && ~obj.sus2;
                if porte
                    if obj.APPRENDRE                  % a. OS-ELM
                        hc = h';                      % (n+6) x 1
                        Ph = obj.P * hc;
                        gain = Ph / (obj.LAMBDA + hc' * Ph);
                        obj.BETA = obj.BETA + gain * (err / obj.TE_);
                        obj.P = (obj.P - gain * Ph') / obj.LAMBDA;
                    end
                    th_ancien = obj.theta;
                    if abs(eb) > obj.ZM && J > 0       % b. gains
                        phi = J * (s .* obj.dK);
                        obj.theta = obj.theta + obj.ETA * eb * phi / (obj.EPS + phi * phi') ...
                                    + obj.ALPHA * (obj.theta - obj.theta_prec);
                        adapte = true;
                        obj.nb_adapt = obj.nb_adapt + 1;
                    end
                    obj.theta = min(max(obj.theta, 0), 1);   % projection sur la boite
                    obj.theta_prec = th_ancien;
                    obj.K = obj.KMIN + obj.theta .* obj.dK;
                    obj.nb_portes = obj.nb_portes + 1;
                end
            end
            obj.der_porte = porte;
            obj.der_adapte = adapte;
            obj.yb2 = obj.yb1; obj.yb1 = yb;
            obj.db2 = obj.db1; obj.db1 = db;
            obj.sus2 = obj.sus1; obj.sus1 = sus;
            obj.nfen = obj.nfen + 1;
            obj.cpt = 0; obj.sy = 0; obj.sd = 0; obj.se = 0; obj.hors = false;
            obj.S = [0 0 0]; obj.sS = [0 0 0];
        end
    end

    methods (Static)

        function [y, J, h] = evaluer_modele(W, B, BETA, XM, XE, TM, TE_, x)
            % Prediction ybar(n), jacobien d ybar(n) / d dbar(n) et vecteur h
            % (memes formules que ELMPID.modele dans banc_elm_pid.py).
            n = size(W, 2);
            xn = (x - XM) ./ XE;                      % entrees normalisees (1 x 5)
            g = 1 ./ (1 + exp(-(xn * W + B)));        % neurones logsig (1 x n)
            h = [g, xn, 1];                           % neurones, liaisons directes, constante
            y = (h * BETA) * TE_ + TM;                % volts
            dy = ((g .* (1 - g)) .* BETA(1:n)') * W' + BETA(n+1:n+5)';
            J = dy(3) / XE(3) * TE_;
        end
    end

    methods (Static, Access = private)
        function s = charger(nom)
            % Charge un fichier .mat du dossier courant, avec un message clair s'il manque.
            if exist(nom, 'file') ~= 2
                error('elm_pid_adaptatif : %s introuvable (il doit etre dans le dossier du modele).', nom);
            end
            s = load(nom);
        end
    end
end
