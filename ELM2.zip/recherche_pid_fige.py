# =============================================================================
# recherche_pid_fige.py
#
# VERSION
#   1.1 (4 octobre 2026) : le fichier de predictions contient aussi le
#   courant de la bobine toutes les millisecondes et les grandeurs de
#   courant du banc commun 2.1 (observation seulement). Le critere, les
#   points evalues et le resultat ne changent pas.
#   1 (3 octobre 2026).
#
# OBJECTIF
#   Trouver le meilleur PID a gains fixes sur les essais communs, pour servir
#   de deuxieme reference a toutes les methodes. Le PID de Ziegler-Nichols
#   est la premiere reference, mais il est regle par une methode empirique a
#   5 ohms et il oscille a 98 ohms. Un jury demandera si un PID fixe mieux
#   regle ne ferait pas aussi bien qu'une methode adaptative : ce script
#   repond avec le meilleur PID fixe qu'on puisse trouver dans la meme
#   structure que le PID de reference, en connaissant les essais.
#   C'est donc une reference "oracle" : ses gains sont choisis sur les essais
#   eux-memes. Elle sert d'adversaire le plus fort possible ; elle ne sert pas
#   de point de depart a une methode (ce serait lui donner une information
#   tiree des essais de test).
#
# LE CRITERE (fixe avant le calcul, le 3 octobre 2026)
#   Structure : celle du bloc "PID Controller" de PID_Classique_Control.slx
#     (forme Parallel, derivee filtree avec N = 64122.9 rad/s fixe, Forward
#     Euler a Tc, clamping, sortie bornee a [0.01 ; 0.99], conditions
#     initiales 0.5 et 0.01). Seuls P, I et D changent.
#   Variables : multiplicateurs a, b, c des gains de Ziegler-Nichols :
#     P = a x 0.093910, I = b x 301.089, D = c x 7.3227e-6.
#   Contrainte 1 : sur S1, S3 a S9, chaque evenement revient dans la bande
#     +-1 V avant l'evenement suivant (aucune oscillation entretenue).
#   Cout J : moyenne de 13 rapports au PID de Ziegler-Nichols :
#     - IAE de 30 ms a la fin sur S1, S3, S4, S5, S6, S7a, S7b, S8a, S8b et
#       S9 (10 termes) ;
#     - IAE du demarrage (0 a 30 ms) sur S1, S8a et S8b (3 termes : 5, 25 et
#       98 ohms). Le demarrage a 5 ohms est le meme dans S1 a S7 : il n'est
#       compte qu'une fois.
#     S2 est ecarte : F1 entre par la consigne et aucun regulateur ne la
#     rejette (protocole commun, section 2).
#     J = 1 pour le PID de Ziegler-Nichols ; plus J est petit, mieux c'est.
#
# L'AMENDEMENT (declare, decide apres les deux premieres grilles)
#   Avec la seule contrainte 1, le critere retient des gains dont la marge
#   de phase minimale vaut 4 a 9 degres (P x 5.7 a x 8). Personne ne
#   garderait un tel reglage avec des composants a +-20 %. Contrainte 2,
#   ajoutee avant l'affinage : marge de phase d'au moins 30 degres aux 12
#   coins R = 4, 5, 25, 98 ohms et Vin = 160, 200, 240 V. Les marges sont
#   calculees sur le modele moyen du Buck sans pertes, discretise avec un
#   bloqueur d'ordre zero a Tc, comme dans le document Ziegler-Nichols.
#   Departage : parmi les points dont le J est a moins de 1 % du meilleur,
#   on garde le moins actif (moyenne de |d(k) - d(k-1)| sur S1).
#
# LE DEUXIEME AMENDEMENT (declare, decide apres un premier passage complet)
#   Avec les contraintes 1 et 2, la procedure monte jusqu'a P x 16, I x 5.7,
#   D x 11.3 : J = 0.692, mais une frequence de coupure de 7.4 kHz (le tiers
#   de la frequence de decoupage) et une commande 12 fois plus agitee que
#   celle de Ziegler-Nichols sur S1. Le cout est presque plat : ce point ne
#   gagne que 0.013 sur un reglage coupant a 3.4 kHz. Contrainte 3, regle
#   pratique de la commande numerique des convertisseurs : frequence de
#   coupure au plus egale a fs/10 = 2.2 kHz, a chacun des 12 coins, pour
#   rester dans le domaine de validite du modele moyen et ne pas faire
#   passer l'ondulation de decoupage dans la commande. Le script affiche
#   aussi le meilleur J obtenu avec d'autres seuils (fs/20, fs/5, sans
#   limite), pour montrer ce que coute ce choix.
#
# LA PROCEDURE (deterministe)
#   A. Grille 1 : a dans {1/4, 1/2, 1, 2, 4, 8}, b dans {1/8, 1/4, 1/2, 1,
#      2, 4}, c dans {1/2, 1, 2, 4, 8, 16} (216 points).
#   B. Grille 2, ajoutee parce que le meilleur point de la grille 1 etait au
#      bord a = 8 : a dans {4, 4r, 8, 8r, 16, 16r}, b dans {1, r, 2, 2r, 4},
#      c dans {1/r, 1, r, 2, 2r}, avec r = racine de 2 (150 points).
#   C. Affinage : on part du meilleur point des grilles qui respecte les
#      contraintes 1 a 3 et on evalue ses 26 voisins (chaque multiplicateur
#      divise par r, garde ou multiplie par r). Si un voisin admissible a un
#      J plus petit, il devient le centre et on recommence ; sinon on
#      s'arrete. L'affinage est fait pour le seuil retenu (fs/10), puis,
#      pour montrer ce que coute ce seuil, pour fs/20, fs/5 et sans limite.
#   D. Departage parmi les points des grilles et de l'affinage retenu (regle
#      ci-dessus).
#   L'ordre des calculs est fixe : RECALCULER = True redonne le meme
#   fichier de points et le meme resultat.
#
# CE QUE PRODUIT CE SCRIPT
#   pid_fige_points.json : tous les points evalues (a, b, c, termes du
#     cout, contrainte 1, marge minimale, activite), qui servent aussi de
#     memoire : un point deja present n'est pas recalcule.
#   predictions_banc_pid_fige.json : le PID retenu sur les onze essais, dans
#     le meme format que predictions_banc_pid_classique.json, pour que
#     Simuler_PID_Fige.m compare Simulink au banc.
#   recherche_pid_fige.png : J contre marge minimale pour tous les points
#     evalues, et S8b et S9 avec Ziegler-Nichols et le PID retenu.
#
# DEUX FACONS DE LE LANCER
#   RECALCULER = False (reglage fourni) : les points de pid_fige_points.json
#     sont repris. Le script recalcule quand meme Ziegler-Nichols, le point
#     retenu et trois points tires du fichier, et s'arrete si un seul
#     resultat differe : le fichier fourni est ainsi controle sur ta
#     machine. Une a deux minutes.
#   RECALCULER = True : tous les points sont recalcules (552 points de 10
#     essais chacun) : 35 minutes a une heure selon la machine.
#
# BIBLIOTHEQUES NECESSAIRES (pip install numpy scipy matplotlib)
#
# COMMENT LANCER CE SCRIPT :
#   python recherche_pid_fige.py
#   (ou le notebook recherche_pid_fige.ipynb, meme code), depuis le dossier
#   de la base commune : il lit banc_commun.py, scenarios_communs.json et
#   les fichiers scenario_*.mat de ce dossier.
#
# ORDRE D'EXECUTION (deuxieme reference)
#   1. ce script ; 2. Construction_PID_Fige.m ; 3. verifier_pid_fige.py ;
#   4. Simuler_PID_Fige.m.
# =============================================================================


# %% ETAPE 0 : bibliotheques et definitions du banc commun

import os                                     # chemins de fichiers
import json                                   # lecture et ecriture au format texte
import time                                   # duree d'execution
import itertools                              # produit cartesien des grilles
import numpy as np                            # calcul numerique
from scipy.signal import cont2discrete        # discretisation du modele moyen (marges)
import matplotlib.pyplot as plt               # figures

RECALCULER = False                            # True : recalculer tous les points (35 min a 1 h)

try:                                          # dossier du script (ou dossier courant dans un notebook)
    DOSSIER_PID = os.path.dirname(os.path.abspath(__file__))
except NameError:
    DOSSIER_PID = os.getcwd()

# Le banc commun est execute jusqu'a sa marque de fin des definitions : on
# recupere ainsi exactement ses constantes, la lecture des essais, le
# circuit, la boucle fermee (simuler), les grandeurs et le PID classique,
# sans recopier une ligne de code.
with open(os.path.join(DOSSIER_PID, "banc_commun.py"), encoding="utf-8") as f:
    SOURCE_BANC = f.read()                    # texte complet de banc_commun.py
MARQUE = "# === FIN DES DEFINITIONS DU BANC COMMUN ==="
if MARQUE not in SOURCE_BANC:
    raise RuntimeError("banc_commun.py n'a pas la marque de fin des definitions : prendre la version 2 a jour.")
exec(SOURCE_BANC[:SOURCE_BANC.index(MARQUE)])  # constantes, essais, Circuit, simuler, grandeurs, PIDClassique

ESSAIS = {sc["code"]: sc for sc in SCENARIOS}  # les onze essais, par code
CODES_IAE = ["S1", "S3", "S4", "S5", "S6", "S7a", "S7b", "S8a", "S8b", "S9"]   # IAE de 30 ms a la fin
CODES_DEM = ["S1", "S8a", "S8b"]              # IAE du demarrage (5, 25 et 98 ohms)
K30 = int(round(0.03 / TC))                   # instant 30 ms, en numero de pas Tc
MARGE_MINI = 30.0                             # contrainte 2 : marge de phase minimale (degres)
FC_MAXI = FSW / 10.0                          # contrainte 3 : frequence de coupure maximale (Hz)
TOLERANCE_DEPARTAGE = 0.01                    # departage parmi les J a moins de 1 % du meilleur
R2 = 2.0 ** 0.5                               # pas multiplicatif de la grille 2 et de l'affinage
FICHIER_POINTS = os.path.join(DOSSIER_PID, "pid_fige_points.json")


# %% ETAPE 1 : le PID a gains donnes, et l'evaluation d'un reglage

class PIDParallele:
    """Meme loi que PIDClassique (bloc "PID Controller" de Simulink, forme
    Parallel, Forward Euler, clamping, sortie [0.01 ; 0.99]), avec des gains
    P, I, D donnes. Le coefficient de filtre N et les conditions initiales
    sont ceux du PID de reference."""

    def __init__(self, P, I, D):
        self.P, self.I, self.D = P, I, D      # gains du reglage essaye
        self.xI = PID_CI_INTEGRATEUR          # etat de l'integrateur
        self.xF = PID_CI_FILTRE               # etat du filtre de derivee

    def pas(self, e):
        derivee = PID_N * (self.D * e - self.xF)         # terme derive filtre
        u = self.P * e + self.xI + derivee               # somme des trois termes
        u_sat = min(max(u, D_MIN), D_MAX)                # sortie bornee
        entree_I = self.I * e                            # entree de l'integrateur
        bloque = (u != u_sat) and (np.sign(entree_I) == np.sign(u - u_sat))   # clamping
        if not bloque:
            self.xI += TC * entree_I                     # Forward Euler
        self.xF += TC * derivee                          # Forward Euler du filtre
        return u_sat


def gains(a, b, c):
    """Gains P, I, D correspondant aux multiplicateurs a, b, c."""
    return PID_P * a, PID_I * b, PID_D * c


def evaluer(a, b, c):
    """Simule le reglage (a, b, c) sur les dix essais du critere et renvoie,
    par essai : IAE de 30 ms a la fin, IAE du demarrage (0 a 30 ms),
    retour dans la bande apres chaque evenement, ecart efficace, activite de
    la commande et depassement."""
    P, I, D = gains(a, b, c)
    resultat = {}
    for code in CODES_IAE:
        sim = simuler(PIDParallele(P, I, D), ESSAIS[code])        # boucle fermee du banc commun
        o = grandeurs(sim, ESSAIS[code])                           # memes grandeurs que Simulink
        e = sim["consigne"] - sim["v"]                             # ecart a la consigne
        resultat[code] = {"IAE30": float(o["IAE"]),
                          "IAE_dem": float(np.sum(np.abs(e[:K30])) * TC),
                          "revenus": bool(all(ev["revenu"] for ev in o["evenements"])),
                          "e_eff": float(o["e_eff_V"]), "dd": float(o["dd_moyen"]),
                          "dep": float(o["depassement_pct"])}
    return resultat


def termes(res):
    """Les 13 termes du cout, dans l'ordre : 10 IAE apres 30 ms, 3 IAE de demarrage."""
    return np.array([res[c]["IAE30"] for c in CODES_IAE] + [res[c]["IAE_dem"] for c in CODES_DEM])


# %% ETAPE 2 : marge de phase minimale et frequence de coupure maximale aux 12 coins

# Modele moyen du Buck sans pertes, Vout/d = Vin / (L C s^2 + (L/R) s + 1),
# discretise avec un bloqueur d'ordre zero a Tc ; regulateur discret exact
# du bloc Simulink (Forward Euler). La marge est prise a chaque frequence ou
# le gain de boucle traverse 1 ; on garde la plus petite.
W = np.logspace(np.log10(2 * np.pi * 20.0), np.log10(np.pi / TC * 0.999), 60000)   # pulsations (rad/s)
Z = np.exp(1j * W * TC)                       # points du cercle unite
COINS = [(R, V) for R in (4.0, 5.0, 25.0, 98.0) for V in (160.0, 200.0, 240.0)]
REPONSES = {}                                 # reponse frequentielle du Buck a chaque coin
for R, V in COINS:
    num_d, den_d, _ = cont2discrete(([V], [L_BOB * C_CONV, L_BOB / R, 1.0]), TC, method="zoh")
    REPONSES[(R, V)] = np.polyval(np.squeeze(num_d), Z) / np.polyval(den_d, Z)


def frequentiel(a, b, c):
    """Plus petite marge de phase (degres) et plus haute frequence de coupure
    (Hz) aux 12 coins pour le reglage (a, b, c)."""
    P, I, D = gains(a, b, c)
    Cz = P + I * TC / (Z - 1) + D * PID_N / (1 + PID_N * TC / (Z - 1))   # regulateur discret
    pire, fc = 180.0, 0.0
    for coin, G in REPONSES.items():
        boucle = Cz * G                                              # gain de boucle
        module = np.abs(boucle)
        phase = np.degrees(np.unwrap(np.angle(boucle)))
        croisements = np.where(np.diff(np.sign(module - 1.0)))[0]    # le module traverse 1
        for j in croisements:
            pire = min(pire, (phase[j] + 360.0) % 360.0 - 180.0)     # marge de phase en degres
            fc = max(fc, W[j] / (2 * np.pi))                         # frequence de coupure en Hz
    return float(pire), float(fc)


def marge_min(a, b, c):
    """Plus petite marge de phase (degres) aux 12 coins."""
    return frequentiel(a, b, c)[0]


# %% ETAPE 3 : memoire des points et evaluation des grilles

def cle(a, b, c):
    """Cle texte d'un point (6 decimales suffisent : les multiplicateurs sont des puissances de r)."""
    return f"{a:.6f},{b:.6f},{c:.6f}"


if os.path.exists(FICHIER_POINTS) and not RECALCULER:
    with open(FICHIER_POINTS, encoding="utf-8") as f:
        POINTS = json.load(f)                 # points deja evalues
    print(f"{len(POINTS)} points repris de pid_fige_points.json.")
else:
    POINTS = {}
    print("Tous les points seront calcules.")
T0 = time.time()


def point(a, b, c):
    """Resultat du point (a, b, c), calcule s'il n'est pas deja en memoire."""
    k = cle(a, b, c)
    if k not in POINTS:
        res = evaluer(a, b, c)
        marge, fc = frequentiel(a, b, c)
        POINTS[k] = {"a": a, "b": b, "c": c, "essais": res, "marge_min": marge, "fc_max": fc}
        if len(POINTS) % 20 == 0:
            print(f"  {len(POINTS)} points evalues ({time.time() - T0:.0f} s)")
    return POINTS[k]


ZN = point(1.0, 1.0, 1.0)                     # reference du cout
T_ZN = termes(ZN["essais"])                   # ses 13 termes


def cout(p):
    """J : moyenne des 13 rapports au PID de Ziegler-Nichols."""
    return float(np.mean(termes(p["essais"]) / T_ZN))


def admissible(p, avec_marge=True, fc_maxi=None):
    """Contrainte 1 (tous les evenements revenus) et, si demande, contraintes
    2 (marge) et 3 (frequence de coupure, seuil FC_MAXI par defaut)."""
    ok = all(p["essais"][c]["revenus"] for c in CODES_IAE)
    if not avec_marge:
        return ok
    seuil = FC_MAXI if fc_maxi is None else fc_maxi
    return ok and p["marge_min"] >= MARGE_MINI and p["fc_max"] <= seuil


# A. Grille 1
GRILLE_1 = list(itertools.product([0.25, 0.5, 1, 2, 4, 8], [0.125, 0.25, 0.5, 1, 2, 4], [0.5, 1, 2, 4, 8, 16]))
# B. Grille 2
GRILLE_2 = list(itertools.product([4, 4 * R2, 8, 8 * R2, 16, 16 * R2], [1, R2, 2, 2 * R2, 4], [1 / R2, 1, R2, 2, 2 * R2]))
CLES_GRILLES = []                             # cles des points des grilles 1 et 2
for a, b, c in GRILLE_1 + GRILLE_2:
    point(float(a), float(b), float(c))
    CLES_GRILLES.append(cle(float(a), float(b), float(c)))
print(f"Grilles 1 et 2 evaluees ({len(set(CLES_GRILLES))} points).")
PTS_GRILLES = [POINTS[k] for k in dict.fromkeys(CLES_GRILLES)]       # sans doublon, ordre conserve

meilleur_sans_marge = min((p for p in PTS_GRILLES if admissible(p, False)), key=cout)
print(f"  Grilles, contrainte 1 seule : J = {cout(meilleur_sans_marge):.3f} en a = {meilleur_sans_marge['a']:.3f}, "
      f"b = {meilleur_sans_marge['b']:.3f}, c = {meilleur_sans_marge['c']:.3f}, marge minimale "
      f"{meilleur_sans_marge['marge_min']:.1f} degres (raison de la contrainte 2).")


# %% ETAPE 4 : affinage pour chaque seuil de coupure, puis departage

def affiner(seuil, nom):
    """Affinage a partir du meilleur point des grilles qui respecte les
    contraintes 1 a 3 (seuil de coupure donne). Renvoie le centre final et
    les cles de tous les points visites."""
    depart = [p for p in PTS_GRILLES if admissible(p, True, seuil)]
    if not depart:
        print(f"  {nom} : aucun point des grilles ne respecte les contraintes.")
        return None, []
    centre = min(depart, key=cout)
    visites, etapes = [], 0
    while True:
        voisins = [point(centre["a"] * fa, centre["b"] * fb, centre["c"] * fc)
                   for fa, fb, fc in itertools.product([1 / R2, 1, R2], repeat=3)]
        visites += [cle(v["a"], v["b"], v["c"]) for v in voisins]
        meilleur = min((v for v in voisins if admissible(v, True, seuil)), key=cout)   # le centre en fait partie
        etapes += 1
        if cout(meilleur) >= cout(centre):
            break                             # le centre reste le meilleur : fin
        centre = meilleur
    print(f"  {nom:22s} : J = {cout(centre):.4f} en a = {centre['a']:.3f}, b = {centre['b']:.3f}, "
          f"c = {centre['c']:.3f} ; coupure {centre['fc_max']:.0f} Hz, marge {centre['marge_min']:.1f} degres, "
          f"activite S1 {centre['essais']['S1']['dd']:.4f} ({etapes} etape(s))")
    return centre, visites


print("\nAffinage (contraintes 1 et 2, et coupure au plus egale au seuil) :")
SEUILS = [("coupure <= fs/10 (retenu)", FSW / 10), ("coupure <= fs/20", FSW / 20),
          ("coupure <= fs/5", FSW / 5), ("sans limite de coupure", np.inf)]
AFFINAGES = {nom: affiner(seuil, nom) for nom, seuil in SEUILS}       # ordre fixe : resultat reproductible
CENTRE, VISITES = AFFINAGES[SEUILS[0][0]]

# Departage parmi les points des grilles et de l'affinage retenu dont le J
# est a moins de 1 % de celui du centre final : le moins actif.
candidats = [POINTS[k] for k in dict.fromkeys(CLES_GRILLES + VISITES) if admissible(POINTS[k])]
proches = [p for p in candidats if cout(p) <= cout(CENTRE) * (1 + TOLERANCE_DEPARTAGE)]
RETENU = min(proches, key=lambda p: p["essais"]["S1"]["dd"])           # le moins actif
P_F, I_F, D_F = gains(RETENU["a"], RETENU["b"], RETENU["c"])

with open(FICHIER_POINTS, "w", encoding="utf-8") as f:
    json.dump(POINTS, f, indent=0)
print(f"\n{len(POINTS)} points dans pid_fige_points.json.")


# %% ETAPE 5 : controle des points repris (si RECALCULER = False)

if not RECALCULER:
    rng = np.random.default_rng(20261003)     # tirage fixe des points controles
    autres = [k for k in POINTS if k not in (cle(1.0, 1.0, 1.0), cle(RETENU["a"], RETENU["b"], RETENU["c"]))]
    a_controler = [cle(1.0, 1.0, 1.0), cle(RETENU["a"], RETENU["b"], RETENU["c"])] + \
        list(rng.choice(autres, size=3, replace=False))
    for k in a_controler:
        p = POINTS[k]
        frais = evaluer(p["a"], p["b"], p["c"])                     # nouveau calcul sur cette machine
        rel = np.abs(termes(frais) - termes(p["essais"])) / termes(p["essais"])
        i7a = CODES_IAE.index("S7a")                                 # terme de l'essai quantifie
        ecart = np.max(np.delete(rel, i7a))                          # tous les termes sauf S7a
        marge, fc = frequentiel(p["a"], p["b"], p["c"])
        print(f"  controle de ({p['a']:.3f}, {p['b']:.3f}, {p['c']:.3f}) : ecart relatif {ecart:.1e} "
              f"(S7a : {rel[i7a]:.1e}), marge {marge:.4f} contre {p['marge_min']:.4f} degres")
        # Avec la mesure quantifiee (S7a), un ecart d'arrondi entre deux machines
        # peut changer une decision du CAN : on tolere 2 % sur ce seul terme.
        if ecart > 1e-6 or rel[i7a] > 0.02 or abs(marge - p["marge_min"]) > 1e-6 or abs(fc - p["fc_max"]) > 1e-6:
            raise RuntimeError("Un point repris differe du calcul sur cette machine : relancer avec RECALCULER = True.")
    print("  Les points repris sont confirmes par un nouveau calcul.")


# %% ETAPE 6 : resultat

print("\n" + "=" * 78)
print(" Meilleur PID fige (structure du PID de reference, N inchange)")
print("=" * 78)
print(f"  multiplicateurs : P x {RETENU['a']:.4f}, I x {RETENU['b']:.4f}, D x {RETENU['c']:.4f}")
print(f"  gains Simulink  : P = {P_F:.6f}, I = {I_F:.4f}, D = {D_F:.6e}, N = {PID_N}")
print(f"  J = {cout(RETENU):.4f} (Ziegler-Nichols : 1) ; marge de phase minimale {RETENU['marge_min']:.1f} degres ; "
      f"coupure maximale {RETENU['fc_max']:.0f} Hz")
print(f"  activite de la commande sur S1 : {RETENU['essais']['S1']['dd']:.4f} (Ziegler-Nichols : {ZN['essais']['S1']['dd']:.4f})")
print(f"  {len(proches)} point(s) a moins de 1 % du J du centre final ({cout(CENTRE):.4f}) ; retenu : le moins actif.")
print(f"\n  {'essai':5s} {'IAE30 ZN':>10s} {'IAE30 fige':>11s} {'e eff ZN':>9s} {'e eff fige':>11s} "
      f"{'dep. ZN':>8s} {'dep. fige':>10s} {'revenu ZN/fige':>15s}")
for c in CODES_IAE:
    z, r = ZN["essais"][c], RETENU["essais"][c]
    print(f"  {c:5s} {z['IAE30']*1e3:9.2f}m {r['IAE30']*1e3:10.2f}m {z['e_eff']*1e3:8.1f}m {r['e_eff']*1e3:10.1f}m "
          f"{z['dep']:7.1f}% {r['dep']:9.1f}% {str(z['revenus']):>7s}/{str(r['revenus'])}")
print("  (IAE en mV.s, ecart efficace en mV)")


# %% ETAPE 7 : resultats attendus de Simulink et figure

predictions = {"version": 2, "Te": TC,
               "regulateur": f"meilleur PID fige (P = {P_F:.6f}, I = {I_F:.4f}, D = {D_F:.6e}, N = {PID_N})",
               "gains": {"P": P_F, "I": I_F, "D": D_F, "N": PID_N,
                         "multiplicateurs": [RETENU["a"], RETENU["b"], RETENU["c"]]},
               "critere": {"J": cout(RETENU), "marge_min_deg": RETENU["marge_min"], "fc_max_Hz": RETENU["fc_max"]},
               "controle": {}, "essais": {}}
sims = {}
pas_1ms = int(round(1e-3 / TC))               # 220 pas Tc par milliseconde
for sc in SCENARIOS:
    sim = simuler(PIDParallele(P_F, I_F, D_F), sc)                  # les onze essais, S2 compris
    o = grandeurs(sim, sc)
    sims[sc["code"]] = sim
    predictions["essais"][sc["code"]] = {"grandeurs": o,
                                         "v_toutes_les_ms": sim["v"][::pas_1ms].tolist(),
                                         "iL_toutes_les_ms": sim["iL"][::pas_1ms].tolist(),
                                         "d_moyen_par_ms": [float(np.mean(sim["d"][i:i + pas_1ms]))
                                                            for i in range(0, len(sim["d"]) - pas_1ms + 1, pas_1ms)]}
with open(os.path.join(DOSSIER_PID, "predictions_banc_pid_fige.json"), "w", encoding="utf-8") as f:
    json.dump(predictions, f, indent=1, allow_nan=False)
print("\n  predictions_banc_pid_fige.json ecrit.")

fig, axes = plt.subplots(3, 1, figsize=(11, 10))
adm = [p for p in POINTS.values() if admissible(p, False)]           # contrainte 1 seulement
ok_marge = [p for p in adm if p["marge_min"] >= MARGE_MINI]           # contraintes 1 et 2
axes[0].scatter([p["fc_max"] / 1e3 for p in adm], [cout(p) for p in adm], s=8, c="0.75", label="contrainte 1")
axes[0].scatter([p["fc_max"] / 1e3 for p in ok_marge], [cout(p) for p in ok_marge], s=10, c="tab:blue",
                label="contraintes 1 et 2 (marge >= 30 degres)")
axes[0].scatter([RETENU["fc_max"] / 1e3], [cout(RETENU)], s=60, c="r", label="PID fige retenu")
axes[0].axvline(FC_MAXI / 1e3, color="k", ls="--", lw=0.8, label="contrainte 3 : coupure <= fs/10")
axes[0].set_xlabel("frequence de coupure maximale aux 12 coins (kHz)")
axes[0].set_ylabel("J (Ziegler-Nichols = 1)")
axes[0].set_title("Points evalues (Ziegler-Nichols ne respecte pas la contrainte 1)", fontsize=9, loc="left")
axes[0].grid(alpha=0.3)
axes[0].legend(fontsize=7)
for ax, code in zip(axes[1:], ["S8b", "S9"]):
    sim_zn = simuler(PIDClassique(), ESSAIS[code])
    ax.plot(sim_zn["t"] * 1e3, sim_zn["v"], lw=0.6, label="Ziegler-Nichols")
    ax.plot(sims[code]["t"] * 1e3, sims[code]["v"], lw=0.6, label="PID fige retenu")
    ax.plot(sims[code]["t"] * 1e3, sims[code]["consigne"], "k--", lw=0.6, label="consigne")
    ax.set_ylim(30, 190)
    ax.set_title(f"{code} : {ESSAIS[code]['nom']}", fontsize=9, loc="left")
    ax.set_xlabel("temps (ms)")
    ax.grid(alpha=0.3)
    ax.legend(fontsize=7, loc="upper right")
fig.tight_layout()
fig.savefig(os.path.join(DOSSIER_PID, "recherche_pid_fige.png"), dpi=110)
plt.close(fig)
print(f"  recherche_pid_fige.png ecrit. Duree totale : {time.time() - T0:.0f} s.")
