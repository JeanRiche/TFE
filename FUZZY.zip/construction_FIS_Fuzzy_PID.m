%% ========================================================================
%  CONSTRUCTION DU FIS (FUZZY INFERENCE SYSTEM) POUR LE FUZZY-PID
%  TFE : Optimisation de la régulation d'un convertisseur Buck
%  ========================================================================
%
%  OBJECTIF DE CE SCRIPT
%  ----------------------
%  Construire un système d'inférence flou de type Mamdani qui remplace,
%  dans la loi de commande PID incrémentale de Lu et al. (eq. 13-14 du
%  papier de référence), le mécanisme de mise à jour des gains. Chez
%  ELM-PID, ce mécanisme est une descente de gradient guidée par le
%  jacobien approché par le réseau ELM (eq. 16-18 du papier). Ici, il est
%  remplacé par une table de règles floues qui prend en entrée l'erreur
%  et sa variation, et sort directement les incréments de gains.
%
%  La loi de commande elle-même NE CHANGE PAS et n'est pas construite
%  dans ce script (elle est commune à ELM-PID, PSO-PID et Fuzzy-PID) :
%      Δµ(k) = Kp(k-1)*xc1(k) + Ki(k-1)*xc2(k) + Kd(k-1)*xc3(k)
%      µ(k)  = µ(k-1) + Δµ(k)
%  avec xc1 = e(k)-e(k-1), xc2 = e(k), xc3 = e(k)-2e(k-1)+e(k-2).
%
%  ENTRÉES DU FIS
%  --------------
%   - e  : erreur de régulation, e(k) = Vref - y(k)          (= xc2)
%   - ce : variation de l'erreur, ce(k) = e(k) - e(k-1)       (= xc1)
%
%  SORTIES DU FIS
%  --------------
%   - dKp, dKi, dKd : incréments à ajouter aux gains précédents, exactement
%     comme Kp(k) = Kp(k-1) + dKp(k). Contrairement à ELM-PID (eq. 18), on
%     n'ajoute PAS de terme de moment (α*(Kp(k-1)-Kp(k-2))) : ce terme sert
%     à accélérer la convergence d'une descente de gradient, il n'a pas de
%     sens pour une table de règles qui donne une sortie directe à chaque
%     pas. C'est un écart assumé par rapport à ELM-PID, pas un oubli.
%
%  UNIVERS DE DISCOURS : NORMALISÉS, PAS ENCORE CALIBRÉS EN PHYSIQUE
%  -------------------------------------------------------------------
%  Les cinq variables (e, ce, dKp, dKi, dKd) utilisent ICI le même univers
%  normalisé [-6, 6] avec 5 ensembles flous (NB, NS, ZE, PS, PB). Le
%  passage du monde physique (volts, volts/pas) au monde normalisé se fait
%  via des facteurs d'échelle (Ke, Kec en entrée ; Kpu, Kiu, Kdu en sortie)
%  qui sont fixés ici à 1 comme PLACEHOLDER. Ils devront être calibrés
%  empiriquement sur de vraies simulations Simulink, exactement comme les
%  bornes MU_MIN/MU_MAX d'ELM-PID (quatre itérations documentées). Ce
%  script ne préjuge pas de ces valeurs : il construit la STRUCTURE du FIS,
%  qui est indépendante de l'échelle physique.
%
%  Piste de départ pour Ke (à affiner) : le régime nominal part de e=100V
%  et redescend vers 0 ; la calibration F1 retenue pour ELM-PID donne un
%  pic de sortie ~165V, soit un e minimal ~-65V. Une première plage
%  physique e ∈ [-70, +100] V est donc raisonnable AVANT normalisation.
%  Pour ce, aucune valeur n'est avancée : elle doit être extraite d'une
%  première simulation réelle à Te=5µs, pas devinée.
%
%  MATLAB 2024, Fuzzy Logic Toolbox (fonctions mamfis / addInput / addMF /
%  addOutput / addRule — API objet, pas l'ancien newfis).
%% ========================================================================

clear; clc;

%% ------------------------------------------------------------------
%  1. FACTEURS D'ÉCHELLE (PLACEHOLDERS — À CALIBRER ITÉRATIVEMENT)
%  ------------------------------------------------------------------
%  Ke, Kec convertissent l'erreur physique (V) et sa variation (V/pas) en
%  entrée normalisée du FIS. Kpu, Kiu, Kdu convertissent la sortie
%  normalisée du FIS en incrément physique de gain.
%
%  Ke, Kec : PREMIER PASSAGE CALIBRE (pas un placeholder) sur des données
%  reelles, extraites d'une simulation en boucle fermee de Fuzzy_PID_Control
%  (Ke=Kec=1, donc pas encore representatif du comportement final, mais le
%  regime nominal observe reste une base valable pour l'entree) :
%    ecn  : min=-0.0031   max=0.49995   (e(k)=Vref-y(k), normalise par Vin)
%    dEcn : min=-0.000467 max=0.000153  (variation par pas Te=5us)
%  Ke=10 place ecn=0.5 (transitoire de demarrage) a 5.0, pres de PB sans
%  saturer, et le residu de regime etabli (~-0.003) profondement en ZE,
%  ce qui est physiquement correct. Kec=10000 place le pas le plus abrupt
%  (~4.7e-4) a 4.7, dans PS/PB, plutot que noye dans ZE comme avec Kec=1.
%  A revalider une fois F1/F2 testes sur Fuzzy-PID (l'ecn pourrait alors
%  descendre plus bas que -0.003, comme observe pour ELM-PID).
%
%  Kdu : PREMIER PASSAGE CALIBRE. Avec Kdu=1, Kd saturait a -KD_MAX des le
%  tout premier pas de simulation (verifie : min(Kd_fuzzy.Data)=max(...)=
%  -0.01, aucune exception) -- une seule sortie brute de la FIS (echelle
%  O(1) a O(6)) suffisait a elle seule a epuiser toute la plage physique
%  de Kd en un seul increment, ce qui est incompatible avec l'idee meme
%  d'un gain qui evolue progressivement. Kdu=5e-6 vise plutot quelques
%  centaines de pas de sortie maximale soutenue pour atteindre KD_MAX
%  (6*5e-6*333 ~= 0.01), un ordre de grandeur a valider, pas une certitude.
%
%  Kpu, Kiu : encore a 1. Kp reste a 0 sur ce systeme (confirme, comme pour
%  ELM-PID -- non prioritaire). Kiu n'est PAS touche dans cette passe : le
%  blocage de Ki a KI_MAX observe vient d'abord d'un defaut de la regle
%  (ZE,ZE) elle-meme (section 6, corrigee ci-dessous), pas necessairement
%  de son echelle de sortie -- a isoler avant de toucher Kiu, pour ne pas
%  corriger deux choses a la fois et perdre la capacite de savoir laquelle
%  a resolu quoi.
%  MISE A JOUR (apres correction du cycle limite sur Ki) : une fois
%  l'oscillation saturante eliminee (voir Construction_Simulink_Fuzzy_PID.m,
%  regle e=ZE/ce=ZE historique), le systeme se stabilise proprement mais
%  avec une petite erreur statique (~4,5%, ecn~0.0225 mesure) : Ki retombe
%  a 0 et n'est plus relance, parce que ce residu reste a l'interieur de
%  la bande ZE, calibree large ([-0.3, 0.3] en ecn reel avec Ke=10) pour
%  couvrir l'excursion de demarrage (jusqu'a 0.5).
%
%  REVERT (apres le bug d'univers hors limite) : Ke=100 avait ete
%  propose pour retrecir cette bande, mais a fait sortir e_fis (jusqu'a
%  50 au demarrage) de l'univers ALORS DECLARE [-6,6] du bloc Fuzzy
%  Logic Controller de Simulink, qui ne sature pas silencieusement dans
%  ce cas -- il annule les 3 sorties en permanence tant que l'entree
%  reste hors limite. L'univers de l'entree e est maintenant elargi a
%  [-80,80] (section 3 ci-dessous) pour eviter ca a l'avenir, mais Ke
%  revient ici a 10 : on repart du dernier point de reference propre et
%  compris (y=104.5V, Ki final=0, pas d'oscillation) avant de retenter
%  de resserrer la precision fine, plutot que de repartir d'un etat casse.
Ke  = 100;     % deuxieme tentative, apres correction structurelle (univers elargi a [-80,80], section 3) -- voir note ci-dessus
Kec = 10000;   % inchange
Kpu = 1;       % inchange : Kp reste a 0 sur ce systeme, non prioritaire
Kiu = 1;       % inchange
Kdu = 5e-6;    % calibre : voir justification ci-dessus

%% ------------------------------------------------------------------
%  2. CRÉATION DU FIS MAMDANI
%  ------------------------------------------------------------------
%  mamfis() crée un objet FIS vide de type Mamdani. On fixe explicitement
%  les méthodes d'inférence (valeurs par défaut de Mamdani, mais on les
%  écrit en toutes lettres pour qu'il n'y ait aucune ambiguïté à la
%  relecture, conformément à la convention du projet).
fis = mamfis('Name', 'Fuzzy_PID_Buck');
fis.AndMethod              = 'min';       % ET flou = minimum
fis.OrMethod                = 'max';       % OU flou = maximum (non utilisé ici, pas de règles OU)
fis.ImplicationMethod        = 'min';       % implication = minimum
fis.AggregationMethod        = 'max';       % agrégation des règles = maximum
fis.DefuzzificationMethod    = 'centroid';  % défuzzification = centre de gravité

%% ------------------------------------------------------------------
%  3. ENTRÉE 1 : e (erreur normalisée)
%  ------------------------------------------------------------------
%  Univers DECLARE [-80, 80] (voir note ci-dessous), 5 ensembles flous
%  triangulaires (trimf) a recouvrement de 50%, TOUJOURS centres sur
%  -6, -3, 0, 3, 6 -- seule la plage de validite declaree change, pas
%  les fonctions d'appartenance elles-memes. NB et PB sont des triangles
%  dont un sommet est repete (ex. [-6 -6 -3]) : ceci cree un "epaulement"
%  qui sature la fonction d'appartenance a 1 au-dela de x=6 (ou x=-6),
%  plutot qu'un triangle isole qui retomberait artificiellement a 0.
%
%  CORRECTION DE FOND (le vrai bug, trouve apres le test Ke=100) : un
%  trimf avec un point repete ([3,6,6]) NE CREE PAS un palier qui reste
%  a 1 au-dela de x=6 -- la definition standard d'un triangle retombe a
%  0 pour tout x >= c, meme quand b=c. Ce n'est pas un palier, c'est un
%  triangle degenere qui culmine pile a x=6 et retombe immediatement a
%  0 juste apres. Resultat verifie : des que e_fis depasse 6, les 5
%  ensembles valent tous 0, aucune regle ne se declenche, "no rules
%  fired" en continu, meme avec l'univers declare elargi (qui empeche
%  seulement l'avertissement "hors limites", pas ce probleme-la). Reste
%  invisible tant que Ke reste petit (e_fis ne depasse jamais 6) ; Ke=100
%  l'a expose. Un vrai palier saturant se construit avec un trapeze
%  (trapmf, 4 points), sommet plat jusqu'au bord de l'univers declare :
%  PB = trapmf([3, 6, 80, 80]) reste a 1 de x=6 a x=80 (le bord de
%  l'univers), au lieu de retomber a 0 immediatement apres x=6.
fis = addInput(fis, [-80 80], 'Name', 'e');
fis = addMF(fis, 'e', 'trapmf', [-80 -80 -6 -3], 'Name', 'NB');
fis = addMF(fis, 'e', 'trimf', [-6 -3  0], 'Name', 'NS');
fis = addMF(fis, 'e', 'trimf', [-3  0  3], 'Name', 'ZE');
fis = addMF(fis, 'e', 'trimf', [ 0  3  6], 'Name', 'PS');
fis = addMF(fis, 'e', 'trapmf', [ 3  6  80  80], 'Name', 'PB');

%% ------------------------------------------------------------------
%  4. ENTRÉE 2 : ce (variation de l'erreur normalisée)
%  ------------------------------------------------------------------
%  Structure identique à e (même raisonnement, même recouvrement à 50 %).
%  Seul le facteur d'échelle Kec diffère de Ke une fois la calibration
%  physique faite ; la forme des ensembles flous reste la même.
%
%  MEME CORRECTIF QUE POUR e (voir section 3, le vrai bug trapmf/trimf) :
%  NB et PB passent en trapmf, sommet plat jusqu'au bord de l'univers
%  declare [-1000,1000], au lieu du trimf a point repete qui retombait
%  silencieusement a 0 des que |ce_fis| depassait 6.
fis = addInput(fis, [-1000 1000], 'Name', 'ce');
fis = addMF(fis, 'ce', 'trapmf', [-1000 -1000 -6 -3], 'Name', 'NB');
fis = addMF(fis, 'ce', 'trimf', [-6 -3  0], 'Name', 'NS');
fis = addMF(fis, 'ce', 'trimf', [-3  0  3], 'Name', 'ZE');
fis = addMF(fis, 'ce', 'trimf', [ 0  3  6], 'Name', 'PS');
fis = addMF(fis, 'ce', 'trapmf', [ 3  6  1000  1000], 'Name', 'PB');

%% ------------------------------------------------------------------
%  5. SORTIES : dKp, dKi, dKd
%  ------------------------------------------------------------------
%  Les trois sorties réutilisent la même structure normalisée [-6, 6] à
%  5 ensembles flous, pour rester cohérent et simple. Ce qui les
%  différencie n'est pas leur forme mais la TABLE DE RÈGLES (section 6) :
%  chaque sortie répond différemment à la même paire (e, ce).
for nomSortie = ["dKp", "dKi", "dKd"]
    fis = addOutput(fis, [-6 6], 'Name', nomSortie);
    fis = addMF(fis, nomSortie, 'trimf', [-6 -6 -3], 'Name', 'NB');
    fis = addMF(fis, nomSortie, 'trimf', [-6 -3  0], 'Name', 'NS');
    fis = addMF(fis, nomSortie, 'trimf', [-3  0  3], 'Name', 'ZE');
    fis = addMF(fis, nomSortie, 'trimf', [ 0  3  6], 'Name', 'PS');
    fis = addMF(fis, nomSortie, 'trimf', [ 3  6  6], 'Name', 'PB');
end

%% ------------------------------------------------------------------
%  6. TABLE DE 25 RÈGLES
%  ------------------------------------------------------------------
%  Logique de conception (détaillée dans la réponse qui accompagne ce
%  script, à reprendre telle quelle dans le mémoire, chapitre 4) :
%   - dKp répond surtout à |e| (erreur loin de la cible -> Kp fort), sauf
%     quand ce indique une convergence rapide (risque de dépassement),
%     auquel cas dKp est réduit même si e est encore grand.
%   - dKi répond à l'inverse : petit quand |e| est grand (évite le
%     windup pendant les grands régimes transitoires), grand quand e est
%     proche de zéro (précision en régime établi).
%   - dKd répond surtout à |ce| (vitesse de variation), avec un maximum
%     précisément quand e est petit ET ce est grand : c'est la zone où
%     l'amortissement anti-dépassement est le plus utile.
%  La table est construite pour vérifier g(e,ce) = g(-e,-ce) (symétrie
%  centrale) : les gains sont une fonction de la SÉVÉRITÉ de la situation,
%  pas du signe de l'erreur. Cette propriété est vérifiée automatiquement
%  à la section 7, pas seulement affirmée.
%
%  Indices des ensembles flous (mêmes pour e, ce et les 3 sorties) :
%  1=NB  2=NS  3=ZE  4=PS  5=PB
%
%  Format d'une ligne de règle (API addRule) :
%  [indice_e  indice_ce  indice_dKp  indice_dKi  indice_dKd  poids  ET/OU]
%  poids = 1 (aucune règle atténuée) ; 1 = connecteur ET (les deux
%  entrées doivent être vraies, pas de règle OU dans cette base).

%  CORRECTION DE CONCEPTION (apres premier test reel) : la regle
%  (e=ZE, ce=ZE) donnait a l'origine dKi=PB ("maximiser Ki pour la
%  precision en regime etabli"). Constate en pratique : rien dans la
%  table ne dit jamais a Ki de s'arreter de monter une fois qu'il est
%  deja grand -- la regle se redeclenche a chaque pas des que l'erreur
%  est proche de zero, quelle que soit la valeur deja atteinte par Ki.
%  Resultat mesure : Ki grimpe jusqu'a KI_MAX et y reste colle en
%  permanence, ce qui revient a amplifier au maximum le moindre residu
%  de ripple de commutation en une commande saturee en continu (mu qui
%  oscille sans arret entre ses deux bornes, jamais de convergence
%  reelle). C'est un defaut de la regle elle-meme, pas seulement une
%  question d'echelle : dKi=ZE (rien a ajouter, on maintient l'acquis)
%  est le choix coherent avec l'esprit d'un regulateur qui integre
%  jusqu'a annuler l'erreur, puis s'arrete, pas qui pousse indefiniment.
%
%  CORRECTION SUPPLEMENTAIRE (apres un second test reel) : meme corrigee
%  au centre, la ligne e=ZE reduisait encore Ki sur les colonnes ce=NS et
%  ce=PS ("a la cible, derive legere -> reduire Ki"). Constate en
%  pratique : sur ce systeme, qui ne depasse jamais sa cible (Kp reste a
%  0, confirme a deux reprises), (e=ZE, ce=NS) ne represente PAS un
%  systeme qui oscille autour d'une cible deja atteinte -- c'est encore
%  l'approche finale, la derniere ligne droite avant d'arriver, puisque e
%  continue de descendre. Reduire Ki precisement a cet instant l'a fait
%  s'ecrouler a 0 juste avant la fin de la convergence (mesure : Ki
%  final=0, Vout bloque a ~3,2V au lieu de 100V, plus aucune action
%  integrale pour finir le travail puisque Kp=0 et Kd est negligeable
%  ici). Seules les colonnes extremes (ce=NB ou PB : une vraie
%  perturbation rapide alors qu'on est deja pres de la cible) gardent une
%  reduction de Ki ; les colonnes intermediaires (NS, ZE, PS) maintiennent
%  toutes Ki au lieu de le reduire.
%
%  CORRECTION DE FOND (apres un troisieme test reel, evalfis direct) :
%  au tout premier pas (e=PB, ce=ZE), la table donnait dKi=NB (reduire
%  fortement), en miroir de la regle (e=NB, ce=ZE). Verifie par calcul
%  direct (evalfis) : ceci produit dKi=-0.59 des le premier pas, et comme
%  Ki part de 0 et reste borne a 0 minimum, il n'en decolle jamais --
%  confirme sur 40000 pas de simulation, aucun instant ou Ki > 0.
%  La cause n'est pas une cellule isolee mais le principe de symetrie
%  e/-e impose a TOUTE la table Ki : il suppose qu'une erreur severe
%  positive et une erreur severe negative meritent le meme traitement
%  prudent (anti-windup), au seul motif qu'elles ont la meme ampleur.
%  Sur ce systeme precis, ce n'est pas vrai. Kp reste a 0 en permanence
%  (confirme a plusieurs reprises) : Ki est le SEUL levier reel. Et le
%  systeme ne depasse jamais sa cible tout seul (confirme aussi) : e=PB
%  (tres en dessous de la cible) est la situation de DEMARRAGE, ou Ki
%  doit pouvoir monter sans retenue puisque rien d'autre ne fait avancer
%  le systeme vers la cible. e=NB (au-dessus de la cible) serait un vrai
%  depassement, qui ne se produit pas naturellement ici -- reduire Ki
%  dans ce cas reste defendable, mais ne doit pas s'appliquer par miroir
%  a e=PB. La ligne e=PB de la table Ki cesse donc d'etre le miroir de la
%  ligne e=NB : elle pousse Ki au maximum sur toute la ligne, quelle que
%  soit ce, puisqu'aussi longtemps que le systeme est loin sous sa cible,
%  aucune raison reelle (autre que l'esthetique de la symetrie) ne
%  justifie de freiner le seul gain qui fait effectivement quelque chose.
%  Consequence : dKp et dKd restent verifies symetriques a la section 7 ;
%  dKi ne l'est plus, par construction, et ne doit plus l'etre.
%
%  CORRECTION DE FOND (apres un quatrieme test reel, KI_MAX=10 puis
%  evalfis + decoupage par signe(e)*signe(ce) sur les 10001 points
%  reellement visites en regime etabli) : Ki restait colle a SON PLAFOND
%  quelle que soit sa valeur (teste a 100 puis 10, meme comportement dans
%  les deux cas) -- signe que le plafond n'etait jamais le facteur
%  limitant. Mesure directe : quand l'erreur s'eloigne de zero (e et ce
%  de meme signe), dKi median = -3.6e-17 (bruit flottant, donc nul) et
%  seulement 18.6% des points sont positifs. Quand l'erreur revient DEJA
%  toute seule vers zero (e et ce de signes opposes, aucune aide requise),
%  dKi est positif dans 100% des points, mediane 0.63. La table pousse
%  Ki vers le haut precisement quand ce n'est pas necessaire, et reste
%  muette quand l'erreur empire reellement -- l'inverse de l'intention
%  documentee en tete de section 6.
%  Localise a exactement 4 cellules : (e=NS,ce=NS), (e=NS,ce=PS),
%  (e=PS,ce=NS), (e=PS,ce=PS) -- les seules, dans la region reellement
%  visitee (e_fis reste sous 0.66 en regime etabli, profondement dans ZE
%  avec ~20% de contamination NS/PS ; ce_fis reste sous 2, dans ZE/NS/PS),
%  ou e ET ce sont simultanement non nuls. Ces 4 cellules avaient herite
%  de la meme logique de severite que dKp/dKd (NS quand ca "empire", PS
%  quand ca "converge"), au lieu de la logique propre a l'integrale.
%  Sur ce systeme, le ripple de commutation fait osciller e et ce de part
%  et d'autre de zero en permanence sans jamais representer une vraie
%  divergence ni une vraie convergence a corriger -- c'est du bruit
%  periodique autour de la cible, pas un regime transitoire. Les 4
%  cellules passent donc a dKi=ZE (maintien), exactement le traitement
%  deja retenu pour la ligne e=ZE voisine (regles 12,13,14) apres les
%  deux corrections precedentes. Ni la ligne e=ZE, ni les lignes e=NB/PB
%  (demarrage et anti-depassement theorique, non mis en cause par cette
%  mesure), ni dKp/dKd (aucune anomalie demontree par les donnees) ne
%  sont touches : un seul changement teste a la fois.
%
%  CORRECTION SUPPLEMENTAIRE (5e test, apres verification que la
%  correction precedente est bien chargee -- evalfis(fisFuzzyPID,
%  [-1.5 -1.5]) direct sur la variable utilisee par Simulink) : ce point
%  declenche a poids egal 4 regles ((NS,NS)=7, (NS,ZE)=8, (ZE,NS)=12,
%  (ZE,ZE)=13), et le resultat (dKi=1.5, pas ~0) montre qu'une seule
%  regle non corrigee suffit a tirer le centroide hors de zero. Les
%  cellules (e=NS,ce=ZE) et (e=PS,ce=ZE) etaient restees a dKi=PS,
%  lues comme "progression bloquee a erreur moderee, relance justifiee".
%  Mais e ne depasse jamais 0.66 en regime etabli (loin du pic de regle
%  a 3) : "ce=ZE" ici n'est jamais une vraie stagnation, c'est l'instant
%  ou le ripple change de sens et sa derivee s'annule momentanement --
%  la meme nature de bruit que les 4 cellules deja corrigees, sous un
%  angle (ce exactement nul) que le decoupage signe(e)*signe(ce) du 4e
%  test ne couvrait pas. Alignees sur le traitement de la ligne e=ZE
%  (maintien sur ce=NS/ZE/PS, correction reelle seulement sur ce=NB/PB) :
%  dKi=ZE pour ces 2 cellules aussi. Les colonnes ce=NB/PB des lignes
%  e=NS/PS (regles 6,10,16,20) ne sont pas touchees : elles ne se
%  declenchent jamais dans la plage mesuree (ce reste sous 2, loin du
%  seuil >=3 pour NB/PB) et rester correctes ou non n'est donc pas
%  observable avec les donnees actuelles.
%
%  CORRECTION DE FOND (6e test, apres mesure directe de dKp/dKd en
%  regime etabli reel dans Test_Validation_Fuzzy_PID_Nominal.m, ETAPE
%  4quater -- pas evalfis isole cette fois, mais 4000 points de
%  simulation reelle sur la fenetre [0.18,0.2]s) : dKp affichait une
%  moyenne de -1.75 (min -2.84, max -0.78) et dKd une moyenne de -8.8e-6
%  (min -1.5e-5, max -3.9e-6), TOUS DEUX de signe constamment negatif sur
%  toute la fenetre -- alors que e_fis et ce_fis restent, sur cette meme
%  fenetre, integralement dans la zone coeur [-6,6] (ETAPE 4ter, 0.0%
%  hors coeur), donc en severite quasi nulle. Trace jusqu'a la regle
%  (e=ZE, ce=ZE) : dKp=NS et dKd=NS y etaient RESTES a leur valeur
%  d'origine, jamais revus lors de la correction de dKi sur cette meme
%  cellule ci-dessus ("coquille... dKi etait reste a NS... jamais remis
%  a ZE") -- la meme faute, jamais reproduite pour dKp/dKd faute d'un
%  test qui l'aurait revelee (la verification section 7 ne teste que la
%  symetrie miroir, pas la valeur AU point d'equilibre lui-meme). Ceci
%  contredit directement le principe documente en tete de section 6 :
%  "dKp répond surtout à |e|" -- a e=ZE, |e|=0 par definition, la severite
%  est nulle, dKp/dKd devraient donc valoir ZE, pas NS. Les cellules
%  immediatement voisines le confirment : (e=ZE,ce=NS)=regle 8 et
%  (e=ZE,ce=PS)=regle 14 donnent toutes deux dKp=PS/dKd=PS (signe
%  OPPOSE, meme classe de magnitude) -- (ZE,ZE) est un creux isole au
%  centre exact, pas une transition progressive de severite, signature
%  identique au bug dKi deja corrige. Consequence mecanique : Kp/Kd sont
%  des INTEGRATEURS bornes sans terme de fuite (loi_incrementale_fuzzy,
%  Construction_Simulink_Fuzzy_PID.m) -- alimentes en continu par une
%  sortie non nulle a l'equilibre, ils derivent inevitablement jusqu'a
%  une borne et s'y bloquent (confirme : Kd colle a -KD_MAX 90.9% du
%  temps, Kp colle a 0 96.5% du temps, mu — qui depend de Kd — colle a
%  MU_MAX 50.3% du temps alors que le point de fonctionnement physique
%  attendu est mu=Vref/Vin=0.5). Fix, meme traitement que dKi a cette
%  cellule : dKp NS->ZE et dKd NS->ZE sur la regle (e=ZE,ce=ZE)
%  uniquement -- aucune autre cellule touchee, un seul changement teste
%  a la fois (meme discipline que les corrections precedentes).
%
%  CORRECTION DE FOND (7e test, apres re-mesure reelle post-6e-test dans
%  Test_Validation_Fuzzy_PID_Nominal.m) : la 6e correction a bien elimine
%  le blocage de Kd (90.9%->0.0%) et le plancher de Kp (96.5%->0.2%), MAIS
%  Kp s'est simplement deplace vers SON AUTRE BORNE : colle a KP_MAX=50
%  99.6% du temps (dKp mesure : moyenne +0.51, min +0.0002, jamais negatif
%  sur toute la fenetre). Cause : la ligne e=ZE entiere pousse dKp/dKd
%  vers le haut des que |ce| s'ecarte de zero, quel que soit son signe
%  (regles 8=(ZE,NS) et 14=(ZE,PS), toutes deux dKp=PS/dKd=PS -- coherent
%  avec le principe de symetrie de severite, donc invisible a la
%  verification section 7). Or ce_fis n'est quasiment JAMAIS exactement
%  nul : c'est l'ondulation de commutation, qui oscille en permanence de
%  part et d'autre de zero par construction physique (confirme ETAPE
%  4quinquies : xc1/xc2/xc3 sains et symetriques, ce n'est PAS un biais de
%  calcul_erreur_fuzzy -- le biais est bien dans la reponse du FIS a un ce
%  non nul mais mineur). Un increment positif quasi permanent sur un
%  integrateur sans fuite borne a [0,KP_MAX] ne peut aller que dans un
%  sens. C'est EXACTEMENT le raisonnement deja applique a dKi (4e test
%  ci-dessus, regles (NS,NS)/(NS,PS)/(PS,NS)/(PS,PS)) : "le ripple de
%  commutation fait osciller e et ce en permanence sans jamais representer
%  une vraie divergence ni une vraie convergence -- c'est du bruit
%  periodique, pas un regime transitoire", jamais etendu a dKp/dKd sur
%  les regles 8 et 14. Fix : dKp PS->ZE et dKd PS->ZE sur les regles 8 et
%  14 uniquement (mirroir l'une de l'autre par construction, donc la
%  verification de symetrie section 7 continue de passer). mu (50.2% de
%  contact avec son plafond, mais en 637 contacts courts, le plus long
%  7.2ms) n'est PAS touche par cette correction : ETAPE 4quinquies a deja
%  ecarte un gel de son propre integrateur (xc1/xc2/xc3 sains) -- ce
%  contact frequent mais bref est vraisemblablement du battement normal
%  lie au ripple, a confirmer par inspection visuelle, pas un defaut de
%  la table de regles.
%
%  CORRECTION DE FOND (8e test, apres re-mesure reelle post-7e-test) : le
%  7e test a bien reduit le biais de dKp d'un facteur ~15 (moyenne
%  +0.51->+0.034, min desormais indiscernable de zero) mais Kp reste
%  colle a KP_MAX 96.9% du temps (99.6% avant) -- graphique reel confirme
%  un plateau franc, pas du bruit. Meme mecanique que le 7e test, mais sur
%  l'axe e cette fois plutot que ce : les regles (e=NS,ce=ZE) et
%  (e=PS,ce=ZE) donnent encore dKp=PS/dKd=NS, alors que dKi y est deja ZE
%  depuis le 5e test EXACTEMENT POUR LA MEME RAISON ("e=NS,ce=ZE n'est
%  jamais une vraie stagnation... c'est l'instant ou le ripple change de
%  sens"). e_fis n'est pas plus a zero pile que ce_fis ne l'etait -- il
%  reste seulement dans une bande bien plus etroite en regime etabli (max
%  mesure 0.08 contre 0.95 pour ce_fis, ETAPE 4ter), d'ou une appartenance
%  a PS/NS bien plus faible a ces cellules (~2.7% a e=0.08 contre ~32% a
%  ce=0.95) : le facteur ~12 entre ces deux poids d'activation correspond
%  au facteur ~15 de reduction du biais observe apres le 7e test -- pas
%  une coincidence, la meme mecanique continue de jouer, juste plus
%  doucement. Troisieme occurrence du meme angle mort (verification
%  section 7 = symetrie miroir seulement, jamais la valeur au repos).
%  Fix : dKp PS->ZE et dKd NS->ZE sur (e=NS,ce=ZE) et (e=PS,ce=ZE)
%  (mirroir l'une de l'autre, section 7 continue de passer). mu (50.2%,
%  637 contacts courts, 7.2ms max) inchange apres le 7e test, comme
%  attendu -- cette 8e correction ne le concerne pas non plus.
%
%  CORRECTION DE FOND (9e test, apres re-mesure reelle post-8e-test) : le
%  8e test a bien fait chuter Kp au plafond de 96.9% a 3.1% du temps --
%  desormais explique en totalite par le transitoire de demarrage (le pic
%  a 50 dure ~5-6ms sur le graphique reel, soit ~3% de 0.2s) et dKp est
%  redevenu equilibre (moyenne +4.7e-4, quasi nulle, min/max symetriques
%  -0.127/+0.128). Kp n'est plus suspect. MAIS Kd, annonce "gueri" depuis
%  le 6e test sur la seule foi de SA BORNE NEGATIVE (0.0% a -KD_MAX), n'a
%  jamais ete verifie a SA BORNE POSITIVE -- exactement le piege deja
%  tombe une fois entre le 6e et le 7e test pour Kp (guerir un cote ne
%  prouve rien sur l'autre). Mesure reelle post-8e-test (ETAPE 4quater) :
%  dKd moyenne=+3.13e-07, min=+6.46e-11 -- JAMAIS negatif sur les 4000
%  points de la fenetre [0.18,0.2]s. Graphique reel (validation_nominale_
%  gains.png) : Kd grimpe a ce qui ressemble a son plafond en ~5ms puis
%  reste plat jusqu'a t=0.2s -- signature visuelle d'un gel, pas d'une
%  adaptation active. Cause tracee dans la table : les 4 cellules ou e ET
%  ce sont simultanement non nuls -- (e=NS,ce=NS), (e=NS,ce=PS),
%  (e=PS,ce=NS), (e=PS,ce=PS), deja identifiees et corrigees pour dKi au
%  4e test comme "bruit de ripple pur, pas un vrai transitoire" -- donnent
%  TOUTES LES QUATRE dKd=PS, quel que soit le signe de e et de ce. C'est
%  la difference cle avec dKp, qui alterne PS/NS selon la cellule
%  ((NS,NS)/(PS,PS)->PS, (NS,PS)/(PS,NS)->NS) et s'annule donc en moyenne
%  au fil du ripple (mesure confirmee : dKp quasi nul desormais) : dKd n'a
%  RIEN pour se compenser, les 4 cellules poussent dans le meme sens en
%  permanence, donc l'integrateur sans fuite ne peut que monter. Meme
%  angle mort que les 8 tests precedents (verification section 7 = symetrie
%  miroir seulement, jamais la valeur au repos), sur une nouvelle
%  configuration de cellules (diagonale/coin, pas un axe e=ZE ou ce=ZE).
%  Fix : dKd PS->ZE sur les 4 cellules (2,2)/(2,4)/(4,2)/(4,4) ; dKp non
%  touche (deja sain, deja coherent en miroir a ces 4 cellules -- (2,2)=
%  (4,4)=PS et (2,4)=(4,2)=NS, aucun changement necessaire). Verification
%  section 7 (symetrie miroir) continue de passer : seul dKd change, a la
%  meme valeur (ZE) sur les 2 paires miroir.
%
%  CORRECTION DE FOND (10e test, premier run REEL du scenario F1 --
%  perturbation de commande, Construction_Simulink_Fuzzy_PID_F1.m) :
%  jusqu'ici, la ligne e=NB n'avait JAMAIS ete reellement visitee -- les
%  9 tests precedents portaient tous sur le scenario NOMINAL, ou Vout ne
%  depasse jamais sa cible tout seul (Kp reste a 0, confirme a plusieurs
%  reprises). F1(t) est justement une perturbation qui pousse Vout
%  AU-DESSUS de Vref pendant sa fenetre active [0.05,0.07]s -- la toute
%  premiere situation reelle ou e=NB se produit dans ce projet. Resultat
%  mesure sur les 4 scopes du premier run reel (Vout, Kp/Ki, Kd,
%  commande) : Ki grimpe a environ 6300 pendant la montee, puis s'effondre
%  a 0 exactement au moment ou l'erreur bascule en e=NB (vers t=0.065-
%  0.07s), et Y RESTE jusqu'a la fin du run (t=0.2s) malgre une erreur
%  residuelle large et persistante -- Vout reste bloque a environ 145V au
%  lieu de revenir a 100V. ECHEC du critere de validation obligatoire du
%  projet (retour complet a Vref apres toute perturbation).
%  Cause tracee dans la table : exactement le meme mecanisme que le 3e
%  test ci-dessus, mais sur la ligne MIROIR jamais corrigee. La ligne
%  e=NB donnait encore dKi=NB sur ce=NB/NS/ZE (regles 1-3), dKi=NS sur
%  ce=PS (regle 4) et seulement dKi=PS (pas PB) sur ce=PB (regle 5), sous
%  la justification deja ecrite dans ce fichier lors du 3e test : "e=NB
%  (au-dessus de la cible) serait un vrai depassement, qui ne se produit
%  pas naturellement ici -- reduire Ki dans ce cas reste defendable, mais
%  ne doit pas s'appliquer par miroir a e=PB". Cette hypothese n'avait
%  jamais ete testee avant F1 -- les donnees reelles l'infirment. Le
%  raisonnement qui a corrige e=PB s'applique ici a l'identique : Ki est
%  TOUJOURS >= 0 (loi_incrementale_fuzzy), c'est le SIGNE de l'erreur
%  (xc2=ecn dans dmu = Kp1*xc1 + Ki1*xc2 + Kd1*xc3) qui determine le sens
%  de la correction, pas le signe de Ki -- augmenter Ki pendant un e=NB
%  reel amplifie donc une correction dans le bon sens (vers le bas),
%  exactement comme augmenter Ki pendant un e=PB reel amplifie la
%  correction vers le haut. Rien dans les donnees ne distingue plus les
%  deux cas : la ligne e=NB doit cesser d'etre traitee en anti-windup,
%  pour la meme raison deja retenue pour e=PB.
%  Fix : dKi passe a PB (5) sur TOUTE la ligne e=NB (regles 1 a 5),
%  exactement la meme valeur que la ligne e=PB deja corrigee au 3e test.
%  dKp/dKd NON touches (deja mirroir-symetriques avec e=PB, verifies
%  section 7, aucune anomalie relevee sur ces deux sorties par cette
%  mesure). La regle (e=NS,ce=NB) et son miroir (e=PS,ce=PB), toujours a
%  dKi=NB, ne sont PAS touchees ici : erreur seulement MODEREE (pas
%  severe), zone differente, un seul changement teste a la fois -- a
%  revisiter seulement si une future mesure reelle l'implique
%  specifiquement. A RE-VERIFIER sur le prochain run F1 reel : Ki doit
%  desormais pouvoir remonter depuis 0 des que l'erreur reste franchement
%  negative apres la fin de la perturbation, et Vout doit revenir a 100V
%  avant la fin des 0.2s. A verifier aussi que le scenario NOMINAL reste
%  inchange (e=NB n'y est jamais visite, donc cette ligne ne devrait avoir
%  aucun effet mesurable -- a confirmer par un run reel, pas supposer).
ruleList = [
    1 1  5 5 4  1 1   % e=NB, ce=NB : erreur sévère et qui s'aggrave -> Kp max, Ki max (10e test : plus d'anti-windup, voir bloc ci-dessus), Kd modéré
    1 2  5 5 3  1 1   % e=NB, ce=NS : erreur sévère, aggravation légère -> Kp max, Ki max, Kd neutre
    1 3  5 5 2  1 1   % e=NB, ce=ZE : erreur sévère, bloquée -> Kp max pour la faire bouger, Ki max (10e test), Kd réduit (rien à amortir)
    1 4  4 5 4  1 1   % e=NB, ce=PS : erreur sévère mais convergence modérée -> Kp encore élevé, Ki max (10e test, plus "commence à monter")
    1 5  1 5 5  1 1   % e=NB, ce=PB : erreur sévère, convergence RAPIDE -> Kp réduit (anti-dépassement), Ki max (10e test), Kd max
    2 1  5 1 4  1 1   % e=NS, ce=NB : erreur modérée qui s'aggrave fort -> Kp max
    2 2  4 3 3  1 1   % e=NS, ce=NS : CORRECTION (4e test) -- dKi=NS reagissait au ripple comme une vraie divergence ; e et ce simultanement non nuls mais tous deux modestes = bruit de commutation, pas un transitoire. dKi=ZE (maintien), comme la ligne e=ZE voisine. CORRECTION DE FOND (9e test, voir bloc de commentaire ci-dessus) : dKd restait a PS -- meme faute que dKi ici, jamais reproduite pour dKd. Passe a ZE (maintien) ; dKp inchange (deja sain).
    2 3  3 3 3  1 1   % e=NS, ce=ZE : CORRECTION (5e test, evalfis(fisFuzzyPID,[-1.5 -1.5]) apres 4e correction) -- dKi=PS restant ici tirait encore le centroide hors de zero meme apres avoir corrige 7/9/17/19, car "e=NS,ce=ZE" n'est jamais une vraie stagnation sur ce systeme (e ne depasse jamais 0.63 en regime etabli, loin du pic de regle a 3) : c'est l'instant ou le ripple change de sens, ce=0 momentanement. Meme traitement que la ligne e=ZE (rules 12-14) : dKi=ZE. CORRECTION DE FOND (8e test, voir bloc de commentaire ci-dessus) : dKp/dKd etaient restes a PS/NS -- exactement la meme faute que dKi ici, jamais reproduite faute d'un test qui l'aurait revelee. Passes a ZE (maintien), meme raisonnement.
    2 4  2 3 3  1 1   % e=NS, ce=PS : CORRECTION (4e test) -- dKi=PS reagissait au ripple comme une vraie convergence a recompenser ; meme raisonnement que (NS,NS) : dKi=ZE (maintien). CORRECTION DE FOND (9e test) : dKd PS->ZE, symetrique de la correction de (2,2) ci-dessus ; dKp inchange (deja sain, deja coherent en miroir avec (4,2)).
    2 5  1 4 5  1 1   % e=NS, ce=PB : erreur modérée, convergence rapide -> Kp fortement réduit, Kd max (dépassement imminent)
    3 1  5 1 5  1 1   % e=ZE, ce=NB : à la cible mais dérive rapide -> Kp et Kd max, Ki réduit (seule vraie perturbation à cette ligne)
    3 2  3 3 3  1 1   % e=ZE, ce=NS : approche finale (corrigé) -> Ki MAINTENU, pas réduit. CORRECTION DE FOND (7e test, voir bloc de commentaire ci-dessus) : dKp/dKd etaient restes a PS -- reagissaient au ripple de commutation (ce=NS mineur, normal en regime etabli) comme une vraie perturbation a corriger, poussant Kp vers KP_MAX en permanence. Passes a ZE (maintien), meme raisonnement deja applique a dKi sur les cellules (NS,NS)/(NS,PS)/(PS,NS)/(PS,PS) au 4e test.
    3 3  3 3 3  1 1   % e=ZE, ce=ZE : CORRECTION (coquille trouvee via evalfis + Rules().Description) -- dKi etait reste a NS (reduit) depuis la "DEUXIEME TENTATIVE", jamais remis a ZE (maintenu) comme documente/voulu. Confirme causer le dents-de-scie residuel : Ki retombait a 0 en phase calme au lieu d'etre maintenu, laissant Vout deriver jusqu'a declencher une correction brutale. CORRECTION DE FOND (6e test, voir bloc de commentaire ci-dessus) : dKp et dKd etaient restes a NS (jamais revus lors de la correction de dKi ci-dessus) -- meme faute, memes symptomes (integrateurs Kp/Kd derivant en permanence vers une borne), corriges a ZE pour etre coherents avec les cellules voisines (e=ZE,ce=NS)/(e=ZE,ce=PS) et avec le principe de severite documente en tete de section 6.
    3 4  3 3 3  1 1   % e=ZE, ce=PS : symétrique de (ZE, NS), corrigé de la même façon. CORRECTION DE FOND (7e test) : dKp/dKd PS->ZE, symetrique de la correction de la regle 8 ci-dessus, meme raisonnement (mirroir exact par construction : (3,4) est le miroir de (3,2)).
    3 5  5 1 5  1 1   % e=ZE, ce=PB : symétrique de (ZE, NB), Ki réduit (vraie perturbation)
    4 1  1 4 5  1 1   % e=PS, ce=NB : symétrique de (NS, PB)
    4 2  2 3 3  1 1   % e=PS, ce=NS : CORRECTION (4e test) -- symetrique de (NS,PS) corrige ci-dessus, meme raisonnement : dKi=ZE (maintien) au lieu de PS. CORRECTION DE FOND (9e test) : dKd PS->ZE, miroir de (2,4) ; dKp inchange (deja sain).
    4 3  3 3 3  1 1   % e=PS, ce=ZE : CORRECTION (5e test) -- symetrique de (NS,ZE) corrige ci-dessus, meme raisonnement : dKi=ZE (maintien) au lieu de PS. CORRECTION DE FOND (8e test) : dKp/dKd PS->ZE / NS->ZE, symetrique de la correction de la regle (2,3) ci-dessus, meme raisonnement (mirroir exact par construction : (4,3) est le miroir de (2,3)).
    4 4  4 3 3  1 1   % e=PS, ce=PS : CORRECTION (4e test) -- symetrique de (NS,NS) corrige ci-dessus, meme raisonnement : dKi=ZE (maintien) au lieu de NS. CORRECTION DE FOND (9e test) : dKd PS->ZE, miroir de (2,2) ; dKp inchange (deja sain).
    4 5  5 1 4  1 1   % e=PS, ce=PB : symétrique de (NS, NB)
    5 1  1 5 5  1 1   % e=PB, ce=NB : dKp/dKd symétriques de (NB,PB) ; dKi=PB (corrigé, plus NB) -> démarrage, Ki doit monter
    5 2  4 5 4  1 1   % e=PB, ce=NS : dKi=PB (corrigé, plus NS)
    5 3  5 5 2  1 1   % e=PB, ce=ZE : dKi=PB (corrigé, plus NB) -> c'est CETTE cellule qui bloquait Ki à 0 dès le 1er pas
    5 4  5 5 3  1 1   % e=PB, ce=PS : dKi=PB (corrigé, plus NB)
    5 5  5 5 4  1 1   % e=PB, ce=PB : dKi=PB (corrigé, plus NB)
];

fis = addRule(fis, ruleList);

%% ------------------------------------------------------------------
%  7. VÉRIFICATION AUTOMATIQUE DE LA SYMÉTRIE (dKp, dKd UNIQUEMENT)
%  ------------------------------------------------------------------
%  Ne fait confiance à aucune table recopiée à la main sans la vérifier :
%  pour chaque règle (e_idx, ce_idx), la règle miroir (6-e_idx, 6-ce_idx)
%  doit produire EXACTEMENT le même dKp et le même dKd -- ces deux
%  sorties restent des fonctions de la SÉVÉRITÉ de la situation, pas du
%  signe de l'erreur. dKi est volontairement EXCLU de cette vérification,
%  et ne l'a jamais été depuis le 3e test ci-dessus. CORRECTION DE LA
%  JUSTIFICATION (10e test, voir bloc de commentaire complet ci-dessus) :
%  ce commentaire affirmait jusqu'ici que Ki "monte quand le systeme est
%  sous sa cible, descend en cas de depassement reel" -- un comportement
%  jamais verifie par un run reel visitant e=NB avant F1. Les donnees F1
%  montrent que "descendre" en cas de depassement reel affame le seul
%  levier capable de corriger l'erreur et bloque durablement le systeme
%  loin de sa cible. La regle reellement voulue, confirmee par les deux
%  corrections (3e et 10e tests) : Ki repond a la SEVERITE de l'erreur,
%  dans les DEUX sens (PB sur toute la ligne e=PB ET sur toute la ligne
%  e=NB), pas a son signe -- la direction de la correction vient du signe
%  de l'erreur elle-meme (xc2=ecn dans dmu), jamais du signe de Ki
%  (toujours >= 0 par construction). Ki reste a ZE seulement pres de
%  l'equilibre (e/ce proches de zero), pour ne pas deriver indefiniment
%  une fois la cible atteinte. dKi n'est plus "asymetrique au signe de
%  l'erreur" comme l'affirmait ce commentaire -- il est symetrique en
%  severite comme dKp/dKd, par coincidence de valeurs (PB des deux cotes)
%  et non par construction imposee : rien n'empecherait une future mesure
%  d'exiger des valeurs differentes de PB sur l'un des deux cotes, donc
%  la verification de symetrie miroir ci-dessous continue, a dessein, de
%  ne porter que sur dKp/dKd.
nbErreurs = 0;
for i = 1:size(ruleList,1)
    e_idx  = ruleList(i,1);
    ce_idx = ruleList(i,2);
    ligneMiroir = ruleList( ruleList(:,1)==(6-e_idx) & ruleList(:,2)==(6-ce_idx), [3 5] );
    tripletKpKd = ruleList(i, [3 5]);
    if ~isequal(tripletKpKd, ligneMiroir)
        fprintf('ASYMETRIE (dKp/dKd) : regle (%d,%d)=%s vs miroir (%d,%d)=%s\n', ...
            e_idx, ce_idx, mat2str(tripletKpKd), 6-e_idx, 6-ce_idx, mat2str(ligneMiroir));
        nbErreurs = nbErreurs + 1;
    end
end
if nbErreurs == 0
    fprintf('Vérification de symétrie (dKp, dKd) : OK sur les 25 règles.\n');
else
    error('%d asymétrie(s) détectée(s) dans la table de règles — corriger avant de continuer.', nbErreurs);
end

% VERIFICATION SUPPLEMENTAIRE (ajoutee suite au 6e test ci-dessus) : la
% symetrie miroir ci-dessus ne garantit PAS que la regle d'EQUILIBRE
% (e=ZE, ce=ZE, severite nulle par definition) produit bien une sortie
% ZE pour dKp et dKd -- c'est exactement le defaut qui vient d'etre
% trouve (NS au lieu de ZE), invisible a la verification de symetrie
% puisque NS==NS est parfaitement "symetrique" avec lui-meme. Controle
% direct et permanent de ce point precis pour empecher toute regression.
ligneEquilibre = ruleList( ruleList(:,1)==3 & ruleList(:,2)==3, [3 5] );
if ~isequal(ligneEquilibre, [3 3])
    error(['La regle (e=ZE, ce=ZE) donne dKp/dKd=%s au lieu de [ZE ZE]=[3 3] -- ' ...
        'severite nulle par definition a ce point, une sortie non nulle fait deriver ' ...
        'les integrateurs bornes Kp/Kd (loi_incrementale_fuzzy) jusqu''a une borne ' ...
        'sans jamais en repartir (voir 6e correction ci-dessus).'], mat2str(ligneEquilibre));
end
fprintf('Vérification du point d''équilibre (e=ZE, ce=ZE) : dKp=ZE, dKd=ZE -- OK.\n');

% VERIFICATION SUPPLEMENTAIRE (ajoutee suite au 7e test) : au-dela du seul
% point d'equilibre exact, ce_fis n'est en pratique JAMAIS a zero pile
% (ondulation de commutation permanente) -- toute la ligne e=ZE (ce=NS,
% ZE, PS) est donc visitee en continu en regime etabli. Un dKp/dKd non nul
% sur CE=NS ou CE=PS avec e=ZE produit exactement le meme windup que sur
% (ZE,ZE), juste plus lent -- confirme en pratique (regle 8/14 a PS ->
% Kp colle a KP_MAX 99.6% du temps, voir 7e correction ci-dessus). Controle
% permanent sur toute la ligne e=ZE, pas seulement son centre.
ligneZE_NS = ruleList( ruleList(:,1)==3 & ruleList(:,2)==2, [3 5] );
ligneZE_PS = ruleList( ruleList(:,1)==3 & ruleList(:,2)==4, [3 5] );
if ~isequal(ligneZE_NS, [3 3]) || ~isequal(ligneZE_PS, [3 3])
    error(['La ligne e=ZE donne dKp/dKd=%s en ce=NS et %s en ce=PS au lieu de [ZE ZE] -- ' ...
        'ce_fis n''est quasiment jamais exactement nul en regime etabli (ondulation de ' ...
        'commutation permanente), donc ces cellules se declenchent en continu ; une sortie ' ...
        'non nulle y fait deriver Kp/Kd vers une borne tout aussi surement qu''a (e=ZE,ce=ZE) ' ...
        '(voir 7e correction ci-dessus).'], mat2str(ligneZE_NS), mat2str(ligneZE_PS));
end
fprintf('Vérification de toute la ligne e=ZE (ce=NS/ZE/PS) : dKp=ZE, dKd=ZE -- OK.\n');

% VERIFICATION SUPPLEMENTAIRE (ajoutee suite au 8e test) : meme angle mort,
% cette fois sur l'AXE e plutot que ce -- e_fis n'est en pratique jamais a
% zero pile non plus (max mesure 0.08 en regime etabli, ETAPE 4ter), donc
% les cellules (e=NS,ce=ZE) et (e=PS,ce=ZE) se declenchent en continu, a
% faible poids mais sans jamais s'arreter. Un dKp/dKd non nul y produit le
% meme windup que sur (ZE,ZE) ou la ligne e=ZE, juste plus lent (confirme :
% Kp encore colle a KP_MAX 96.9% du temps apres le 7e test, malgre un biais
% deja reduit d'un facteur ~15). Controle permanent sur ces deux cellules,
% symetriques l'une de l'autre par construction.
colonneZE_NS = ruleList( ruleList(:,1)==2 & ruleList(:,2)==3, [3 5] );
colonneZE_PS = ruleList( ruleList(:,1)==4 & ruleList(:,2)==3, [3 5] );
if ~isequal(colonneZE_NS, [3 3]) || ~isequal(colonneZE_PS, [3 3])
    error(['Les regles (e=NS,ce=ZE) et (e=PS,ce=ZE) donnent dKp/dKd=%s et %s au lieu de ' ...
        '[ZE ZE] -- e_fis n''est quasiment jamais exactement nul en regime etabli (max ' ...
        'mesure 0.08), donc ces cellules se declenchent en continu ; une sortie non nulle ' ...
        'y fait deriver Kp/Kd vers une borne tout aussi surement qu''a (e=ZE,ce=ZE) ou sur ' ...
        'la ligne e=ZE (voir 8e correction ci-dessus).'], mat2str(colonneZE_NS), mat2str(colonneZE_PS));
end
fprintf('Vérification des cellules (e=NS,ce=ZE) et (e=PS,ce=ZE) : dKp=ZE, dKd=ZE -- OK.\n');

% VERIFICATION SUPPLEMENTAIRE (ajoutee suite au 9e test) : meme angle mort
% une troisieme forme -- cette fois sur les 4 cellules "diagonales" ou e ET
% ce sont simultanement non nuls (e=NS/PS croise avec ce=NS/PS). Contrairement
% aux verifications precedentes (axe e=ZE, axe ce=ZE), on NE verifie PAS ici
% dKp==ZE : dKp y est deliberement non nul (PS sur (NS,NS)/(PS,PS), NS sur
% (NS,PS)/(PS,NS)) et c'est correct, car les 2 paires s'annulent en moyenne
% au fil du ripple (mesure confirmee : dKp quasi nul en regime etabli). Seul
% dKd est verifie a ZE, car ces 4 cellules donnaient TOUTES dKd=PS (aucune
% compensation possible, contrairement a dKp) -- un integrateur sans fuite
% pousse alors inevitablement vers +KD_MAX (confirme : dKd jamais negatif
% sur 4000 points en regime etabli avant cette correction).
coinNS_NS = ruleList( ruleList(:,1)==2 & ruleList(:,2)==2, 5 );
coinNS_PS = ruleList( ruleList(:,1)==2 & ruleList(:,2)==4, 5 );
coinPS_NS = ruleList( ruleList(:,1)==4 & ruleList(:,2)==2, 5 );
coinPS_PS = ruleList( ruleList(:,1)==4 & ruleList(:,2)==4, 5 );
if coinNS_NS~=3 || coinNS_PS~=3 || coinPS_NS~=3 || coinPS_PS~=3
    error(['Les regles (e=NS,ce=NS)/(e=NS,ce=PS)/(e=PS,ce=NS)/(e=PS,ce=PS) donnent dKd=[%d %d %d %d] ' ...
        'au lieu de [ZE ZE ZE ZE]=[3 3 3 3] -- ces 4 cellules simultanement non nulles en e ET ce ne ' ...
        'peuvent PAS se compenser entre elles pour dKd (contrairement a dKp, qui alterne PS/NS selon ' ...
        'la cellule) : une sortie non nulle et de meme signe sur les 4 y fait deriver Kd vers une borne ' ...
        'de facon garantie (voir 9e correction ci-dessus).'], coinNS_NS, coinNS_PS, coinPS_NS, coinPS_PS);
end
fprintf('Vérification des 4 cellules diagonales (NS/PS x NS/PS) : dKd=ZE -- OK.\n');

% VERIFICATION SUPPLEMENTAIRE (ajoutee suite au 10e test, voir bloc de
% commentaire complet ci-dessus) : la ligne e=NB n'avait jamais ete
% reellement visitee avant le premier run du scenario F1 -- son dKi
% "anti-windup" (NB/NS sur la majeure partie de la ligne) affamait Ki des
% que l'erreur basculait au-dessus de Vref sous l'effet de la
% perturbation, bloquant Vout loin de sa cible sans aucun mecanisme pour
% en repartir. Controle permanent, exactement le meme principe que pour
% la ligne e=PB (corrigee au 3e test, jamais dotee de son propre garde-fou
% jusqu'ici) : dKi doit valoir PB (5) sur les 2 lignes extremes, sans
% exception de cellule.
ligneNB_dKi = ruleList( ruleList(:,1)==1, 4 );
lignePB_dKi = ruleList( ruleList(:,1)==5, 4 );
if any(ligneNB_dKi ~= 5) || any(lignePB_dKi ~= 5)
    error(['La ligne e=NB donne dKi=%s et la ligne e=PB donne dKi=%s (ordre ce=NB..PB) au lieu ' ...
        'de PB partout ([5 5 5 5 5]) -- une erreur severe et persistante (dans un sens ou dans ' ...
        'l''autre, ex. perturbation F1 qui pousse Vout au-dessus de Vref) affame alors le seul ' ...
        'levier de correction reel (Ki) sans aucun mecanisme pour en repartir (voir 10e ' ...
        'correction ci-dessus, confirmee par le premier run reel du scenario F1).'], ...
        mat2str(ligneNB_dKi.'), mat2str(lignePB_dKi.'));
end
fprintf('Vérification des lignes e=NB et e=PB (10e test) : dKi=PB sur toute la ligne, aucune exception -- OK.\n');

%% ------------------------------------------------------------------
%  8. VISUALISATION DE CONTRÔLE (fonctions d'appartenance)
%  ------------------------------------------------------------------
%  Trace les fonctions d'appartenance de e et de dKp pour vérification
%  visuelle avant intégration dans Simulink — même logique que les
%  captures d'écran utilisées pour valider les bornes MU d'ELM-PID.
figure('Name', 'Verification FIS Fuzzy-PID');
subplot(2,1,1); plotmf(fis, 'input', 1);  title('Entrée e (normalisée)');
subplot(2,1,2); plotmf(fis, 'output', 1); title('Sortie dKp (normalisée)');

%% ------------------------------------------------------------------
%  9. EXPORT
%  ------------------------------------------------------------------
%  writeFIS enregistre un fichier .fis lisible par le bloc Simulink
%  "Fuzzy Logic Controller" (référence directe au fichier). Le .mat
%  conserve en plus l'objet fis complet pour un usage programmatique
%  (par exemple, réévaluer une règle en Python/MATLAB hors Simulink).
writeFIS(fis, 'fuzzy_pid_buck.fis');
save('fuzzy_pid_buck.mat', 'fis', 'Ke', 'Kec', 'Kpu', 'Kiu', 'Kdu');

fprintf('\nFIS construit : %d entrées, %d sorties, %d règles.\n', ...
    numel(fis.Inputs), numel(fis.Outputs), numel(fis.Rules));
fprintf('Fichiers écrits : fuzzy_pid_buck.fis, fuzzy_pid_buck.mat\n');
fprintf('Prochaine étape : calibration de Ke, Kec, Kpu, Kiu, Kdu sur simulation réelle.\n');
