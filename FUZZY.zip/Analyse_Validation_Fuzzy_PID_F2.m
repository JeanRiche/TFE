%% Analyse_Validation_Fuzzy_PID_F2.m
% =========================================================================
%   VALIDATION NUMERIQUE DU SCENARIO F2 (PERTURBATION DE CHARGE) --
%   FUZZY-PID -- meme niveau de rigueur que Analyse_Validation_Fuzzy_PID_F1.m
% =========================================================================
%
% POURQUOI CE SCRIPT : le seul script existant pour F2, Analyse_mu_F2_vs_
% Nominal.m, ne mesure qu'UNE chose (le chatter de mu_fuzzy hors
% perturbation, nominal vs F2) -- il ne verifie ni la reaction physique de
% Vout/iL a la perturbation, ni le comportement de Ki/Kp/Kd a une fenetre
% comparable au nominal, ni la saturation de la commande reellement
% appliquee. Ce n'est pas une validation complete, seulement un diagnostic
% ponctuel sur un point precis. Ce script la complete, avec la meme
% structure et la meme exigence que celle appliquee a F1 :
%   1) empreinte physique de la perturbation sur iL et Vout (F2 est une
%      perturbation de CHARGE, contrairement a F1 qui est une perturbation
%      de COMMANDE -- la preuve la plus directe que le mecanisme herite de
%      PID_Classique_Control_load_disturbance.slx est bien exerce passe
%      par le courant de charge, pas par un signal logue) ;
%   2) Ki/Kp/Kd a une fenetre de comparaison EGALE a celle du nominal
%      ([0.18, 0.20]s, jamais une reference d'un autre horizon de
%      simulation -- meme piege deja documente et evite pour F1) ;
%   3) saturation de mu_fuzzy (qui EST ICI le signal reellement applique
%      au PWM, puisque F2 ne touche jamais les bornes internes de mu --
%      voir Construction_Simulink_Fuzzy_PID_F2.m, "F2 ne perturbe jamais
%      mu"), pendant vs hors perturbation ;
%   4) chatter de mu_fuzzy hors perturbation, nominal vs F2 -- reprend et
%      etend Analyse_mu_F2_vs_Nominal.m en calculant explicitement l'ecart
%      de moyenne (ce script-ci ne se contentait que d'un jugement visuel
%      "du meme ordre" sans le chiffrer).
%
% RAPPEL DE LA DEFINITION (Lu et al. 2021, section 5.3, "disturbance F2(t)"),
% telle que documentee dans l'en-tete de Construction_Simulink_Fuzzy_PID_F2.m :
%   F2(t) = 0        , 0    < t < 0.05
%         = -2*R/15  , 0.05 < t < 0.07
%         = 0        , 0.07 < t < 0.2
% avec R = 5 ohms (valeur nominale du circuit), donc F2(t) = -0.6667 ohm sur
% la fenetre active : une DIMINUTION de la resistance de charge, R_eff(t) =
% R + F2(t) = 4.333 ohms sur cette fenetre. A Vout constant, une resistance
% plus faible tire davantage de courant : iL doit donc AUGMENTER pendant la
% fenetre active, et Vout doit d'abord CREUSER (undershoot) avant de
% revenir a Vref -- sens oppose a F1 (qui fait MONTER Vout). Ce mecanisme
% est physique (topologie de circuit commutee, pas un signal), donc F2(t)
% lui-meme n'est logue nulle part dans le modele : ce script le rappelle
% ci-dessous comme une CONSTANTE de reference, il ne l'extrait pas d'une
% simulation.
%
% Ce script ne modifie aucun fichier .slx et ne tranche aucune conclusion
% a la place de l'utilisateur -- il mesure et affiche, a charge de lecture.
% =========================================================================

clear; clc;

% Meme mecanisme que pour le nominal/F1/Analyse_mu_F2_vs_Nominal.m : le
% clear ci-dessus vide "fisFuzzyPID" du workspace de base, or FLC_Fuzzy_PID
% (nominal ET F2) le reference par son parametre FIS a l'execution de
% sim(). Rechargement explicite avant toute simulation.
if ~exist('fuzzy_pid_buck.mat', 'file')
    error(['Fichier fuzzy_pid_buck.mat introuvable sur le chemin MATLAB courant. ' ...
           'Placez-vous dans le dossier qui le contient avant de relancer ce script.']);
end
d_fis = load('fuzzy_pid_buck.mat');
assignin('base', 'fisFuzzyPID', d_fis.fis);
fprintf('"fisFuzzyPID" recharge dans le workspace de base depuis fuzzy_pid_buck.mat (%d regles).\n\n', ...
    numel(d_fis.fis.Rules));

mdlNominal = 'Fuzzy_PID_Control';
mdlF2      = 'Fuzzy_PID_Control_F2';

Vref = 100;
Vin  = 200;
R_NOMINAL = 5;                       % ohms, valeur nominale de la charge
DELTA_R_ACTIF = -2 * R_NOMINAL / 15; % F2(t) pendant la fenetre active
R_EFF_ACTIF = R_NOMINAL + DELTA_R_ACTIF;
fprintf(['Rappel (constante de reference, NON extraite d''une simulation -- F2 est une perturbation\n' ...
    'physique de circuit, pas un signal logue) : F2(t) = %+.4f ohm pendant [0.05,0.07]s, soit R_eff = ' ...
    '%.4f ohm (contre %.1f ohm hors perturbation).\n\n'], DELTA_R_ACTIF, R_EFF_ACTIF, R_NOMINAL);

% -------------------------------------------------------------------
% ETAPE 1 : nominal -- simulation puis extraction IMMEDIATE (avant que F2
% n'ecrase les memes noms de variable dans le workspace de base)
% -------------------------------------------------------------------
fprintf('=========================================================\n');
fprintf(' NOMINAL (%s)\n', mdlNominal);
fprintf('=========================================================\n');
if isempty(which([mdlNominal '.slx']))
    error('Fichier "%s.slx" introuvable sur le chemin MATLAB.', mdlNominal);
end
load_system(mdlNominal);
% Le courant iL est logue par un bloc nomme "To Workspace1", mais son
% parametre VariableName n'est PAS forcement "iL" -- heritage du fichier
% de reference PID_Classique_Control.slx, ou ce bloc s'appelle "x" (voir
% Construction_Simulink_Fuzzy_PID.m). Lu dynamiquement ici plutot que
% suppose, pour ne pas reproduire une erreur deja rencontree ailleurs dans
% ce projet (ne jamais supposer un nom sans le verifier).
nomVarVout_nom = get_param([mdlNominal '/To Workspace'],  'VariableName');
nomVarIL_nom   = get_param([mdlNominal '/To Workspace1'], 'VariableName');
fprintf('Variables de sortie du nominal : Vout -> "%s", iL -> "%s" (verifie, pas suppose).\n', ...
    nomVarVout_nom, nomVarIL_nom);
% StopTime du nominal fixe explicitement (voir Analyse_Validation_Fuzzy_
% PID_F1.m pour le detail) : deux runs successifs de scripts qui ne
% touchaient jamais StopTime ont donne des durees de simulation
% differentes pour ce meme fichier (1s puis 0.2s) -- signe que la valeur
% sauvegardee dans le .slx n'est pas stable dans le temps. 0.2s suffit a
% toutes les fenetres utilisees ici (la plus tardive est [0.18,0.20]s) et
% egalise la duree avec F2, plutot que de dependre d'une valeur non
% controlee par ce script.
set_param(mdlNominal, 'StopTime', '0.2');
% AJOUT (demande explicite : etendre la decomposition de contribution
% Kp*xc1/Ki*xc2/Kd*xc3, ETAPE 4sexies de Test_Validation_Fuzzy_PID_
% Nominal.m, au-dela du seul regime nominal a [0.98,1.00]s -- voir MESURE 5
% plus bas). Blocs de logging temporaires, memes noms/branchements que
% ETAPE 4quinquies de ce meme script nominal (Calcul_Erreur_Fuzzy/1-2-3 =
% xc2/xc1/xc3, PAS un ordre 1-2-3 naturel -- verifie sur ce script-source,
% pas suppose). Ajoutes sur le modele CHARGE EN MEMOIRE uniquement ;
% close_system(...,0) ci-dessous ne sauvegarde jamais rien sur disque.
add_block('simulink/Sinks/To Workspace', [mdlNominal '/Log_xc2_tmp'], ...
    'VariableName', 'xc2_log', 'SaveFormat', 'Timeseries', 'Position', [400 220 460 240]);
add_block('simulink/Sinks/To Workspace', [mdlNominal '/Log_xc1_tmp'], ...
    'VariableName', 'xc1_log', 'SaveFormat', 'Timeseries', 'Position', [400 260 460 280]);
add_block('simulink/Sinks/To Workspace', [mdlNominal '/Log_xc3_tmp'], ...
    'VariableName', 'xc3_log', 'SaveFormat', 'Timeseries', 'Position', [400 300 460 320]);
add_line(mdlNominal, 'Calcul_Erreur_Fuzzy/1', 'Log_xc2_tmp/1', 'autorouting', 'on');
add_line(mdlNominal, 'Calcul_Erreur_Fuzzy/2', 'Log_xc1_tmp/1', 'autorouting', 'on');
add_line(mdlNominal, 'Calcul_Erreur_Fuzzy/3', 'Log_xc3_tmp/1', 'autorouting', 'on');
set_param(mdlNominal, 'ReturnWorkspaceOutputs', 'off');   % regle de construction n=8, reaffirmee avant chaque sim
fprintf('Simulation de %s...\n', mdlNominal);
sim(mdlNominal);
[t_nom, y_nom]  = extraire_temps_valeurs(evalin('base', nomVarVout_nom), sprintf('%s (Vout, nominal)', nomVarVout_nom));
[~,     x_nom]  = extraire_temps_valeurs(evalin('base', nomVarIL_nom),   sprintf('%s (iL, nominal)', nomVarIL_nom));
[~,     mu_nom] = extraire_temps_valeurs(evalin('base', 'mu_fuzzy'), 'mu_fuzzy (nominal)');
[~,     Kp_nom] = extraire_temps_valeurs(evalin('base', 'Kp_fuzzy'), 'Kp_fuzzy (nominal)');
[~,     Ki_nom] = extraire_temps_valeurs(evalin('base', 'Ki_fuzzy'), 'Ki_fuzzy (nominal)');
[~,     Kd_nom] = extraire_temps_valeurs(evalin('base', 'Kd_fuzzy'), 'Kd_fuzzy (nominal)');
[t_xc1_nom, xc1_nom] = extraire_temps_valeurs(evalin('base', 'xc1_log'), 'xc1_log (nominal)');
[t_xc2_nom, xc2_nom] = extraire_temps_valeurs(evalin('base', 'xc2_log'), 'xc2_log (nominal)');
[t_xc3_nom, xc3_nom] = extraire_temps_valeurs(evalin('base', 'xc3_log'), 'xc3_log (nominal)');
delete_block([mdlNominal '/Log_xc1_tmp']);
delete_block([mdlNominal '/Log_xc2_tmp']);
delete_block([mdlNominal '/Log_xc3_tmp']);
close_system(mdlNominal, 0);
fprintf('Nominal extrait : %d points, de t=%.6g a t=%.6g.\n\n', numel(y_nom), t_nom(1), t_nom(end));

% -------------------------------------------------------------------
% ETAPE 2 : F2 -- simulation puis extraction IMMEDIATE
% -------------------------------------------------------------------
fprintf('=========================================================\n');
fprintf(' F2 (%s)\n', mdlF2);
fprintf('=========================================================\n');
if isempty(which([mdlF2 '.slx']))
    error(['Fichier "%s.slx" introuvable sur le chemin MATLAB. Lancez d''abord ' ...
           'Construction_Simulink_Fuzzy_PID_F2.m.'], mdlF2);
end
load_system(mdlF2);
nomVarVout_f2 = get_param([mdlF2 '/To Workspace'],  'VariableName');
nomVarIL_f2   = get_param([mdlF2 '/To Workspace1'], 'VariableName');
fprintf('Variables de sortie de F2 : Vout -> "%s", iL -> "%s" (verifie, pas suppose).\n', ...
    nomVarVout_f2, nomVarIL_f2);
% Meme ajout que pour le nominal ci-dessus, meme branchement verifie.
add_block('simulink/Sinks/To Workspace', [mdlF2 '/Log_xc2_tmp'], ...
    'VariableName', 'xc2_log', 'SaveFormat', 'Timeseries', 'Position', [400 220 460 240]);
add_block('simulink/Sinks/To Workspace', [mdlF2 '/Log_xc1_tmp'], ...
    'VariableName', 'xc1_log', 'SaveFormat', 'Timeseries', 'Position', [400 260 460 280]);
add_block('simulink/Sinks/To Workspace', [mdlF2 '/Log_xc3_tmp'], ...
    'VariableName', 'xc3_log', 'SaveFormat', 'Timeseries', 'Position', [400 300 460 320]);
add_line(mdlF2, 'Calcul_Erreur_Fuzzy/1', 'Log_xc2_tmp/1', 'autorouting', 'on');
add_line(mdlF2, 'Calcul_Erreur_Fuzzy/2', 'Log_xc1_tmp/1', 'autorouting', 'on');
add_line(mdlF2, 'Calcul_Erreur_Fuzzy/3', 'Log_xc3_tmp/1', 'autorouting', 'on');
set_param(mdlF2, 'ReturnWorkspaceOutputs', 'off');
fprintf('Simulation de %s...\n', mdlF2);
sim(mdlF2);
[t_f2, y_f2]  = extraire_temps_valeurs(evalin('base', nomVarVout_f2), sprintf('%s (Vout, F2)', nomVarVout_f2));
[~,    x_f2]  = extraire_temps_valeurs(evalin('base', nomVarIL_f2),   sprintf('%s (iL, F2)', nomVarIL_f2));
[~,    mu_f2] = extraire_temps_valeurs(evalin('base', 'mu_fuzzy'), 'mu_fuzzy (F2)');
[~,    Kp_f2] = extraire_temps_valeurs(evalin('base', 'Kp_fuzzy'), 'Kp_fuzzy (F2)');
[~,    Ki_f2] = extraire_temps_valeurs(evalin('base', 'Ki_fuzzy'), 'Ki_fuzzy (F2)');
[~,    Kd_f2] = extraire_temps_valeurs(evalin('base', 'Kd_fuzzy'), 'Kd_fuzzy (F2)');
[t_xc1_f2, xc1_f2] = extraire_temps_valeurs(evalin('base', 'xc1_log'), 'xc1_log (F2)');
[t_xc2_f2, xc2_f2] = extraire_temps_valeurs(evalin('base', 'xc2_log'), 'xc2_log (F2)');
[t_xc3_f2, xc3_f2] = extraire_temps_valeurs(evalin('base', 'xc3_log'), 'xc3_log (F2)');
delete_block([mdlF2 '/Log_xc1_tmp']);
delete_block([mdlF2 '/Log_xc2_tmp']);
delete_block([mdlF2 '/Log_xc3_tmp']);
close_system(mdlF2, 0);
fprintf('F2 extrait : %d points, de t=%.6g a t=%.6g.\n\n', numel(y_f2), t_f2(1), t_f2(end));

% Masque partage, reutilise par les mesures 2 et 3 : toute la fenetre
% active de la perturbation [0.05, 0.07]s sur l'axe de temps de F2.
idxFenetreActive_f2 = (t_f2 >= 0.05) & (t_f2 <= 0.07);

% =========================================================================
% MESURE 1 : empreinte physique de la perturbation sur iL et Vout
% =========================================================================
fprintf('=========================================================\n');
fprintf(' MESURE 1 : reaction de iL et Vout a la perturbation de charge\n');
fprintf('=========================================================\n');
FEN_BASE   = [0.014 0.03];
FEN_REACT  = [0.05  0.055];
FEN_FINALE = [0.18  0.20];

idxBase   = (t_f2 >= FEN_BASE(1))   & (t_f2 <= FEN_BASE(2));
idxReact  = (t_f2 >= FEN_REACT(1))  & (t_f2 <= FEN_REACT(2));
idxFinale = (t_f2 >= FEN_FINALE(1)) & (t_f2 <= FEN_FINALE(2));

iL_base   = mean(x_f2(idxBase));
iL_pic    = max(x_f2(idxFenetreActive_f2));
iL_finale = mean(x_f2(idxFinale));
fprintf('iL moyen avant perturbation [%.3f,%.3f]s : %.4f A\n', FEN_BASE(1), FEN_BASE(2), iL_base);
fprintf('iL pic sur toute la fenetre active [0.05,0.07]s        : %.4f A (attendu : superieur a iL_base, R_eff plus faible tire plus de courant)\n', iL_pic);
fprintf('iL moyen en fin de simulation [%.3f,%.3f]s              : %.4f A\n\n', FEN_FINALE(1), FEN_FINALE(2), iL_finale);

vout_base   = mean(y_f2(idxBase));
vout_creux  = min(y_f2(idxReact));
vout_finale = mean(y_f2(idxFinale));
ecart_finale_pct = 100 * (vout_finale - Vref) / Vref;
fprintf('Vout moyen avant perturbation [%.3f,%.3f]s : %.3f V (reference Vref=%.0f V)\n', FEN_BASE(1), FEN_BASE(2), vout_base, Vref);
fprintf('Vout creux sur [%.3f,%.3f]s (tout debut de la fenetre active) : %.3f V\n', FEN_REACT(1), FEN_REACT(2), vout_creux);
fprintf('Vout moyen en fin de simulation [%.3f,%.3f]s                  : %.3f V (ecart a Vref : %+.3f%%)\n\n', ...
    FEN_FINALE(1), FEN_FINALE(2), vout_finale, ecart_finale_pct);
fprintf(['LECTURE : F2(t) diminue R (charge plus lourde), pas d''effet direct sur mu comme F1 -- la signature\n' ...
    'attendue est donc PHYSIQUE, pas une consequence du calcul de commande : iL_pic > iL_base confirme que le\n' ...
    'mecanisme (Series RLC Branch2 + Ideal Switch + Step1/Step2, herite de PID_Classique_Control_load_\n' ...
    'disturbance.slx) est reellement exerce ; un iL_pic proche de iL_base indiquerait que la perturbation n''a\n' ...
    'pas d''effet mesurable, a investiguer avant toute autre conclusion. Le critere retenu pour Vout est le\n' ...
    'meme que pour F1 (retour COMPLET a Vref apres la fin de la fenetre active), avec un creux au lieu d''un\n' ...
    'pic puisque la charge augmente au lieu de la commande.\n\n']);

% =========================================================================
% MESURE 2 : Ki/Kp/Kd a fenetre egale, F2 vs nominal
% =========================================================================
fprintf('=========================================================\n');
fprintf(' MESURE 2 : Ki/Kp/Kd en regime final [0.18,0.20]s -- F2 vs nominal, meme fenetre\n');
fprintf('=========================================================\n');
idxFinaleNom = (t_nom >= FEN_FINALE(1)) & (t_nom <= FEN_FINALE(2));

Ki_finale_f2  = mean(Ki_f2(idxFinale));
Ki_finale_nom = mean(Ki_nom(idxFinaleNom));
Kp_finale_f2  = mean(Kp_f2(idxFinale));
Kp_finale_nom = mean(Kp_nom(idxFinaleNom));
Kd_finale_f2  = mean(Kd_f2(idxFinale));
Kd_finale_nom = mean(Kd_nom(idxFinaleNom));

fprintf(['Comparaison a fenetre egale (%.3f a %.3f s des DEUX cotes) -- pas une reference gardee d''un run a\n' ...
    'StopTime different (meme piege deja documente et evite pour F1) :\n'], FEN_FINALE(1), FEN_FINALE(2));
fprintf('Ki : F2=%.4g   |  nominal=%.4g\n', Ki_finale_f2, Ki_finale_nom);
fprintf('Kp : F2=%.4g   |  nominal=%.4g\n', Kp_finale_f2, Kp_finale_nom);
fprintf('Kd : F2=%.4g   |  nominal=%.4g\n\n', Kd_finale_f2, Kd_finale_nom);
fprintf(['LECTURE : contrairement a F1 (perturbation de commande, qui sollicite directement la zone e=NB de la\n' ...
    'table de regles), F2 est une perturbation physique en amont du calcul d''erreur -- rien ne garantit a priori\n' ...
    'que les gains s''ecartent autant du nominal qu''en F1. Un ecart faible ici n''est PAS un signe d''echec ; un\n' ...
    'Ki bloque pres de zero le serait (meme classe de defaut que le bug d''affamement deja corrige pour F1),\n' ...
    'a verifier explicitement sur le chiffre F2 ci-dessus avant de conclure quoi que ce soit.\n\n']);

% =========================================================================
% MESURE 3 : commande reellement appliquee -- saturation pendant vs hors
% perturbation
% =========================================================================
fprintf('=========================================================\n');
fprintf(' MESURE 3 : mu_fuzzy (signal reellement applique au PWM Generator pour F2)\n');
fprintf('=========================================================\n');
fprintf(['Rappel : contrairement a F1, F2 ne touche jamais les bornes internes de mu (MU_MIN_F2=MU_MAX_F2\n' ...
    '= bornes physiques du nominal, voir Construction_Simulink_Fuzzy_PID_F2.m). "mu_fuzzy" logue ici EST donc\n' ...
    'deja le signal applique, sans distinction brut/sature comme pour F1.\n\n']);
fprintf('mu_fuzzy sur la fenetre active [0.05,0.07]s : min=%.4f  max=%.4f  (bornes physiques : [0.01, 0.99])\n', ...
    min(mu_f2(idxFenetreActive_f2)), max(mu_f2(idxFenetreActive_f2)));
idxHorsPert_f2 = ~idxFenetreActive_f2;
tempsCollePendant  = 100 * mean(mu_f2(idxFenetreActive_f2) >= 0.99 - 1e-6);
tempsColleHorsPert = 100 * mean(mu_f2(idxHorsPert_f2)      >= 0.99 - 1e-6);
tempsColleMaxTotal = 100 * mean(mu_f2 >= 0.99 - 1e-6);
fprintf('Temps colle a 0.99 PENDANT la perturbation [0.05,0.07]s : %.2f%%\n', tempsCollePendant);
fprintf('Temps colle a 0.99 HORS perturbation (reste du run)      : %.2f%%\n', tempsColleHorsPert);
fprintf('Temps colle a 0.99 sur la totalite du run                : %.2f%%\n\n', tempsColleMaxTotal);
fprintf(['LECTURE : la charge augmentant (R_eff plus faible), le convertisseur doit tirer davantage sur son\n' ...
    'rapport cyclique pour maintenir Vout -- un pourcentage PENDANT superieur au pourcentage HORS perturbation\n' ...
    'va dans ce sens (sens oppose a F1, ou le pourcentage PENDANT etait plus bas que hors perturbation, car F1\n' ...
    'diminue le besoin de duty cycle au lieu de l''augmenter). A verifier sur les chiffres ci-dessus, pas a\n' ...
    'supposer.\n\n']);

% =========================================================================
% MESURE 4 : chatter de mu_fuzzy hors perturbation, nominal vs F2 (reprend
% et etend Analyse_mu_F2_vs_Nominal.m en chiffrant l'ecart)
% =========================================================================
fprintf('=========================================================\n');
fprintf(' MESURE 4 : chatter de mu hors perturbation -- nominal vs F2\n');
fprintf('=========================================================\n');
SEUIL_MEDIAN = 0.5;
fenetres = { ...
    'Nominal, hors perturbation [0.014, 0.03]s', t_nom, mu_nom, [0.014 0.03]; ...
    'F2, hors perturbation [0.014, 0.03]s',      t_f2,  mu_f2,  [0.014 0.03]; ...
    'F2, apres la perturbation [0.12, 0.14]s',   t_f2,  mu_f2,  [0.12  0.14]  ...
};
moyenneNominale = NaN;
for i = 1:size(fenetres, 1)
    label = fenetres{i,1}; t = fenetres{i,2}; y = fenetres{i,3}; bornes = fenetres{i,4};
    idx = (t >= bornes(1)) & (t <= bornes(2));
    if ~any(idx)
        fprintf('[%s] : AUCUN point trouve dans cette fenetre.\n\n', label);
        continue;
    end
    yFen = y(idx); tFen = t(idx);
    signeCentre = sign(yFen - SEUIL_MEDIAN); signeCentre(signeCentre == 0) = 1;
    nbFranchissements = sum(abs(diff(signeCentre)) > 0);
    freqHz = (nbFranchissements / 2) / (tFen(end) - tFen(1));
    fprintf('[%s]\n  min=%.4f  max=%.4f  moyenne=%.4f  freq. oscillation estimee ~%.0f Hz\n\n', ...
        label, min(yFen), max(yFen), mean(yFen), freqHz);
    if i == 1
        moyenneNominale = mean(yFen);
    end
end
idxF2HorsPertBase = (t_f2 >= 0.014) & (t_f2 <= 0.03);
moyenneF2HorsPert = mean(mu_f2(idxF2HorsPertBase));
ecartMoyenne = moyenneF2HorsPert - moyenneNominale;
fprintf('Ecart de moyenne (F2 hors perturbation moins nominal) : %+.4f\n', ecartMoyenne);
if abs(ecartMoyenne) > 0.1
    fprintf(['ATTENTION -- CET ECART N''EST PAS NEGLIGEABLE : contrairement a ce qu''implique le mecanisme de F2\n' ...
        '(bornes internes de mu inchangees vs nominal), mu_fuzzy hors perturbation s''ecarte sensiblement du\n' ...
        'nominal. A investiguer avant de documenter F2 comme "identique au nominal hors perturbation" dans le\n' ...
        'memoire -- ne pas reprendre telle quelle la conclusion d''Analyse_mu_F2_vs_Nominal.m sans ce chiffre.\n']);
else
    fprintf(['Ecart negligeable : le comportement de mu_fuzzy hors perturbation reste comparable au nominal,\n' ...
        'ce qui confirme numeriquement (et non plus seulement par lecture visuelle de captures d''ecran) la\n' ...
        'conclusion deja avancee par Analyse_mu_F2_vs_Nominal.m.\n']);
end

% =========================================================================
% MESURE 5 : poids reel de Kp*xc1/Ki*xc2/Kd*xc3 dans dmu, nominal ET F2, a
% fenetre egale [0.18,0.20]s -- meme formule (majorant) que l'ETAPE 4sexies
% de Test_Validation_Fuzzy_PID_Nominal.m, qui ne l'avait verifiee QU'une
% fois, en regime nominal, a [0.98,1.00]s. Meme demarche que la MESURE 6
% de Analyse_Validation_Fuzzy_PID_F1.m.
% =========================================================================
fprintf('=========================================================\n');
fprintf(' MESURE 5 : poids de Kp*xc1/Ki*xc2/Kd*xc3 dans dmu -- nominal et F2, meme fenetre [0.18,0.20]s\n');
fprintf('=========================================================\n');
idxXc1Nom = (t_xc1_nom >= FEN_FINALE(1)) & (t_xc1_nom <= FEN_FINALE(2));
idxXc2Nom = (t_xc2_nom >= FEN_FINALE(1)) & (t_xc2_nom <= FEN_FINALE(2));
idxXc3Nom = (t_xc3_nom >= FEN_FINALE(1)) & (t_xc3_nom <= FEN_FINALE(2));
idxXc1F2  = (t_xc1_f2  >= FEN_FINALE(1)) & (t_xc1_f2  <= FEN_FINALE(2));
idxXc2F2  = (t_xc2_f2  >= FEN_FINALE(1)) & (t_xc2_f2  <= FEN_FINALE(2));
idxXc3F2  = (t_xc3_f2  >= FEN_FINALE(1)) & (t_xc3_f2  <= FEN_FINALE(2));

decompositions = { ...
    'NOMINAL', Kp_finale_nom, Ki_finale_nom, Kd_finale_nom, ...
        max(abs(xc1_nom(idxXc1Nom))), max(abs(xc2_nom(idxXc2Nom))), max(abs(xc3_nom(idxXc3Nom))); ...
    'F2',      Kp_finale_f2,  Ki_finale_f2,  Kd_finale_f2, ...
        max(abs(xc1_f2(idxXc1F2))),  max(abs(xc2_f2(idxXc2F2))),  max(abs(xc3_f2(idxXc3F2)))  ...
};
for i = 1:size(decompositions, 1)
    label = decompositions{i,1};
    kp_moy = decompositions{i,2}; ki_moy = decompositions{i,3}; kd_moy = decompositions{i,4};
    xc1_absmax = decompositions{i,5}; xc2_absmax = decompositions{i,6}; xc3_absmax = decompositions{i,7};
    contrib_kp = abs(kp_moy * xc1_absmax);
    contrib_ki = abs(ki_moy * xc2_absmax);
    contrib_kd = abs(kd_moy * xc3_absmax);
    contrib_totale = contrib_kp + contrib_ki + contrib_kd;
    fprintf('[%s]\n', label);
    fprintf('  Kp1*xc1 (majorant) : %.4e  (%5.2f%% du total)\n', contrib_kp, 100*contrib_kp/contrib_totale);
    fprintf('  Ki1*xc2 (majorant) : %.4e  (%5.2f%% du total)\n', contrib_ki, 100*contrib_ki/contrib_totale);
    fprintf('  Kd1*xc3 (majorant) : %.4e  (%5.2f%% du total)\n', contrib_kd, 100*contrib_kd/contrib_totale);
    if contrib_kd / contrib_totale < 0.01
        fprintf('  OK : contribution de Kd < 1%% du total, seuil de negligeabilite retenu au memoire respecte.\n\n');
    else
        fprintf(['  ATTENTION : contribution de Kd >= 1%% du total pour ce scenario -- le seuil de negligeabilite\n' ...
            '  retenu (verifie uniquement en regime nominal a [0.98,1.00]s dans Test_Validation_Fuzzy_PID_\n' ...
            '  Nominal.m) ne tient PAS ici sans reserve ; a documenter explicitement avant toute affirmation\n' ...
            '  generale sur la negligeabilite de Kd au memoire.\n\n']);
    end
end
fprintf(['LECTURE : si Ki*xc2 domine et Kp*xc1/Kd*xc3 restent sous 1%% dans les DEUX lignes ci-dessus, la\n' ...
    'hierarchie de contribution decrite a la section 6.2 (a partir du seul regime nominal) generalise bien a F2\n' ...
    '; sinon la section 6.2 doit etre nuancee comme scenario-dependante.\n']);

function [t, vals] = extraire_temps_valeurs(donnee, nomAffiche)
% Identique a la fonction du meme nom dans Test_Validation_Fuzzy_PID_
% Nominal.m, Analyse_mu_F2_vs_Nominal.m et Analyse_Validation_Fuzzy_PID_
% F1.m -- extraction robuste quel que soit le SaveFormat reel du bloc
% "To Workspace".
    if isa(donnee, 'timeseries')
        t = donnee.Time;
        vals = squeeze(donnee.Data);
    elseif isstruct(donnee) && isfield(donnee, 'time') && isfield(donnee, 'signals')
        t = donnee.time;
        vals = squeeze(donnee.signals.values);
    elseif isnumeric(donnee)
        vals = donnee;
        if evalin('base', 'exist(''tout'', ''var'')')
            t = evalin('base', 'tout');
        else
            error(['"%s" est un tableau numerique brut (SaveFormat=Array) mais aucune variable ' ...
                   '"tout" n''a ete trouvee pour lui associer un axe de temps.'], nomAffiche);
        end
    else
        error('Format de "%s" non reconnu (classe : %s) -- extraction impossible sans inspection manuelle.', ...
            nomAffiche, class(donnee));
    end
    vals = vals(:);
    t = t(:);
end
