%% Analyse_mu_F2_vs_Nominal.m
% =========================================================================
%   MESURE NUMERIQUE DU COMPORTEMENT DE mu (commande) -- F2 vs NOMINAL
% =========================================================================
%
% POURQUOI CE SCRIPT : les captures d'ecran zoomees de Scope_Commande_Fuzzy
% montrent mu balayer presque toute la plage [0.01, 0.99] de facon dense et
% repetee, y compris HORS de la fenetre de perturbation F2 (verifie sur
% [0.014, 0.03]s, bien avant 0.05s). Ce n'est donc pas un effet de F2 --
% mais on ne sait pas encore si ce comportement existe DEJA dans le
% nominal (Fuzzy_PID_Control.slx, deja valide par ailleurs) ou s'il est
% propre a la construction de F2. Comparer des captures d'ecran zoomees a
% la main est lent et imprecis -- ce script mesure directement les
% valeurs loguees (variable "mu_fuzzy", SaveFormat=Timeseries, meme
% convention que Test_Validation_Fuzzy_PID_Nominal.m) sur les deux
% modeles et sur plusieurs fenetres, plutot que de multiplier les
% captures d'ecran.
%
% IMPORTANT : ce script se contente de MESURER et d'AFFICHER des chiffres.
% Il ne modifie aucun fichier .slx et ne tranche aucune conclusion a la
% place de l'utilisateur -- les chiffres sont a lire et interpreter avec
% le meme niveau d'exigence que les captures d'ecran precedentes.
%
% PIEGE EVITE DELIBEREMENT : les deux modeles utilisent le meme nom de
% variable de sortie ("mu_fuzzy", copiee depuis le nominal par
% construction). Simuler les deux modeles PUIS extraire les deux
% variables a la fin ecraserait la premiere par la seconde. Chaque
% extraction est donc faite immediatement apres SA PROPRE simulation,
% jamais groupee a la fin.
%
% Reutilise "extraire_temps_valeurs", identique a celle de
% Test_Validation_Fuzzy_PID_Nominal.m (extraction robuste quel que soit le
% SaveFormat reel du bloc "To Workspace").
% =========================================================================

clear; clc;

% CORRECTION (erreur reelle a l'execution -- "Unrecognized function or
% variable 'fisFuzzyPID'") : le clear ci-dessus vide le workspace de base
% de "fisFuzzyPID", or le bloc "FLC_Fuzzy_PID" des DEUX modeles reference
% cette variable par son parametre FIS (voir Construction_Simulink_
% Fuzzy_PID.m, meme mecanisme). sim() ne peut pas evaluer ce parametre
% sans elle. Meme fichier .mat et meme nom de variable que la
% construction d'origine -- rechargee ici a l'identique, avant toute
% simulation.
if ~exist('fuzzy_pid_buck.mat', 'file')
    error(['Fichier fuzzy_pid_buck.mat introuvable sur le chemin MATLAB courant. ' ...
           'C''est le meme fichier que celui utilise par Construction_Simulink_' ...
           'Fuzzy_PID.m -- placez-vous dans le dossier qui le contient (ou ajoutez-le ' ...
           'au chemin) avant de relancer ce script.']);
end
d_fis = load('fuzzy_pid_buck.mat');
assignin('base', 'fisFuzzyPID', d_fis.fis);
fprintf('"fisFuzzyPID" recharge dans le workspace de base depuis fuzzy_pid_buck.mat (%d regles).\n\n', ...
    numel(d_fis.fis.Rules));

mdlNominal = 'Fuzzy_PID_Control';
mdlF2      = 'Fuzzy_PID_Control_F2';

SEUIL_MEDIAN = 0.5;   % simple reperage au milieu de [0.01,0.99] pour
                       % compter les oscillations pleine echelle -- pas
                       % une borne physique du systeme

% -------------------------------------------------------------------
% ETAPE 1 : nominal -- simulation puis extraction IMMEDIATE de mu_fuzzy
% -------------------------------------------------------------------
fprintf('=========================================================\n');
fprintf(' NOMINAL (%s)\n', mdlNominal);
fprintf('=========================================================\n');
if isempty(which([mdlNominal '.slx']))
    error(['Fichier "%s.slx" introuvable sur le chemin MATLAB.'], mdlNominal);
end
load_system(mdlNominal);
% CORRECTION (erreur reelle : sim() reussit mais "mu_fuzzy" reste introuvable
% ensuite) -- meme mecanisme que Test_Validation_Fuzzy_PID_Nominal.m (ETAPE 2,
% commentaire "regle de construction n=8") : ReturnWorkspaceOutputs doit etre
% reaffirme explicitement AVANT CHAQUE sim(), jamais suppose deja correct sur
% le fichier charge -- sinon les blocs "To Workspace" peuvent finir dans un
% objet SimulationOutput non capture au lieu du workspace de base.
set_param(mdlNominal, 'ReturnWorkspaceOutputs', 'off');
fprintf('Simulation de %s...\n', mdlNominal);
sim(mdlNominal);
[t_nom, mu_nom] = extraire_temps_valeurs(evalin('base', 'mu_fuzzy'), 'mu_fuzzy (nominal)');
close_system(mdlNominal, 0);
fprintf('mu_fuzzy (nominal) extrait : %d points, de t=%.6g a t=%.6g.\n\n', ...
    numel(mu_nom), t_nom(1), t_nom(end));

% -------------------------------------------------------------------
% ETAPE 2 : F2 -- simulation puis extraction IMMEDIATE de mu_fuzzy
% -------------------------------------------------------------------
fprintf('=========================================================\n');
fprintf(' F2 (%s)\n', mdlF2);
fprintf('=========================================================\n');
if isempty(which([mdlF2 '.slx']))
    error(['Fichier "%s.slx" introuvable sur le chemin MATLAB.'], mdlF2);
end
load_system(mdlF2);
set_param(mdlF2, 'ReturnWorkspaceOutputs', 'off');   % voir commentaire au meme endroit pour le nominal
fprintf('Simulation de %s...\n', mdlF2);
sim(mdlF2);
[t_f2, mu_f2] = extraire_temps_valeurs(evalin('base', 'mu_fuzzy'), 'mu_fuzzy (F2)');
close_system(mdlF2, 0);
fprintf('mu_fuzzy (F2) extrait : %d points, de t=%.6g a t=%.6g.\n\n', ...
    numel(mu_f2), t_f2(1), t_f2(end));

% -------------------------------------------------------------------
% ETAPE 3 : mesures par fenetre, sur les DEUX modeles
% -------------------------------------------------------------------
fprintf('=========================================================\n');
fprintf(' MESURES\n');
fprintf('=========================================================\n');

fenetres = { ...
    'Nominal, hors perturbation [0.014, 0.03]s', t_nom, mu_nom, [0.014 0.03]; ...
    'F2, hors perturbation [0.014, 0.03]s',      t_f2,  mu_f2,  [0.014 0.03]; ...
    'F2, PENDANT la perturbation [0.05, 0.07]s', t_f2,  mu_f2,  [0.05  0.07]; ...
    'F2, apres la perturbation [0.12, 0.14]s',   t_f2,  mu_f2,  [0.12  0.14]  ...
};

for i = 1:size(fenetres, 1)
    label = fenetres{i,1};
    t = fenetres{i,2};
    y = fenetres{i,3};
    bornes = fenetres{i,4};

    idx = (t >= bornes(1)) & (t <= bornes(2));
    if ~any(idx)
        fprintf('[%s] : AUCUN point trouve dans cette fenetre -- verifiez StopTime/les bornes.\n\n', label);
        continue;
    end
    yFen = y(idx);
    tFen = t(idx);

    mn = min(yFen);
    mx = max(yFen);
    moy = mean(yFen);
    fracBas = 100 * mean(yFen < SEUIL_MEDIAN);

    % Estimation de la frequence d'oscillation : nombre de franchissements
    % du seuil median, divise par 2 (aller-retour = 1 cycle) et par la
    % duree de la fenetre.
    signeCentre = sign(yFen - SEUIL_MEDIAN);
    signeCentre(signeCentre == 0) = 1;
    nbFranchissements = sum(abs(diff(signeCentre)) > 0);
    dureeFen = tFen(end) - tFen(1);
    freqOscillationHz = (nbFranchissements / 2) / dureeFen;

    fprintf('[%s]\n', label);
    fprintf('  min=%.4f  max=%.4f  moyenne=%.4f\n', mn, mx, moy);
    fprintf('  temps sous %.2f : %.1f%%\n', SEUIL_MEDIAN, fracBas);
    fprintf('  franchissements du seuil median : %d -> frequence d''oscillation estimee ~%.0f Hz\n\n', ...
        nbFranchissements, freqOscillationHz);
end

fprintf('=========================================================\n');
fprintf(' LECTURE\n');
fprintf('=========================================================\n');
fprintf(['Si "Nominal, hors perturbation" et "F2, hors perturbation" donnent des\n' ...
         'chiffres du meme ordre (min proche de zero, memes frequences), ce\n' ...
         'balayage pleine echelle est un trait de fond du Fuzzy-PID deja present\n' ...
         'dans le nominal valide -- pas quelque chose introduit par F2.\n' ...
         'Si "F2, PENDANT la perturbation" et "F2, apres la perturbation" ne\n' ...
         'different pas non plus significativement de "F2, hors perturbation",\n' ...
         'la perturbation elle-meme n''aggrave pas ce phenomene -- il est constant\n' ...
         'sur toute la duree de la simulation, quelle que soit la fenetre.\n']);

function [t, vals] = extraire_temps_valeurs(donnee, nomAffiche)
% Identique a la fonction du meme nom dans Test_Validation_Fuzzy_PID_
% Nominal.m -- extraction robuste quel que soit le SaveFormat reel du
% bloc "To Workspace" (Timeseries, Structure/StructureWithTime, ou Array
% brut + temps separe dans "tout").
    if isa(donnee, 'timeseries')
        t = donnee.Time;
        vals = squeeze(donnee.Data);
    elseif isstruct(donnee) && isfield(donnee, 'time') && isfield(donnee, 'signals')
        t = donnee.time;
        vals = squeeze(donnee.signals.values);
    elseif isnumeric(donnee)
        vals = donnee;
        if evalin('base', 'exist(''tout'', ''var'')')
            t = evalin('base', 'tout');
        else
            error(['"%s" est un tableau numerique brut (SaveFormat=Array) mais aucune variable ' ...
                   '"tout" n''a ete trouvee pour lui associer un axe de temps. Ouvrez le bloc ' ...
                   '"To Workspace" concerne et mettez son SaveFormat sur "Timeseries" avant de ' ...
                   'relancer ce script.'], nomAffiche);
        end
    else
        error('Format de "%s" non reconnu (classe : %s) -- extraction impossible sans inspection manuelle.', ...
            nomAffiche, class(donnee));
    end
    vals = vals(:);
    t = t(:);
end
