%% Construction_Simulink_Fuzzy_PID.m
% =========================================================================
%                                                                         %
%   CONSTRUCTION DU MODELE FUZZY-PID A PARTIR DE                        %
%   PID_Classique_Control.slx                                           %
%                                                                         %
% =========================================================================
%
% CE QUE FAIT CE SCRIPT
% ----------------------
% Part de VOTRE fichier PID_Classique_Control.slx (modele a plat, une
% seule boucle fermee : Vref -> Sum1 -> PID Controller -> PWM Generator
% (DC-DC) -> Mosfet -> circuit physique L=50mH/C=40uF/R=5 Ohm -> mesures
% Vin/Vout/iL -> Vout referme la boucle sur Sum1). Ce script :
%   1) Duplique ce fichier en Fuzzy_PID_Control.slx (l'original n'est
%      jamais modifie).
%   2) Supprime le bloc "PID Controller" natif ET le bloc "Sum1" (devenu
%      sans aucune fonction des que "PID Controller" disparait). Le bloc
%      "Constant1" (Vref=100) est CONSERVE mais reconnecte : il alimente
%      desormais directement "Calcul_Erreur_Fuzzy" comme une vraie entree
%      Vref, au lieu de rester orphelin a cote d'un Vref code en dur et
%      invisible dans le code genere -- Vref reste ainsi un signal visible
%      et tracable sur le schema (voir la note complete a ce sujet plus
%      bas, section "Bloc 1"). Zero impact numerique (100 reste 100),
%      uniquement un gain de clarte pour un schema destine au memoire.
%   3) Construit la branche Fuzzy-PID : un bloc de calcul d'erreur, le
%      bloc Simulink natif "Fuzzy Logic Controller" (charge le FIS deja
%      construit par construction_FIS_Fuzzy_PID.m), et un bloc
%      d'incrementation des gains, cable exactement comme le prevoit la
%      loi de commande partagee avec ELM-PID (eq. 13-14 de Lu et al.).
%
% CE QUE CE SCRIPT NE FAIT PAS (perimetre confirme)
% ---------------------------------------------------
% Pas de branche de comparaison PID-classique/Fuzzy-PID cote a cote, pas
% de scopes a 2 entrees comme pour ELM-PID vs boucle ouverte. Une seule
% boucle fermee, pilotee par Fuzzy-PID. La comparaison finale entre
% methodes est un chapitre a part, qui reprendra de toute facon
% completement la structure de comparaison ELM-PID dans une autre
% discussion.
%
% IDEMPOTENCE -- CORRECTION IMPORTANTE PAR RAPPORT A LA VERSION PRECEDENTE
% --------------------------------------------------------------------------
% La premiere version de ce script ne gardait qu'UNE SEULE garde globale
% (presence du bloc "Loi_Incrementale_Fuzzy") pour decider de tout
% reconstruire ou rien. Consequence observee en pratique : si la
% construction s'arrete avant d'atteindre cette etape (ex. le bloc
% Fuzzy Logic Controller ajoute a la main apres un echec d'add_block),
% relancer le script ignorait cette garde et retentait TOUT depuis le
% debut, provoquant "Block 'Echantillonneur_Fuzzy' already exists."
% Chaque bloc a maintenant SA PROPRE garde individuelle (isempty(find_
% system(...))) : le script peut etre relance autant de fois que
% necessaire, quel que soit l'endroit ou une execution precedente s'est
% arretee, sans jamais tenter de recreer ce qui existe deja.
%
% CORRECTIONS PAR RAPPORT A CE QUI AVAIT ETE DIT PLUS TOT DANS CE PROJET
% ------------------------------------------------------------------------
% - Les gains du PID classique (P=0.110068, I=54.2388, D=2.48331e-05,
%   lus directement dans PID_Classique_Control.slx) portent la mention
%   "Transfer Function Based (PID Tuner App)" dans les metadonnees du
%   bloc, PAS Ziegler-Nichols. Ce script ne s'en sert de toute facon pas
%   (voir plus bas), mais la terminologie est a corriger dans le
%   memoire si necessaire.
% - MU_MIN/MU_MAX pour ELM-PID sont en realite 0.01/0.99 (identiques a
%   la saturation externe), pas [-0.8, 1.8] comme indique par erreur
%   dans une reponse precedente de cette conversation. Les valeurs
%   utilisees ci-dessous sont les vraies, lues dans le code source.
%
% PREREQUIS
% ---------
%   - PID_Classique_Control.slx dans le meme dossier que ce script.
%   - fuzzy_pid_buck.mat dans le meme dossier (produit par
%     construction_FIS_Fuzzy_PID.m -- contient l'objet fis et les
%     facteurs d'echelle Ke, Kec, Kpu, Kiu, Kdu).
% =========================================================================

clear; clc;

% -------------------------------------------------------------------
% PARAMETRES PHYSIQUES (identiques a ceux lus dans PID_Classique_Control.slx :
% Vin=200V, Vref=100V, T=5us, Fsw=22kHz -- voir DC Voltage Source, Constant1,
% powergui et PWM Generator (DC-DC) du fichier original)
% -------------------------------------------------------------------
Vin  = 200;
Vref = 100;
T    = 5e-6;

fprintf('=== Parametres physiques (identiques a PID_Classique_Control.slx) ===\n');
fprintf('Vin=%.3g V  Vref=%.3g V  T=%.3g s\n', Vin, Vref, T);

% -------------------------------------------------------------------
% CHARGEMENT DU FIS ET DES FACTEURS D'ECHELLE
% (produits par construction_FIS_Fuzzy_PID.m -- NON reconstruits ici)
% -------------------------------------------------------------------
if ~exist('fuzzy_pid_buck.mat', 'file')
    error(['Fichier fuzzy_pid_buck.mat introuvable. Executez d''abord ' ...
           'construction_FIS_Fuzzy_PID.m, puis copiez le .mat produit ' ...
           'dans ce meme dossier.']);
end
d_fis = load('fuzzy_pid_buck.mat');
fisFuzzyPID = d_fis.fis;
Ke  = d_fis.Ke;    % placeholder = 1, a calibrer
Kec = d_fis.Kec;   % placeholder = 1, a calibrer
Kpu = d_fis.Kpu;   % placeholder = 1, a calibrer
Kiu = d_fis.Kiu;   % placeholder = 1, a calibrer
Kdu = d_fis.Kdu;   % placeholder = 1, a calibrer

fprintf('\nFIS charge : %d regles, facteurs d''echelle Ke=%.3g Kec=%.3g Kpu=%.3g Kiu=%.3g Kdu=%.3g (placeholders)\n', ...
    numel(fisFuzzyPID.Rules), Ke, Kec, Kpu, Kiu, Kdu);

% Rendre le fis accessible au workspace de base : le bloc natif "Fuzzy
% Logic Controller" reference son FIS par un NOM DE VARIABLE du
% workspace de base au moment de la simulation, pas par une valeur
% passee en parametre du script -- il faut donc l'y placer explicitement.
assignin('base', 'fisFuzzyPID', fisFuzzyPID);

% -------------------------------------------------------------------
% BORNES DE L'ALGORITHME INCREMENTAL (eq. 13-14) -- VALEURS FINALES,
% VALIDEES EMPIRIQUEMENT. L'historique complet des tests qui ont mene a
% ces valeurs (cycle limite de Ki a KI_MAX=100, diagnostic KI_MAX
% 50->1000->50000, saga de la table de regles du FIS, diagnostic
% KP_MAX 50->1000) est documente dans la memoire de projet et repris au
% chapitre 4 du memoire -- il n'est plus reproduit ici pour garder ce
% script lisible.
% -------------------------------------------------------------------
% KI_MAX=50000 : ELM-PID, sur le meme circuit et la meme loi incrementale
% (eq. 13-14, meme Te), converge naturellement vers Ki~11581 sous ce
% plafond -- repris ici comme valeur motivee. Confirme non limitant une
% fois la table de regles du FIS corrigee (le cycle limite de mu observe
% initialement venait d'un defaut de regle pres de l'equilibre, pas d'un
% plafond mal calibre).
% KP_MAX=50 : plafond ELM-PID d'origine. Diagnostic dedie (relaxation
% temporaire a 1000) : PAS d'equilibre naturel sous ce plafond --
% l'increment brut dKp reste constant quelle que soit la valeur deja
% atteinte par Kp, signature d'un windup de table non elimine (meme
% famille que Kd, voir construction_FIS_Fuzzy_PID.m). KP_MAX=50 est donc
% retenu comme plafond deliberement choisi (pas un equilibre "trouve"),
% sa contribution a dmu restant mesuree negligeable tant qu'il reste
% raisonnable.
% KD_MAX=0.01 : inchange depuis ELM-PID.
KP_MAX = 50; KI_MAX = 50000; KD_MAX = 0.01;
MU_MIN = 0.01; MU_MAX = 0.99;   % identiques a la saturation externe du PID classique ET d'ELM-PID -- une seule saturation, pas deux paliers

fprintf('Bornes retenues comme point de depart : KP_MAX=%.4g KI_MAX=%.4g KD_MAX=%.4g MU=[%.2g,%.2g]\n', ...
    KP_MAX, KI_MAX, KD_MAX, MU_MIN, MU_MAX);

% =====================================================================
% GENERATION DU CODE DES 2 BLOCS MATLAB FUNCTION
% =====================================================================

% ---- Bloc 1 : calcul de l'erreur normalisee et de ses combinaisons ----
% Meme convention qu'ELM-PID : ecn = (Vref-y)/Vin. ecn sert aussi de xc2
% en aval (identique, pas besoin d'une 4e sortie redondante).
%
% CORRECTION (Vref en entree, plus en litteral code en dur) : la premiere
% version de ce bloc codait Vref=100 en dur a l'interieur du code genere,
% pendant que le bloc "Constant1" (valeur 100, herite de l'ancien PID
% classique) restait visible sur le schema mais totalement deconnecte --
% une source de confusion pour quiconque relit le schema (Constant1
% semble alimenter quelque chose, mais la vraie valeur utilisee est
% invisible, planquee dans le code du bloc MATLAB Function). Vref est
% maintenant une VRAIE entree de ce bloc, alimentee par Constant1 -- zero
% impact numerique (100 reste 100), mais Vref redevient un signal visible
% et tracable sur le schema plutot qu'un nombre magique cache. Vin reste
% code en dur : contrairement a Vref, il n'existe aucun bloc scalaire
% equivalent deja present dans le modele a reconnecter (Vin est fourni au
% circuit physique par une "DC Voltage Source", pas par un signal de
% calcul disponible ici).
code_erreur = sprintf([ ...
'function [ecn, xc1, xc3] = calcul_erreur_fuzzy(y, Vref)\n' ...
'%%#codegen\n' ...
'%% Erreur normalisee et ses combinaisons pour la loi PID incrementale\n' ...
'%% (eq. 13, meme convention que le controleur ELM-PID : ecn=(Vref-y)/Vin).\n' ...
'%% ecn joue aussi le role de xc2 pour le bloc en aval. Vref est fourni en\n' ...
'%% entree (cable depuis "Constant1"), Vin reste un parametre physique fixe.\n' ...
'\n' ...
'persistent ecn1 ecn2 initialise\n' ...
'\n' ...
'Vin = %.10g;\n' ...
'\n' ...
'if isempty(initialise)\n' ...
'    ecn1 = Vref/Vin;\n' ...
'    ecn2 = Vref/Vin;\n' ...
'    initialise = true;\n' ...
'end\n' ...
'\n' ...
'ecn = (Vref - y) / Vin;\n' ...
'xc1 = ecn - ecn1;\n' ...
'xc3 = ecn - 2*ecn1 + ecn2;\n' ...
'\n' ...
'ecn2 = ecn1;\n' ...
'ecn1 = ecn;\n' ...
'end\n' ...
], Vin);

fid = fopen('code_calcul_erreur_fuzzy.txt', 'w');
fprintf(fid, '%s', code_erreur);
fclose(fid);

% ---- Bloc 2 : loi PID incrementale + gains fournis par la FIS ----
% Identique a eq. 13-14 d'ELM-PID, SANS terme de moment (eq. 18 d'ELM-PID
% en comporte un : alpha*(Kp(k-1)-Kp(k-2)) -- ecart assume, deja
% justifie : ce terme accelere la convergence d'une descente de
% gradient, une table de regles n'a rien a accelerer). Consequence
% directe : pas besoin de garder Kp2/Ki2/Kd2 en memoire, seulement les
% valeurs precedentes (Kp1/Ki1/Kd1) -- un etat plus simple qu'ELM-PID,
% pas un oubli.
code_loi = sprintf([ ...
'function [mu, Kp, Ki, Kd] = loi_incrementale_fuzzy(xc2, xc1, xc3, dKp, dKi, dKd)\n' ...
'%%#codegen\n' ...
'%% Loi de commande PID incrementale (eq. 13-14, Lu et al.), gains fournis\n' ...
'%% par la FIS (bloc Fuzzy Logic Controller) plutot que par descente de\n' ...
'%% gradient. Pas de terme de moment (ecart assume vs ELM-PID, eq. 18) :\n' ...
'%% une table de regles n''a pas de trajectoire d''apprentissage a accelerer.\n' ...
'\n' ...
'persistent Kp1 Ki1 Kd1 mu1 initialise\n' ...
'\n' ...
'KP_MAX = %.10g; KI_MAX = %.10g; KD_MAX = %.10g;\n' ...
'MU_MIN = %.10g; MU_MAX = %.10g;\n' ...
'\n' ...
'if isempty(initialise)\n' ...
'    Kp1 = 0; Ki1 = 0; Kd1 = 0;\n' ...
'    mu1 = 0.5;\n' ...
'    initialise = true;\n' ...
'end\n' ...
'\n' ...
'%% ---- Commande PID incrementale (equation 13-14) : utilise les gains\n' ...
'%% DU PAS PRECEDENT (Kp1, Ki1, Kd1 = Kp(k-1) etc.), exactement comme\n' ...
'%% l''equation 13 de Lu et al. : dmu(k) = Kp(k-1)*xc1(k) + Ki(k-1)*xc2(k)\n' ...
'%% + Kd(k-1)*xc3(k). NE PAS utiliser les gains tout juste recalcules a\n' ...
'%% ce meme pas : ce serait une boucle de retroaction differente de celle\n' ...
'%% specifiee par l''equation, sans le decalage d''un pas prevu par la loi\n' ...
'%% incrementale d''origine (bug corrige : la premiere version de ce bloc\n' ...
'%% calculait Kp/Ki/Kd du pas courant AVANT de les utiliser dans dmu,\n' ...
'%% au lieu d''utiliser Kp1/Ki1/Kd1).\n' ...
'dmu = Kp1*xc1 + Ki1*xc2 + Kd1*xc3;\n' ...
'mu  = min(MU_MAX, max(MU_MIN, mu1 + dmu));\n' ...
'\n' ...
'%% ---- Mise a jour des gains pour le pas SUIVANT, a partir de\n' ...
'%% l''increment fourni par la FIS a ce pas-ci (Kp,Ki >= 0 -- un gain ne\n' ...
'%% change pas de sens physique --, Kd borne symetriquement) ----\n' ...
'Kp = min(KP_MAX, max(0, Kp1 + dKp));\n' ...
'Ki = min(KI_MAX, max(0, Ki1 + dKi));\n' ...
'Kd = min(KD_MAX, max(-KD_MAX, Kd1 + dKd));\n' ...
'\n' ...
'%% ---- Decalage des historiques pour le pas suivant ----\n' ...
'Kp1 = Kp; Ki1 = Ki; Kd1 = Kd; mu1 = mu;\n' ...
'end\n' ...
], KP_MAX, KI_MAX, KD_MAX, MU_MIN, MU_MAX);

fid = fopen('code_loi_incrementale_fuzzy.txt', 'w');
fprintf(fid, '%s', code_loi);
fclose(fid);
fprintf('\nCode des 2 blocs genere : code_calcul_erreur_fuzzy.txt, code_loi_incrementale_fuzzy.txt\n');

% =====================================================================
% CONSTRUCTION DU MODELE SIMULINK
% =====================================================================
modele_original = 'PID_Classique_Control';
mdl = 'Fuzzy_PID_Control';

if ~exist([modele_original '.slx'], 'file')
    error('Fichier %s.slx introuvable. Placez-le dans le meme dossier que ce script.', modele_original);
end
if bdIsLoaded(modele_original); close_system(modele_original, 0); end

% Ferme aussi une eventuelle instance de "mdl" deja en memoire, AVANT de
% decider s'il faut copier ou reutiliser le fichier. Sans ca, MATLAB garde
% le modele charge d'une execution a l'autre dans la meme session : meme
% apres avoir supprime Fuzzy_PID_Control.slx et en avoir recopie un neuf
% depuis PID_Classique_Control.slx, load_system(mdl) reutilisait l'ancien
% modele deja en memoire au lieu de lire le fichier fraichement copie sur
% le disque -- ce qui produisait un modele en memoire "perime" par
% rapport au fichier reel, et faisait echouer save_system en fin de
% script avec "has changed on disk since it was loaded". Fermer sans
% sauvegarder ici garantit que load_system lit toujours le vrai fichier.
if bdIsLoaded(mdl); close_system(mdl, 0); end

% Copie SEULEMENT si la destination n'existe pas encore -- meme
% precaution que dans le script ELM-PID : sinon, relancer ce script
% ecraserait a chaque fois vos eventuelles corrections manuelles sur
% Fuzzy_PID_Control.slx.
if ~exist([mdl '.slx'], 'file')
    copyfile([modele_original '.slx'], [mdl '.slx']);
    fprintf('\n%s.slx cree (copie de %s.slx, original non modifie).\n', mdl, modele_original);
else
    fprintf('\n%s.slx existe deja -- reutilise (pas de re-copie).\n', mdl);
end
load_system(mdl);

% Nom exact du bloc PWM, avec son VRAI retour a la ligne (meme
% precaution que le script ELM-PID : jamais de texte litteral direct
% pour ce nom).
nom_pwm = sprintf('PWM Generator\n(DC-DC)');

% -------------------------------------------------------------------
% ETAPE A : suppression du bloc "PID Controller" et de ses lignes
% -------------------------------------------------------------------
% delete_block supprime automatiquement les lignes connectees a ses
% ports -- pas besoin de les supprimer une par une. Deja idempotent par
% construction (verifie en pratique : "deja absent -- rien a supprimer"
% au second passage). Sum1 est traite juste apres (supprime, devenu sans
% fonction) ; Constant1 est traite ensuite (conserve et reconnecte).
if ~isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'PID Controller'))
    delete_block([mdl '/PID Controller']);
    fprintf('Bloc "PID Controller" supprime (avec ses lignes).\n');
else
    fprintf('Bloc "PID Controller" deja absent -- rien a supprimer.\n');
end

% SUM1 : REELLEMENT MORT, SUPPRIME (pas seulement sa ligne de sortie).
% Sum1 calculait Vref-Vout pour l'ancien "PID Controller" ; sa sortie n'a
% plus aucun consommateur, et son unique role (transporter Constant1 vers
% l'aval) est repris directement par le cablage Constant1->Calcul_Erreur_
% Fuzzy plus bas -- le garder n'aurait plus aucune fonction, seulement de
% la confusion sur le schema. delete_block gere lui-meme la suppression
% de ses lignes connectees (l'entree Vout et la ligne vers Constant1).
if ~isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Sum1'))
    delete_block([mdl '/Sum1']);
    fprintf('Bloc "Sum1" supprime (plus aucune fonction dans l''architecture Fuzzy-PID -- voir note ci-dessus).\n');
else
    fprintf('Bloc "Sum1" deja absent -- rien a supprimer.\n');
end

% CONSTANT1 (Vref) : VERIFIE, PAS SUPPOSE -- avant de le reconnecter
% ailleurs (voir ETAPE B/E), on verifie explicitement que sa valeur
% correspond bien au Vref utilise par ce script, plutot que de faire
% confiance a un heritage silencieux de PID_Classique_Control.slx.
if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Constant1'))
    error(['Bloc "Constant1" introuvable dans %s -- attendu comme source de Vref ' ...
           '(herite de PID_Classique_Control.slx). Verifiez le fichier source.'], mdl);
end
valConstant1 = str2double(get_param([mdl '/Constant1'], 'Value'));
if abs(valConstant1 - Vref) > 1e-9
    error(['"Constant1" vaut %.10g, different du Vref=%.10g utilise par ce script. ' ...
           'Ne pas cabler aveuglement : corrigez l''un ou l''autre avant de continuer.'], valConstant1, Vref);
end
fprintf('Bloc "Constant1" verifie : valeur %.10g conforme a Vref -- conserve et reconnecte (voir ETAPE B/E).\n', valConstant1);

% PURGE DES BRANCHES FANTOMES LAISSEES PAR LA SUPPRESSION DE SUM1
% -----------------------------------------------------------------
% DIAGNOSTIC POSE SUR LE FICHIER REEL (pas une hypothese) : inspection
% directe du XML interne du .slx envoye par l'utilisateur
% (simulink/systems/system_root.xml, un .slx etant une archive zip). Sum1
% avait 2 entrees -- Constant1 (Vref) ET Vout (y) -- donc CHACUNE de ces
% 2 lignes est une ligne A EMBRANCHEMENTS (elle dessert aussi d'autres
% blocs : Constant1->Calcul_Erreur_Fuzzy, Vout->To Workspace/Goto1/
% Echantillonneur_Fuzzy). delete_block([mdl '/Sum1']) retire bien la
% REFERENCE de destination ("Dst") de la branche qui allait vers Sum1,
% mais laisse dans le fichier la branche elle-meme (ses points
% geometriques), desormais sans destination -- confirme par lecture
% directe du XML (une <Branch> avec des <Points> mais sans <Dst> ni
% sous-branche). C'est EXACTEMENT le fil/la fleche qui ne mene nulle part
% que vous voyez a l'ecran, et qui survit a une fermeture/reouverture
% complete du modele car il est reellement enregistre dans le fichier --
% ce n'est ni un residu d'affichage ni un highlight de selection (d'ou
% l'echec des 2 tentatives precedentes, qui essayaient de nettoyer un
% etat d'affichage au lieu de la structure reelle du fichier).
% Ni delete_block ni delete_line ne savent retirer UNE SEULE branche
% morte d'une ligne a embranchements sans toucher aux autres : la seule
% methode fiable (fonction locale purge_branches_orphelines, definie en
% fin de fichier) est de capturer les VRAIES destinations actuelles de la
% ligne (celles qui ont encore un port reel, la branche fantome n'en a
% pas), de supprimer la ligne ENTIERE (ce qui emporte la branche fantome
% au passage), puis de reposer une ligne vers chacune des vraies
% destinations capturees. Applique aux 2 lignes concernees (Constant1 et
% Vout), inconditionnellement et a chaque execution : idempotent par
% construction (si aucune branche fantome n'existe, ceci demonte puis
% remonte exactement les memes connexions, sans aucun changement
% fonctionnel), donc capable de reparer un fichier deja casse par une
% execution precedente de ce script, pas seulement d'empecher le defaut
% a l'avenir.
purge_branches_orphelines(mdl, 'Constant1', 1);
if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Vout'))
    error(['Bloc "Vout" introuvable dans %s -- attendu comme mesure de sortie ' ...
           '(herite de PID_Classique_Control.slx). Verifiez le fichier source.'], mdl);
end
purge_branches_orphelines(mdl, 'Vout', 1);

% LIGNES TOTALEMENT DECORATIVES (sans Src ni Dst) : plus traitees ici.
% Deux approches anterieures ont ete abandonnees a cet endroit : la
% premiere supprimait automatiquement, via l'API Simulink live, toute
% ligne dont les DEUX cotes semblaient invalides -- ce critere ne
% distingue pas une ligne de signal morte d'une connexion PHYSIQUE
% Simscape (dont get_param ne rapporte pas les extremites de la meme
% maniere), et a reellement supprime une connexion reelle par erreur,
% fragmentant le circuit. La seconde se contentait de LISTER ces lignes
% pour suppression manuelle dans l'editeur. Les deux sont maintenant
% inutiles : l'ETAPE FINALE de ce script (finaliser_fichier_slx) purge
% deja ces lignes automatiquement, en lisant le XML brut du .slx
% sauvegarde plutot que l'API live -- aucune ambiguite possible avec une
% connexion physique, et aucune intervention manuelle requise.

% Nettoyage cible de l'entree D du PWM Generator : supprime uniquement
% si la ligne actuelle ne vient PAS de "Loi_Incrementale_Fuzzy" (notre
% controleur), pour ne jamais defaire une connexion deja correcte a
% chaque relance -- seulement un vrai residu.
ph_pwm = get_param([mdl '/' nom_pwm], 'PortHandles');
lignePwm = get_param(ph_pwm.Inport(1), 'Line');
if lignePwm ~= -1
    srcH = get_param(lignePwm, 'SrcBlockHandle');
    nomSource = '';
    if ~isempty(srcH) && all(ishandle(srcH))
        nomSource = get_param(srcH, 'Name');
    end
    if strcmp(nomSource, 'Loi_Incrementale_Fuzzy')
        fprintf('Entree D du PWM Generator deja correctement cablee (source : Loi_Incrementale_Fuzzy) -- conservee.\n');
    else
        delete_line(lignePwm);
        fprintf('Ligne residuelle supprimee sur l''entree D du PWM Generator (venait de "%s").\n', nomSource);
    end
else
    fprintf('Entree D du PWM Generator deja libre.\n');
end

% -------------------------------------------------------------------
% ETAPE B : echantillonneur + bloc de calcul d'erreur
% CHAQUE add_block est desormais garde INDIVIDUELLEMENT : peu importe
% ou une execution precedente s'est arretee, ce bloc ne recree que ce
% qui manque reellement.
% -------------------------------------------------------------------
if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Echantillonneur_Fuzzy'))
    add_block('simulink/Discrete/Zero-Order Hold', [mdl '/Echantillonneur_Fuzzy']);
    set_param([mdl '/Echantillonneur_Fuzzy'], 'SampleTime', num2str(T), 'Position', [140 300 170 320]);
    fprintf('Bloc "Echantillonneur_Fuzzy" cree.\n');
else
    fprintf('Bloc "Echantillonneur_Fuzzy" deja present -- reutilise.\n');
end

if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Calcul_Erreur_Fuzzy'))
    add_block('simulink/User-Defined Functions/MATLAB Function', [mdl '/Calcul_Erreur_Fuzzy']);
    set_param([mdl '/Calcul_Erreur_Fuzzy'], 'Position', [200 280 320 340]);
    fprintf('Bloc "Calcul_Erreur_Fuzzy" cree.\n');
else
    fprintf('Bloc "Calcul_Erreur_Fuzzy" deja present -- reutilise.\n');
end

% L'injection du code est TOUJOURS retentee, que le bloc vienne d'etre
% cree ou qu'il existat deja : si une execution precedente l'avait
% laisse avec son contenu par defaut (injection ratee sans avoir leve
% d'erreur), ce passage le repare de lui-meme plutot que de perpetuer
% un etat casse silencieusement.
try
    S = sfroot;
    chart = S.find('-isa', 'Stateflow.EMChart', 'Path', [mdl '/Calcul_Erreur_Fuzzy']);
    if isempty(chart); error('Objet Stateflow.EMChart introuvable.'); end
    chart.Script = code_erreur;
    fprintf('Code (re)injecte dans "Calcul_Erreur_Fuzzy".\n');
catch ME
    fprintf(2, ['\n*** ATTENTION : injection automatique echouee (%s).\n' ...
        '*** SECOURS MANUEL : ouvrez le bloc "Calcul_Erreur_Fuzzy" dans %s.slx,\n' ...
        '*** effacez son contenu par defaut, collez-y code_calcul_erreur_fuzzy.txt,\n' ...
        '*** sauvegardez, puis relancez ce script.\n\n'], ME.message, mdl);
end

try
    set_param(mdl, 'SimulationCommand', 'update');
catch
end
nb_ports_erreur = get_param([mdl '/Calcul_Erreur_Fuzzy'], 'Ports');
if nb_ports_erreur(1) ~= 2
    error(['"Calcul_Erreur_Fuzzy" a %d entree(s) au lieu de 2 (y, Vref) : injection non prise en compte. ' ...
           'Voir le secours manuel ci-dessus.'], nb_ports_erreur(1));
end
if nb_ports_erreur(2) ~= 3
    error(['"Calcul_Erreur_Fuzzy" a %d sortie(s) au lieu de 3 : injection non prise en compte. ' ...
           'Voir le secours manuel ci-dessus.'], nb_ports_erreur(2));
end
fprintf('Verifie : "Calcul_Erreur_Fuzzy" a bien 2 entrees (y, Vref) et 3 sorties (ecn, xc1, xc3).\n');

% -------------------------------------------------------------------
% ETAPE C : bloc natif "Fuzzy Logic Controller" + gains d'echelle
% -------------------------------------------------------------------
% ATTENTION -- CONFIRME PAR TEST (get_param(...,'ReferenceBlock') sur le
% bloc ajoute a la main) : le nom du bloc dans la bibliotheque contient
% un VRAI retour a la ligne entre "Logic" et "Controller", exactement
% comme "PWM Generator\n(DC-DC)" plus haut dans ce projet. Plutot que de
% deviner l'espacement exact autour de ce \n (fragile, invisible a l'oeil
% nu), on interroge directement la bibliotheque fuzblock pour retrouver
% le nom EXACT, caractere pour caractere, du bloc dont le contenu (une
% fois les espaces/retours a la ligne retires) correspond a
% "FuzzyLogicController".
% CORRECTION DE FOND (apres 3 runs consecutifs avec 3 tables de regles
% differentes -- originale, 4 cellules corrigees, 6 cellules corrigees --
% donnant EXACTEMENT les memes statistiques de regime etabli au chiffre
% pres, alors que changer KI_MAX seul, lui, produisait bien un
% changement mesure) : garder ce bloc entre deux runs et se contenter de
% rappeler set_param(...,'FIS','fisFuzzyPID') ne suffit pas. set_param ne
% declenche la reconstruction interne du bloc (qui traduit la table de
% regles en logique executable) que s'il detecte un changement de VALEUR
% du parametre -- le nom de variable "fisFuzzyPID" ne change jamais d'un
% run a l'autre, seul SON CONTENU change, donc a partir du deuxieme run
% set_param ne voit rien de nouveau et le bloc garde la reconstruction
% faite lors du tout premier run, quel que soit ce que la table de
% regles contient ensuite. Ce n'est pas propre a l'injection de code
% (KP_MAX/KI_MAX/KD_MAX) qui, elle, ecrit sans condition dans le
% Stateflow a chaque passage -- d'ou la difference de comportement
% observee entre les deux mecanismes.
% Premiere tentative de fix (vider le parametre FIS puis le remettre,
% pour forcer un changement de valeur) : rejetee par Simulink, une
% expression vide n'est pas une valeur de parametre FIS valide ("cannot
% be evaluated"). Fix retenu : supprimer et recreer ce bloc a CHAQUE
% run plutot que de le reutiliser. Une reconstruction neuve n'a pas de
% cache a rafraichir. Le cablage n'est pas perdu : delete_block retire
% aussi les lignes connectees, et la logique de cablage idempotent plus
% bas (ligne_si_possible) les retablit d'elle-meme puisqu'elle verifie
% l'etat reel des ports, pas une hypothese sur ce qui existait avant.
if ~isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'FLC_Fuzzy_PID'))
    delete_block([mdl '/FLC_Fuzzy_PID']);
    fprintf('Bloc "FLC_Fuzzy_PID" existant supprime (reconstruction forcee a chaque run, voir note ci-dessus).\n');
end
try
    load_system('fuzblock');
    % Pas de filtre BlockType ni de SearchDepth limite cette fois : le
    % premier essai filtrait sur BlockType='Reference', un critere
    % propre aux blocs Simscape Power Systems (Mosfet, Diode...), pas a
    % un bloc masque classique comme celui-ci -- d'ou l'echec. On liste
    % TOUT ce que contient la bibliotheque, a toute profondeur, et on
    % filtre uniquement sur le nom (une fois les espaces/retours a la
    % ligne retires), ce qui evite d'avoir a deviner un autre critere.
    tous_blocs = find_system('fuzblock');
    tous_blocs = setdiff(tous_blocs, {'fuzblock'}, 'stable');   % exclut la racine de la bibliotheque elle-meme
    chemin_flc = '';
    for i = 1:numel(tous_blocs)
        nom_bloc = get_param(tous_blocs{i}, 'Name');
        if strcmpi(regexprep(nom_bloc, '\s', ''), 'FuzzyLogicController')
            chemin_flc = tous_blocs{i};   % chemin COMPLET deja renvoye par find_system, pas de reconstruction manuelle
            break;
        end
    end
    if isempty(chemin_flc)
        fprintf(2, '\nBlocs trouves dans "fuzblock" (aucun ne correspond a "FuzzyLogicController") :\n');
        for i = 1:numel(tous_blocs)
            fprintf(2, '  - %s\n', strrep(get_param(tous_blocs{i}, 'Name'), sprintf('\n'), '\\n'));
        end
        error('Aucun bloc "Fuzzy Logic Controller" trouve dans la bibliotheque fuzblock (liste ci-dessus).');
    end
    add_block(chemin_flc, [mdl '/FLC_Fuzzy_PID']);
    set_param([mdl '/FLC_Fuzzy_PID'], 'Position', [420 280 520 340]);
    set_param([mdl '/FLC_Fuzzy_PID'], 'FIS', 'fisFuzzyPID');
    fprintf('Bloc "FLC_Fuzzy_PID" (re)cree automatiquement et configure sur "fisFuzzyPID" (chemin resolu dynamiquement : %s).\n', ...
        strrep(chemin_flc, sprintf('\n'), '\n'));
catch ME
    fprintf(2, ['\n*** ATTENTION : (re)construction automatique du bloc FLC a echoue (%s).\n' ...
        '*** SECOURS MANUEL : Simulink Library Browser -> Fuzzy Logic Toolbox ->\n' ...
        '*** glissez "Fuzzy Logic Controller" dans %s.slx, nommez-le "FLC_Fuzzy_PID", entrez\n' ...
        '*** "fisFuzzyPID" dans le champ "Fuzzy inference system", sauvegardez, relancez ce script.\n\n'], ME.message, mdl);
    error('Construction interrompue : voir les instructions de secours ci-dessus.');
end

% Regler le parametre FIS ne leve pas d'erreur meme si Simulink n'a pas
% encore recalcule le nombre de ports du bloc en consequence -- EXACTEMENT
% le meme piege que pour les blocs MATLAB Function (voir ETAPE B et D) :
% sans "Update Diagram" explicite, le bloc reste sur sa configuration par
% defaut (1 entree) au lieu des 2 entrees / 3 sorties qu'impose une FIS a
% 2 entrees et 3 sorties. Meme remede : forcer la mise a jour, puis
% verifier explicitement plutot que de supposer que ca a fonctionne.
try
    set_param(mdl, 'SimulationCommand', 'update');
catch
end
nb_ports_flc = get_param([mdl '/FLC_Fuzzy_PID'], 'Ports');
fprintf(['"FLC_Fuzzy_PID" : %d port(s) d''entree, %d port(s) de sortie -- attendu : 1 et 1,\n' ...
    'chacun un VECTEUR (2 elements en entree, 3 en sortie), pas des ports separes par variable.\n' ...
    'C''est le comportement normal de ce bloc (corrige par rapport a une hypothese fausse\n' ...
    'des versions precedentes de ce script, qui exigeait a tort 2 entrees / 3 sorties separees).\n'], ...
    nb_ports_flc(1), nb_ports_flc(2));

% Un Mux regroupe (e, ce) en un vecteur pour l'entree unique du FLC ; un
% Demux separe le vecteur de sortie unique du FLC en (dKp, dKi, dKd).
% L'ordre compte : le FIS a ete construit avec e en entree 1 et ce en
% entree 2 (voir construction_FIS_Fuzzy_PID.m), donc Mux port 1 = e,
% port 2 = ce ; sorties ajoutees dans l'ordre dKp, dKi, dKd, donc Demux
% port 1 = dKp, port 2 = dKi, port 3 = dKd.
if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Mux_Entrees_FLC'))
    add_block('simulink/Signal Routing/Mux', [mdl '/Mux_Entrees_FLC']);
    set_param([mdl '/Mux_Entrees_FLC'], 'Inputs', '2', 'Position', [390 270 400 330]);
    fprintf('Bloc "Mux_Entrees_FLC" cree (e, ce -> vecteur d''entree du FLC).\n');
else
    fprintf('Bloc "Mux_Entrees_FLC" deja present -- reutilise.\n');
end

if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Demux_Sorties_FLC'))
    add_block('simulink/Signal Routing/Demux', [mdl '/Demux_Sorties_FLC']);
    set_param([mdl '/Demux_Sorties_FLC'], 'Outputs', '3', 'Position', [540 270 550 350]);
    fprintf('Bloc "Demux_Sorties_FLC" cree (vecteur de sortie du FLC -> dKp, dKi, dKd).\n');
else
    fprintf('Bloc "Demux_Sorties_FLC" deja present -- reutilise.\n');
end

% Gains d'echelle (Ke, Kec en entree ; Kpu, Kiu, Kdu en sortie),
% actuellement tous a 1 -- voir plus haut dans ce script. Chacun garde
% individuellement, et le Gain est reapplique a chaque passage (mise a
% jour immediate si vous changez Ke/Kec/Kpu/Kiu/Kdu et relancez, sans
% avoir a supprimer les blocs a la main).
gains_a_creer = {
    'Echelle_e',   Ke,  [340 260 370 280]
    'Echelle_ce',  Kec, [340 340 370 360]
    'Echelle_dKp', Kpu, [560 260 590 280]
    'Echelle_dKi', Kiu, [560 300 590 320]
    'Echelle_dKd', Kdu, [560 340 590 360]
};
for i = 1:size(gains_a_creer, 1)
    nomGain = gains_a_creer{i,1};
    valGain = gains_a_creer{i,2};
    posGain = gains_a_creer{i,3};
    if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', nomGain))
        add_block('simulink/Math Operations/Gain', [mdl '/' nomGain]);
        set_param([mdl '/' nomGain], 'Position', posGain);
        fprintf('Bloc "%s" cree.\n', nomGain);
    else
        fprintf('Bloc "%s" deja present -- reutilise.\n', nomGain);
    end
    set_param([mdl '/' nomGain], 'Gain', num2str(valGain));
end

% -------------------------------------------------------------------
% ETAPE D : bloc de la loi incrementale
% -------------------------------------------------------------------
if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Loi_Incrementale_Fuzzy'))
    add_block('simulink/User-Defined Functions/MATLAB Function', [mdl '/Loi_Incrementale_Fuzzy']);
    set_param([mdl '/Loi_Incrementale_Fuzzy'], 'Position', [640 260 780 380]);
    fprintf('Bloc "Loi_Incrementale_Fuzzy" cree.\n');
else
    fprintf('Bloc "Loi_Incrementale_Fuzzy" deja present -- reutilise.\n');
end

try
    S = sfroot;
    chart = S.find('-isa', 'Stateflow.EMChart', 'Path', [mdl '/Loi_Incrementale_Fuzzy']);
    if isempty(chart); error('Objet Stateflow.EMChart introuvable.'); end
    chart.Script = code_loi;
    fprintf('Code (re)injecte dans "Loi_Incrementale_Fuzzy".\n');
catch ME
    fprintf(2, ['\n*** ATTENTION : injection automatique echouee (%s).\n' ...
        '*** SECOURS MANUEL : ouvrez le bloc "Loi_Incrementale_Fuzzy" dans %s.slx,\n' ...
        '*** effacez son contenu par defaut, collez-y code_loi_incrementale_fuzzy.txt,\n' ...
        '*** sauvegardez, puis relancez ce script.\n\n'], ME.message, mdl);
end

try
    set_param(mdl, 'SimulationCommand', 'update');
catch
end
nb_sorties2 = get_param([mdl '/Loi_Incrementale_Fuzzy'], 'Ports');
if nb_sorties2(2) ~= 4
    error(['"Loi_Incrementale_Fuzzy" a %d sortie(s) au lieu de 4 : injection non prise en compte. ' ...
           'Voir le secours manuel ci-dessus.'], nb_sorties2(2));
end
fprintf('Verifie : "Loi_Incrementale_Fuzzy" a bien 4 sorties (mu, Kp, Ki, Kd).\n');

% -------------------------------------------------------------------
% ETAPE E : cablage complet de la branche Fuzzy-PID
% -------------------------------------------------------------------
% add_line echoue si la ligne (ou le port de destination) est deja
% connectee -- meme probleme d'idempotence que les blocs. La fonction
% locale ligne_si_possible (definie tout en bas de ce fichier) tente la
% connexion et avale silencieusement uniquement les erreurs du type
% "deja connecte", en relancant toute autre erreur inattendue plutot
% que de la masquer.
ligne_si_possible(mdl, 'Vout/1', 'Echantillonneur_Fuzzy/1');
ligne_si_possible(mdl, 'Echantillonneur_Fuzzy/1', 'Calcul_Erreur_Fuzzy/1');
ligne_si_possible(mdl, 'Constant1/1', 'Calcul_Erreur_Fuzzy/2');   % Vref, desormais un vrai signal cable, plus un litteral cache

% Calcul_Erreur_Fuzzy sorties : 1=ecn(=xc2), 2=xc1, 3=xc3
ligne_si_possible(mdl, 'Calcul_Erreur_Fuzzy/1', 'Echelle_e/1');
ligne_si_possible(mdl, 'Calcul_Erreur_Fuzzy/2', 'Echelle_ce/1');
ligne_si_possible(mdl, 'Echelle_e/1', 'Mux_Entrees_FLC/1');
ligne_si_possible(mdl, 'Echelle_ce/1', 'Mux_Entrees_FLC/2');
ligne_si_possible(mdl, 'Mux_Entrees_FLC/1', 'FLC_Fuzzy_PID/1');

% FLC : 1 seule sortie vectorielle (3 elements, ordre dKp/dKi/dKd) -> Demux -> mise a l'echelle
ligne_si_possible(mdl, 'FLC_Fuzzy_PID/1', 'Demux_Sorties_FLC/1');
ligne_si_possible(mdl, 'Demux_Sorties_FLC/1', 'Echelle_dKp/1');
ligne_si_possible(mdl, 'Demux_Sorties_FLC/2', 'Echelle_dKi/1');
ligne_si_possible(mdl, 'Demux_Sorties_FLC/3', 'Echelle_dKd/1');

% Loi_Incrementale_Fuzzy entrees : 1=xc2(=ecn), 2=xc1, 3=xc3, 4=dKp, 5=dKi, 6=dKd
ligne_si_possible(mdl, 'Calcul_Erreur_Fuzzy/1', 'Loi_Incrementale_Fuzzy/1');
ligne_si_possible(mdl, 'Calcul_Erreur_Fuzzy/2', 'Loi_Incrementale_Fuzzy/2');
ligne_si_possible(mdl, 'Calcul_Erreur_Fuzzy/3', 'Loi_Incrementale_Fuzzy/3');
ligne_si_possible(mdl, 'Echelle_dKp/1', 'Loi_Incrementale_Fuzzy/4');
ligne_si_possible(mdl, 'Echelle_dKi/1', 'Loi_Incrementale_Fuzzy/5');
ligne_si_possible(mdl, 'Echelle_dKd/1', 'Loi_Incrementale_Fuzzy/6');

% Loi_Incrementale_Fuzzy sorties : 1=mu, 2=Kp, 3=Ki, 4=Kd
% mu -> PWM Generator (DC-DC), a la place de l'ancien PID Controller.
ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/1', sprintf('%s/1', nom_pwm));

fprintf('Cablage de la branche Fuzzy-PID verifie/complete.\n');

% -------------------------------------------------------------------
% ETAPE F : logs et scopes pour Kp, Ki, Kd, mu (nouveaux -- le PID
% classique avait des gains fixes, rien de dynamique a observer la ou
% Fuzzy-PID en a besoin). Chaque bloc garde individuellement.
% -------------------------------------------------------------------
noms_ctrl = {'mu_fuzzy', 'Kp_fuzzy', 'Ki_fuzzy', 'Kd_fuzzy'};
positions_y = [420, 460, 500, 540];
for i = 1:numel(noms_ctrl)
    nomCourt = ['Log_' noms_ctrl{i}];
    blocName = [mdl '/' nomCourt];
    if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', nomCourt))
        add_block('simulink/Sinks/To Workspace', blocName);
        set_param(blocName, 'VariableName', noms_ctrl{i}, 'SaveFormat', 'Timeseries', ...
            'SampleTime', num2str(T), 'Position', [820 positions_y(i) 900 positions_y(i)+20]);
        fprintf('Bloc "%s" cree.\n', nomCourt);
    else
        fprintf('Bloc "%s" deja present -- reutilise.\n', nomCourt);
    end
    ligne_si_possible(mdl, sprintf('Loi_Incrementale_Fuzzy/%d', i), [nomCourt '/1']);
end

if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Scope_Kp_Ki_Fuzzy'))
    add_block('simulink/Sinks/Scope', [mdl '/Scope_Kp_Ki_Fuzzy']);
    set_param([mdl '/Scope_Kp_Ki_Fuzzy'], 'NumInputPorts', '2', 'Position', [960 260 1020 320]);
    fprintf('Bloc "Scope_Kp_Ki_Fuzzy" cree.\n');
else
    fprintf('Bloc "Scope_Kp_Ki_Fuzzy" deja present -- reutilise.\n');
end
ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/2', 'Scope_Kp_Ki_Fuzzy/1');
ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/3', 'Scope_Kp_Ki_Fuzzy/2');

if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Scope_Kd_Fuzzy'))
    add_block('simulink/Sinks/Scope', [mdl '/Scope_Kd_Fuzzy']);
    set_param([mdl '/Scope_Kd_Fuzzy'], 'Position', [960 360 1020 400]);
    fprintf('Bloc "Scope_Kd_Fuzzy" cree.\n');
else
    fprintf('Bloc "Scope_Kd_Fuzzy" deja present -- reutilise.\n');
end
ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/4', 'Scope_Kd_Fuzzy/1');

if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Scope_Commande_Fuzzy'))
    add_block('simulink/Sinks/Scope', [mdl '/Scope_Commande_Fuzzy']);
    set_param([mdl '/Scope_Commande_Fuzzy'], 'Position', [960 440 1020 480]);
    fprintf('Bloc "Scope_Commande_Fuzzy" cree.\n');
else
    fprintf('Bloc "Scope_Commande_Fuzzy" deja present -- reutilise.\n');
end
ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/1', 'Scope_Commande_Fuzzy/1');

fprintf('Logs et scopes verifies/completes (mu, Kp, Ki, Kd).\n');

% CORRECTIF (apres echec reel dans Test_Validation_Fuzzy_PID_Nominal.m :
% "The logical indices contain a true value outside of the array
% bounds") -- les blocs "To Workspace" (variable "y"=Vout) et
% "To Workspace1" (variable "x") viennent tels quels du modele d'origine
% PID_Classique_Control.slx : ce script ne les cree ni ne les modifie
% jusqu'ici. Ils n'avaient pas de SaveFormat explicite (defaut de
% l'installation MATLAB, potentiellement different d'une machine a
% l'autre, et pouvant produire un objet ou "Time" et "Data" ne sont pas
% garantis de meme longueur -- c'est cette incoherence interne qui a
% provoque l'echec ci-dessus). Fix : forcer EXPLICITEMENT SaveFormat=
% Timeseries, qui garantit par construction "Time" et "Data" de meme
% longueur, quel que soit le SampleTime.
%
% CORRECTIF 2 (a ne pas reproduire) : une premiere version de ce fix
% forcait EN PLUS SampleTime=T (5e-6s, la cadence discrete du
% controleur), par souci de coherence avec les logs Log_mu/Kp/Ki/Kd_fuzzy.
% Erreur reelle constatee : le ripple mesure de Vout est passe de 0.37V a
% 0.35V (-5.3%) alors que Ki restait identique a 0.00% pres -- signature
% incompatible avec une vraie regression de cablage (qui aurait perturbe
% TOUT le comportement, pas seulement le ripple HF). Cause reelle : "y"
% est directement la sortie CONTINUE du reseau Simscape ; la logger a la
% cadence discrete du controleur (200kHz) revient a SOUS-ECHANTILLONNER
% le ripple de commutation reel, qui peut tomber entre deux points de
% cette grille -- le chiffre de reference 0.37V avait ete mesure SANS ce
% sous-echantillonnage (SampleTime=-1, cadence continue/pas variable du
% solveur). Fix retenu : ne fixer QUE SaveFormat (regle le crash), laisser
% SampleTime hérité (-1) pour ne pas alterer la fidelite de la mesure de
% ripple par rapport a la reference historique.
if ~isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'To Workspace'))
    set_param([mdl '/To Workspace'], 'SaveFormat', 'Timeseries');
    fprintf('Bloc "To Workspace" (variable "y"/Vout) : SaveFormat force a Timeseries (SampleTime laisse herite, -1).\n');
else
    fprintf(2, '*** ATTENTION : bloc "To Workspace" (variable "y") introuvable -- verifiez manuellement son format avant le test de validation.\n');
end
if ~isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'To Workspace1'))
    set_param([mdl '/To Workspace1'], 'SaveFormat', 'Timeseries');
    fprintf('Bloc "To Workspace1" (variable "x") : SaveFormat force a Timeseries (SampleTime laisse herite, -1).\n');
end

% OverwriteIfChangedOnDisk : meme famille de bug que le stale in-memory
% model corrige plus haut (bdIsLoaded/close_system avant recopie), mais
% cote sauvegarde cette fois -- le fichier sur disque a pu changer
% (edition manuelle GUI, ou simple horodatage) depuis que ce modele a
% ete charge en memoire dans cette session MATLAB. Sans ce parametre,
% save_system refuse avec "has changed on disk since it was loaded" ;
% c'est le remede que MATLAB suggere lui-meme dans le message d'erreur.
save_system(mdl, [], 'OverwriteIfChangedOnDisk', true);
fprintf('\nModele sauvegarde : %s.slx\n', mdl);

% =====================================================================
% ETAPE FINALE : nettoyage + verification du fichier .slx SUR DISQUE.
%
% Pourquoi ceci travaille sur le FICHIER et pas sur le modele Simulink
% ouvert (aucun get_param/find_system/delete_line ici) : les deux
% regressions reelles de cette session (branches fantomes, puis
% fragmentation du circuit physique) venaient toutes les deux d'une
% hypothese sur le comportement de l'API Simulink LIVE qui s'est revelee
% fausse en pratique. Une ligne totalement decorative (sans Src ni Dst,
% simple residu geometrique visible a l'ecran comme un petit trait ou
% une fleche isolee) peut de la meme maniere ne pas etre nettoyable de
% facon fiable via cette API. Le texte XML brut, lui, ne depend d'aucune
% hypothese sur un comportement d'API : "cette ligne contient-elle le
% texte Name="Src" ou Name="Dst" ?" est une question sur le CONTENU du
% fichier, pas sur son interpretation par Simulink.
%
% Cette etape ferme le modele, reecrit le fichier .slx sur disque si une
% ligne purement decorative y trainait, verifie que la topologie du
% circuit de puissance correspond EXACTEMENT a celle de
% PID_Classique_Control.slx (5 noeuds physiques), puis rouvre le modele
% nettoye. Si la verification finale echoue, le script s'arrete avec une
% erreur explicite plutot que de laisser croire que le fichier est bon.
if bdIsLoaded(mdl); close_system(mdl, 0); end
finaliser_fichier_slx([mdl '.slx'], [modele_original '.slx']);
open_system(mdl);

% CORRECTIF (texte precedent trompeur, trouve en comparant ce script a
% une version anterieure fournie par l'utilisateur) -- ERREUR A NE PAS
% REPRODUIRE : ce RAPPEL affichait auparavant le texte fixe "Ke, Kec,
% Kpu, Kiu, Kdu valent 1", copie tel quel depuis une version anterieure
% de ce script ou c'etait effectivement le cas (fuzzy_pid_buck.mat
% d'alors avait ces 5 facteurs a 1). Depuis, construction_FIS_Fuzzy_PID.m
% a ete iteré (Ke=100/Kec=10000/Kdu=5e-6, apres un vrai bug d'univers FIS
% trouve et corrige -- voir memoire de projet), mais ce texte n'avait
% jamais ete mis a jour en consequence : il affirmait "valent 1" alors
% que les vraies valeurs chargees (Ke, Kec, Kpu, Kiu, Kdu, deja en
% memoire depuis le chargement de fuzzy_pid_buck.mat plus haut) etaient
% differentes -- source directe de la confusion qui a fait comparer une
% simulation reellement mise a l'echelle a une reference qui ne l'etait
% pas. Affiche desormais les valeurs REELLEMENT chargees, jamais un texte
% fixe.
fprintf('\nRAPPEL : Ke=%.4g, Kec=%.4g, Kpu=%.4g, Kiu=%.4g, Kdu=%.4g (valeurs actuelles de fuzzy_pid_buck.mat)\n', ...
    Ke, Kec, Kpu, Kiu, Kdu);
fprintf(['-- meme si ces valeurs ne sont plus de simples placeholders a 1, elles restent en\n' ...
    'cours de calibration pour le regime etabli nominal (Kp/Kd/mu satures une grande partie\n' ...
    'du run avec ces valeurs -- voir ETAPE 4bis de Test_Validation_Fuzzy_PID_Nominal.m).\n']);

% =====================================================================
% FONCTION LOCALE (doit rester en fin de fichier -- regle MATLAB pour
% les scripts contenant des fonctions locales, valable depuis R2016b)
% =====================================================================
function ligne_si_possible(mdl, src, dst)
% Verifie l'ETAT REEL du port de destination avant de tenter la
% connexion, plutot que d'intercepter l'erreur d'add_line et de deviner
% sa signification a partir de son texte. Cette seconde methode s'est
% revelee dangereuse en pratique : un vrai echec de cablage (un port
% deja occupe par un fil residuel, distinct d'une ligne deja posee par
% ce script) contenait aussi le mot "already" dans son message, et se
% faisait donc avaler silencieusement comme s'il s'agissait d'un cas
% normal d'idempotence -- ce qui a laisse l'entree D du PWM Generator
% sans aucune connexion reelle pendant plusieurs relances, sans qu'aucune
% erreur ne le signale. On verifie desormais directement, via
% PortHandles et la propriete "Line" du port, si une ligne existe deja,
% au lieu de deviner apres coup.
    % Recherche du dernier "/" par indexation directe plutot que par
    % regex : la regex precedente (^(.*)/(\d+)$) echouait silencieusement
    % sur "PWM Generator\n(DC-DC)/1", parce que "." ne traverse pas un
    % retour a la ligne par defaut, et ce bloc en contient un dans son
    % nom. L'indexation de caracteres ne depend d'aucune semantique de
    % regex et fonctionne quel que soit le contenu du nom de bloc.
    idxSlash = find(dst == '/', 1, 'last');
    if isempty(idxSlash)
        add_line(mdl, src, dst, 'autorouting', 'on');
        return;
    end
    blocDst = dst(1:idxSlash-1);
    numPort = str2double(dst(idxSlash+1:end));
    ph = get_param([mdl '/' blocDst], 'PortHandles');
    if numPort > numel(ph.Inport)
        error('ligne_si_possible:portIntrouvable', ...
            ['Le port d''entree %d de "%s" n''existe pas (%d port(s) d''entree ' ...
             'trouve(s) sur ce bloc). Verifiez le nom/l''index de port.'], ...
            numPort, blocDst, numel(ph.Inport));
    end
    if get_param(ph.Inport(numPort), 'Line') ~= -1
        fprintf('Ligne %s -> %s deja presente (port verifie occupe) -- ignoree.\n', src, dst);
    else
        add_line(mdl, src, dst, 'autorouting', 'on');
        fprintf('Ligne %s -> %s posee.\n', src, dst);
    end
end

function purge_branches_orphelines(mdl, blocSrc, numPortSrc)
% Repare le defaut Simulink diagnostique par inspection directe du XML du
% .slx (voir le commentaire au point d'appel, ETAPE A) : delete_block sur
% UNE des plusieurs destinations d'une ligne a embranchements (ex. Sum1,
% alimente par Constant1 ET Vout, tous deux branches vers d'autres blocs
% egalement) ne retire que la reference "Dst" de la branche supprimee --
% elle laisse une branche fantome (points geometriques orphelins, sans
% destination) dans le fichier, visible a l'ecran comme un segment de fil
% ou une fleche qui ne mene nulle part, meme apres fermeture/reouverture
% complete (verifie : c'est une donnee reelle du fichier, pas un etat
% d'affichage).
%
% Ni delete_block ni delete_line ne permettent de cibler UNE SEULE branche
% d'une ligne a embranchements : la seule methode fiable est de capturer
% les VRAIES destinations actuelles de la ligne (DstPortHandle -- une
% branche fantome n'a par definition aucun port de destination reel, donc
% n'y apparait jamais), de supprimer la ligne ENTIERE avec delete_line
% (ce qui emporte la branche fantome au passage, puisqu'elle appartient a
% la meme ligne), puis de reposer une ligne vers chacune des vraies
% destinations capturees.
%
% IDEMPOTENT PAR CONSTRUCTION : si aucune branche fantome n'existe, ceci
% demonte puis remonte exactement les memes connexions (0 changement
% fonctionnel) -- donc capable de reparer un fichier deja casse par une
% execution precedente de ce script (le cas reel de l'utilisateur), pas
% seulement d'empecher le defaut a l'avenir. Volontairement inconditionnel
% (pas de detection prealable "y a-t-il une branche fantome ?") : une
% telle detection demanderait de re-parser le XML du .slx depuis MATLAB,
% bien plus fragile que ce demontage/remontage qui, lui, ne depend que de
% l'API Simulink documentee (get_param/delete_line/add_line).
%
% CORRECTION (apres echec reel : "Invalid Simulink port handle") -- ERREUR
% A NE PAS REPRODUIRE : la premiere version de cette fonction gardait les
% handles de ports de destination (DstPortHandle) captes AVANT delete_line,
% et les reutilisait APRES pour reposer les lignes. Un handle Simulink
% n'est garanti valide que jusqu'a la PROCHAINE modification programmatique
% du diagramme -- delete_line en est une, et invalide potentiellement tout
% handle obtenu avant lui, y compris ceux de ports que la suppression ne
% visait meme pas directement. D'ou l'erreur observee en pratique. Fix :
% ne plus jamais faire transiter un HANDLE a travers un appel qui modifie
% le diagramme -- seulement des donnees stables (chemin de bloc en chaine
% via getfullname, numero de port en entier), capturees avant, puis
% reconverties en handles FRAIS apres coup.
    ph = get_param([mdl '/' blocSrc], 'PortHandles');
    if numPortSrc > numel(ph.Outport)
        error('purge_branches_orphelines:portIntrouvable', ...
            'Le port de sortie %d de "%s" n''existe pas.', numPortSrc, blocSrc);
    end
    portSrc = ph.Outport(numPortSrc);
    ligneH = get_param(portSrc, 'Line');
    if ligneH == -1
        fprintf('"%s" (sortie %d) : aucune ligne posee -- rien a purger.\n', blocSrc, numPortSrc);
        return;
    end

    dstBlocH = get_param(ligneH, 'DstBlockHandle');
    dstPortH = get_param(ligneH, 'DstPortHandle');
    nbTotal = numel(dstBlocH);

    % CORRECTION (apres 2e echec reel : "Invalid Simulink object handle"
    % sur getfullname) -- HYPOTHESE INITIALE FAUSSE A NE PAS REPRODUIRE :
    % cette fonction supposait qu'une branche fantome (sans destination
    % reelle) etait simplement ABSENTE des tableaux DstBlockHandle/
    % DstPortHandle. Faux en pratique : la branche fantome y occupe belle
    % et bien une entree, avec un handle -1 -- exactement la convention
    % Simulink deja utilisee partout ailleurs dans ce script pour
    % signaler "rien connecte" (voir par ex. get_param(port,'Line')~=-1
    % plus haut). getfullname(-1) n'est pas une chaine "vide", c'est une
    % erreur ("Invalid Simulink object handle"), d'ou l'echec observe.
    % Fix : filtrer explicitement les entrees dont le handle vaut -1
    % (ou echoue le test ishandle, meme verification que celle deja
    % utilisee dans ce script pour SrcBlockHandle) AVANT tout appel a
    % getfullname -- ce filtre elimine precisement les branches fantomes,
    % ce qui est exactement le resultat recherche.
    dstChemins = {};
    dstNumPorts = [];
    for i = 1:nbTotal
        if dstBlocH(i) ~= -1 && ishandle(dstBlocH(i))
            dstChemins{end+1} = getfullname(dstBlocH(i)); %#ok<AGROW>
            dstNumPorts(end+1) = get_param(dstPortH(i), 'PortNumber'); %#ok<AGROW>
        end
    end
    nbAvant = numel(dstChemins);

    if nbAvant < nbTotal
        fprintf('%d branche(s) fantome(s) (sans destination reelle) detectee(s) et eliminee(s) sur la ligne issue de "%s" (sortie %d).\n', ...
            nbTotal - nbAvant, blocSrc, numPortSrc);
    end
    if nbAvant == 0
        fprintf(2, ['*** ATTENTION : la ligne issue de "%s" (sortie %d) n''a AUCUNE destination ' ...
            'reelle (elle ne consistait qu''en branche(s) fantome(s)). Suppression sans ' ...
            'reconnexion -- verifiez manuellement si un cablage etait pourtant attendu ici.\n'], ...
            blocSrc, numPortSrc);
    end

    delete_line(ligneH);

    % Tout ce qui suit re-derive des handles FRAIS a partir des donnees
    % capturees plus haut -- plus aucun handle d'avant delete_line n'est
    % reutilise, source de l'echec initial.
    ph = get_param([mdl '/' blocSrc], 'PortHandles');
    portSrc = ph.Outport(numPortSrc);
    for i = 1:nbAvant
        phDst = get_param(dstChemins{i}, 'PortHandles');
        add_line(mdl, portSrc, phDst.Inport(dstNumPorts(i)), 'autorouting', 'on');
    end

    fprintf(['Ligne issue de "%s" (sortie %d) reconstruite : %d destination(s) reelle(s) ' ...
        'conservee(s), toute branche fantome (sans destination) eliminee.\n'], ...
        blocSrc, numPortSrc, nbAvant);
end

function finaliser_fichier_slx(fichierCible, fichierReference)
% Reecrit fichierCible EN PLACE si besoin (suppression des lignes
% purement decoratives) puis verifie que la topologie de son circuit de
% puissance correspond EXACTEMENT a celle de fichierReference. Arrete le
% script (error) si la verification finale echoue.
%
% CORRECTION (bug reel observe en conditions reelles, via un log
% d'execution : "Finalisation ... OK -- 0 noeud(s) physique(s)" -- un
% FAUX POSITIF silencieux) -- ERREUR A NE PAS REPRODUIRE : la version
% precedente lisait le contenu de l'archive .slx via
% java.util.zip.ZipFile + une boucle manuelle appelant
% InputStream.read(byte[], int, int). MATLAB passe les tableaux aux
% methodes Java PAR COPIE : ce "read" Java est concu pour ECRIRE dans le
% tableau qu'on lui passe (idiome Java "parametre de sortie"), mais il
% n'ecrivait que dans une copie temporaire cote Java -- jamais dans la
% variable MATLAB d'origine. Seule la VALEUR DE RETOUR (nombre d'octets
% lus) revenait correctement ; le contenu, lui, restait un tableau de
% zeros de la bonne longueur. Resultat : un texte XML entierement
% compose de caracteres NUL, qui ne correspond a AUCUN motif <Line...>
% -- d'ou "0 noeud(s) physique(s)" accepte comme un OK au lieu d'etre
% detecte comme une lecture ratee (aucune exception n'est levee nulle
% part : le bug est totalement silencieux).
%
% Fix : abandon complet de java.util.zip pour la lecture/reecriture de
% l'archive, remplace par les fonctions NATIVES de MATLAB --
% unzip()/fileread() pour lire (aucun tableau ne sert de parametre de
% sortie a une methode Java, donc ce bug est structurellement
% impossible) et fopen/fwrite/fclose + zip() natif pour reecrire.
    if ~isfile(fichierCible)
        error('finaliser_fichier_slx:fichierIntrouvable', ...
            'Fichier introuvable : %s', fichierCible);
    end
    if ~isfile(fichierReference)
        error('finaliser_fichier_slx:fichierIntrouvable', ...
            'Fichier de reference introuvable : %s', fichierReference);
    end

    texte = lire_system_root_xml(fichierCible);
    [texteNettoye, nbSupprimees] = purger_lignes_decoratives_texte(texte);

    if nbSupprimees > 0
        ecrire_system_root_xml(fichierCible, texteNettoye);
        fprintf('Finalisation : %d ligne(s) purement decorative(s) supprimee(s) de %s.\n', ...
            nbSupprimees, fichierCible);
        texteFinal = texteNettoye;
    else
        fprintf('Finalisation : aucune ligne decorative dans %s.\n', fichierCible);
        texteFinal = texte;
    end

    reseauxCible = extraire_reseaux_physiques_texte(texteFinal);

    texteRef = lire_system_root_xml(fichierReference);
    reseauxRef = extraire_reseaux_physiques_texte(texteRef);

    % Garde-fou anti-faux-positif (directement motive par le bug
    % ci-dessus) : un circuit de puissance reel a TOUJOURS au moins 1
    % noeud physique. Si l'un ou l'autre releve est vide, la
    % lecture/l'extraction a echoue quelque part -- on s'arrete plutot
    % que de comparer deux ensembles vides et de conclure a tort a une
    % "identite".
    if isempty(reseauxRef)
        error('finaliser_fichier_slx:lectureReferenceEchouee', ...
            ['Aucun noeud physique extrait de la reference "%s" -- lecture/extraction ' ...
             'probablement en echec (fichier vide, corrompu, ou bug d''extraction). ' ...
             'Verification interrompue plutot que de valider a tort.'], fichierReference);
    end
    if isempty(reseauxCible)
        error('finaliser_fichier_slx:lectureCibleEchouee', ...
            ['Aucun noeud physique extrait de "%s" alors que la reference en a %d -- lecture/extraction ' ...
             'probablement en echec (fichier vide, corrompu, ou bug d''extraction). ' ...
             'Verification interrompue plutot que de valider a tort.'], fichierCible, numel(reseauxRef));
    end

    manquants = setdiff(reseauxRef, reseauxCible);
    imprevus = setdiff(reseauxCible, reseauxRef);

    if isempty(manquants) && isempty(imprevus)
        % Preuve finale, la seule qui compte vraiment : Simulink
        % lui-meme doit pouvoir charger le fichier. La verification
        % texte ci-dessus (unzip + fileread) NE SUFFIT PAS a le
        % garantir -- elle a laisse passer, sans la detecter, une
        % archive dont les entrees etaient nommees avec l'antislash de
        % Windows (bug reel, corrige dans ecrire_system_root_xml) : sur
        % Windows, unzip() de MATLAB reconstruit silencieusement les
        % dossiers a partir de cet antislash, alors que le moteur de
        % chargement de Simulink applique strictement la convention
        % "slash" des Open Packaging Conventions et rejette le fichier.
        % Seul un chargement reel peut donc prouver que l'archive .slx
        % est valide.
        [~, nomModele] = fileparts(fichierCible);
        try
            load_system(fichierCible);
            close_system(nomModele, 0);
        catch ME
            error('finaliser_fichier_slx:fichierIllisibleParSimulink', ...
                ['Le fichier "%s" a ete rebati (topologie et contenu XML verifies corrects ' ...
                 'ci-dessus) mais Simulink lui-meme ne parvient pas a le charger : %s. ' ...
                 'L''archive .slx est donc invalide malgre un contenu textuel correct -- ' ...
                 'NE PAS utiliser ce fichier tel quel.'], fichierCible, ME.message);
        end

        fprintf(['Finalisation : verification topologie circuit de puissance OK -- %d noeud(s) ' ...
            'physique(s) identiques a "%s".\n'], numel(reseauxRef), fichierReference);
        fprintf('Finalisation : fichier "%s" confirme chargeable par Simulink (load_system reussi).\n', ...
            fichierCible);
        return;
    end

    fprintf(2, '\n*** ECHEC VERIFICATION TOPOLOGIE CIRCUIT DE PUISSANCE (finaliser_fichier_slx) ***\n');
    for i = 1:numel(manquants)
        fprintf(2, '  Noeud attendu ABSENT (circuit fragmente)  : %s\n', manquants{i});
    end
    for i = 1:numel(imprevus)
        fprintf(2, '  Noeud INATTENDU (cablage different)       : %s\n', imprevus{i});
    end
    error('finaliser_fichier_slx:topologieIncorrecte', ...
        ['Le circuit de puissance de "%s" ne correspond PAS a celui de "%s". ' ...
         'Construction interrompue -- NE PAS utiliser ce fichier tel quel (details ci-dessus).'], ...
        fichierCible, fichierReference);
end

function texte = lire_system_root_xml(fichierSlx)
% Lit le contenu de "simulink/systems/system_root.xml" a l'interieur
% d'une archive .slx, comme une chaine de caracteres MATLAB. Utilise
% unzip() (extraction native MATLAB vers un dossier temporaire) puis
% fileread() (lecture native, retourne toujours un vecteur LIGNE de
% caracteres) -- aucun tableau ne transite par une methode Java en tant
% que parametre de sortie, donc le bug de copie decrit dans
% finaliser_fichier_slx est ici structurellement impossible.
    dossierTmp = tempname();
    mkdir(dossierTmp);
    nettoyeur = onCleanup(@() rmdir(dossierTmp, 's')); %#ok<NASGU>
    try
        unzip(fichierSlx, dossierTmp);
    catch ME
        error('lire_system_root_xml:unzipEchec', ...
            'Echec de l''extraction de "%s" : %s', fichierSlx, ME.message);
    end
    cheminXml = fullfile(dossierTmp, 'simulink', 'systems', 'system_root.xml');
    if ~isfile(cheminXml)
        error('lire_system_root_xml:xmlIntrouvable', ...
            '"simulink/systems/system_root.xml" introuvable dans %s -- fichier .slx inattendu.', ...
            fichierSlx);
    end
    texte = fileread(cheminXml);
end

function ecrire_system_root_xml(fichierSlx, texteNouveau)
% Reecrit "simulink/systems/system_root.xml" EN PLACE a l'interieur de
% l'archive .slx : extrait toute l'archive dans un dossier temporaire,
% remplace uniquement ce fichier sur disque (fopen/fwrite/fclose), puis
% recompresse le dossier entier a l'identique.
%
% CORRECTION (2e bug reel, distinct du precedent -- trouve sur un vrai
% run MATLAB, APRES que le premier correctif ait ete valide) -- ERREUR A
% NE PAS REPRODUIRE : la version precedente de cette fonction
% recompressait le dossier extrait via zip(zipfilename, files, rootDir).
% Erreur reelle obtenue juste apres, a l'open_system() suivant :
% « ... is not a valid Simulink model file ... does not contain the
% requested part: /simulink/blockdiagram.xml ». Cause reelle : sur
% Windows, la fonction zip() de MATLAB nomme les entrees de l'archive en
% utilisant le separateur de chemin de l'OS (antislash --
% "simulink\blockdiagram.xml"), alors que le format .slx suit les Open
% Packaging Conventions (la meme famille de format que .docx/.xlsx),
% qui exige un SLASH ("/") dans les noms de "parts" -- ce n'est pas une
% question de contenu binaire (les octets du fichier sont intacts),
% c'est le NOM D'ENTREE lui-meme qui ne correspond plus a ce que le
% moteur de packaging de Simulink recherche, donc la "part" est
% introuvable meme si elle est bel et bien presente dans l'archive.
% Reproduit et confirme independamment (hors MATLAB) : une archive zip
% dont une entree est nommee litteralement "simulink\blockdiagram.xml"
% ne repond pas a une recherche exacte de "simulink/blockdiagram.xml".
%
% Fix : abandon de zip() pour l'ECRITURE. On continue de lire via
% unzip() (cote sain, voir lire_system_root_xml), mais on reconstruit
% l'archive nous-memes avec java.util.zip.ZipOutputStream/ZipEntry, en
% forcant explicitement CHAQUE nom d'entree en slash. ZipEntry ne
% reinterprete jamais le nom qu'on lui donne (ce n'est qu'une chaine de
% caracteres pour lui) donc ce controle est total et independant de
% l'OS. Chaque fichier est lu par fread() natif (jamais via un
% InputStream Java) avant d'etre ecrit dans le flux Java --
% ZipOutputStream.write(byte[], off, len) recoit le tableau en
% PARAMETRE D'ENTREE simple, ce n'est pas un parametre de sortie Java
% cense le modifier en place, donc cette direction ne souffre pas du
% bug de copie qui affectait la lecture (lire_tous_octets, cf. plus
% haut).
    dossierTmp = tempname();
    mkdir(dossierTmp);
    nettoyeur = onCleanup(@() rmdir(dossierTmp, 's')); %#ok<NASGU>

    unzip(fichierSlx, dossierTmp);

    cheminXml = fullfile(dossierTmp, 'simulink', 'systems', 'system_root.xml');
    fid = fopen(cheminXml, 'w');
    if fid == -1
        error('ecrire_system_root_xml:ecritureEchec', ...
            'Impossible d''ouvrir "%s" en ecriture.', cheminXml);
    end
    try
        fwrite(fid, unicode2native(texteNouveau, 'UTF-8'), 'uint8');
    catch ME
        fclose(fid);
        rethrow(ME);
    end
    fclose(fid);

    % Reconstruit la liste complete des fichiers extraits (toutes les
    % entrees de l'archive d'origine, pas seulement le XML modifie) pour
    % que l'archive reecrite les contienne toutes.
    fichiers = recenser_fichiers(dossierTmp);

    fichierZipTmp = [fichierSlx '.tmp'];
    if isfile(fichierZipTmp); delete(fichierZipTmp); end
    flux = java.io.FileOutputStream(fichierZipTmp);
    zipOut = java.util.zip.ZipOutputStream(flux);
    try
        for i = 1:numel(fichiers)
            cheminAbsolu = fichiers{i};
            % Nom d'entree relatif a dossierTmp, force en slash (voir
            % justification ci-dessus) quel que soit le filesep() de la
            % plateforme.
            nomEntree = strrep(erase(cheminAbsolu, [dossierTmp filesep]), filesep, '/');
            zipOut.putNextEntry(java.util.zip.ZipEntry(nomEntree));
            fidLecture = fopen(cheminAbsolu, 'r');
            if fidLecture == -1
                zipOut.close();
                error('ecrire_system_root_xml:lectureEchec', ...
                    'Impossible d''ouvrir "%s" en lecture.', cheminAbsolu);
            end
            octetsFichier = fread(fidLecture, Inf, '*uint8');
            fclose(fidLecture);
            if ~isempty(octetsFichier)
                zipOut.write(typecast(octetsFichier, 'int8'), 0, numel(octetsFichier));
            end
            zipOut.closeEntry();
        end
    catch ME
        zipOut.close();
        rethrow(ME);
    end
    zipOut.close();

    if ~isfile(fichierZipTmp)
        error('ecrire_system_root_xml:zipEchec', ...
            'La reecriture de l''archive n''a pas produit le fichier attendu (%s).', fichierZipTmp);
    end

    if isfile(fichierSlx); delete(fichierSlx); end
    movefile(fichierZipTmp, fichierSlx);
end

function fichiers = recenser_fichiers(dossier)
% Liste recursivement tous les fichiers (chemins complets) sous
% "dossier", pour les reecrire un par un dans la nouvelle archive.
    tout = dir(fullfile(dossier, '**', '*'));
    tout = tout(~[tout.isdir]);
    fichiers = fullfile({tout.folder}, {tout.name});
end

function [texteNettoye, nbSupprimees] = purger_lignes_decoratives_texte(texte)
% Supprime toute <Line>...</Line> ne contenant, nulle part dans son
% texte (branches imbriquees comprises), ni Name="Src" ni Name="Dst".
% Une <Line> ne contient jamais une autre <Line> imbriquee (seulement
% des <Branch>), donc une correspondance regex non gourmande entre
% <Line> et </Line> suffit.
    [debuts, fins] = regexp(texte, '<Line>.*?</Line>', 'start', 'end', 'dotall');
    nbSupprimees = 0;
    morceaux = {};
    curseur = 1;
    for i = 1:numel(debuts)
        d = debuts(i); f = fins(i);
        contenu = texte(d:f);
        aSrcOuDst = contains(contenu, 'Name="Src"') || contains(contenu, 'Name="Dst"');
        morceaux{end+1} = texte(curseur:d-1); %#ok<AGROW>
        if aSrcOuDst
            morceaux{end+1} = contenu; %#ok<AGROW>
        else
            nbSupprimees = nbSupprimees + 1;
        end
        curseur = f + 1;
    end
    morceaux{end+1} = texte(curseur:end); %#ok<AGROW>
    texteNettoye = strjoin(morceaux, '');
end

function reseaux = extraire_reseaux_physiques_texte(texte)
% Retourne l'ensemble (cellstr trie/unique) des noeuds physiques du
% circuit de puissance : un noeud par <Line LineType="Connection">,
% represente comme la liste triee et concatenee de toutes les
% references SID#port qu'il contient (P Name="Src" ou "Dst", a
% n'importe quelle profondeur de branche). Comparaison par SID brut
% (pas par nom de bloc resolu) -- suffisant et plus simple ici car les
% blocs de l'etage de puissance conservent des SID identiques entre
% PID_Classique_Control.slx et toutes les variantes Fuzzy-PID/F1/F2
% construites a partir de lui (verifie sur ce projet).
    [debuts, fins] = regexp(texte, '<Line[^>]*>.*?</Line>', 'start', 'end', 'dotall');
    reseaux = {};
    for i = 1:numel(debuts)
        contenu = texte(debuts(i):fins(i));
        enTete = regexp(contenu, '^<Line[^>]*>', 'match', 'once');
        if isempty(strfind(enTete, 'LineType="Connection"')) %#ok<STREMP>
            continue;
        end
        refs = regexp(contenu, '<P Name="(?:Src|Dst)">([^<]+)</P>', 'tokens');
        extremites = {};
        for k = 1:numel(refs)
            extremites{end+1} = refs{k}{1}; %#ok<AGROW>
        end
        if ~isempty(extremites)
            extremites = unique(extremites);
            reseaux{end+1} = strjoin(sort(extremites), ' | '); %#ok<AGROW>
        end
    end
    reseaux = unique(reseaux);
end
