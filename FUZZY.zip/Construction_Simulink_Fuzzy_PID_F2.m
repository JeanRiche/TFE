%% Construction_Simulink_Fuzzy_PID_F2.m
% =========================================================================
%                                                                         %
%   SCENARIO F2 (PERTURBATION DE CHARGE) POUR FUZZY-PID                  %
%   -- construit a partir du fichier de reference DEJA CABLE            %
%      PID_Classique_Control_load_disturbance.slx, jamais modifie       %
%      en place, PAS a partir d'une copie du nominal Fuzzy-PID.         %
%                                                                         %
% =========================================================================
%
% CORRECTION DE STRATEGIE PAR RAPPORT A LA PREMIERE VERSION DE CE SCRIPT
% (a ne pas refaire) : la premiere version partait d'une copie du nominal
% Fuzzy_PID_Control.slx (deja valide) et AJOUTAIT le mecanisme de
% perturbation par-dessus, ce qui obligeait a DETACHER "Series RLC
% Branch2" (la resistance de charge) du rail de masse et a la reconnecter
% a un nouveau noeud -- une manipulation PROGRAMMATIQUE de ports
% physiques (LConn/RConn) sur un reseau Simscape DEJA CONSTRUIT, jamais
% testee reellement (aucun acces a MATLAB dans cet environnement
% d'execution). C'etait le point le plus fragile de cette version,
% explicitement signale comme tel.
%
% Question posee a raison par l'utilisateur : pourquoi ne pas etre parti
% directement du fichier "PID_Classique_Control_load_disturbance.slx"
% fourni, qui contient DEJA le montage ΔR + interrupteur, cable a la main
% dans l'editeur Simulink (donc fiable par construction, sans aucun risque
% de manipulation programmatique de ports physiques) ? Reponse : aucune
% raison valable, seulement la reconduction non questionnee du patron
% utilise pour F1 ("copier le nominal, ajouter des blocs par-dessus"),
% pertinent pour F1 (perturbation purement signal) mais PAS pour F2
% (perturbation physique, avec un fichier de reference DEJA cable a
% disposition).
%
% STRATEGIE CORRIGEE, retenue dans cette version : partir du fichier de
% reference (etage de puissance + mecanisme de perturbation herites TELS
% QUELS, jamais touches), retirer son PID classique (Sum1, PID
% Controller), et COPIER la chaine de commande Fuzzy-PID depuis le
% nominal Fuzzy_PID_Control.slx, bloc par bloc, avec un cablage
% INTEGRALEMENT VERIFIE par extraction directe du XML du nominal (pas
% devine) -- voir la liste des connexions dans le corps du script.
% Consequence directe : PLUS AUCUNE manipulation de port physique dans ce
% script. Toutes les operations restantes (copie de bloc entre modeles
% via add_block, cablage signal via ligne_si_possible) sont du meme type
% que celles deja EPROUVEES ailleurs dans ce projet (nominal, F1) --
% aucune ne touche a un port LConn/RConn.
%
% CORRECTION DE BUG (apres retour reel de simulation "desastreux" -- Vout
% et iL bloques a des valeurs ~1e4 fois trop petites) : diagnostic pose
% par inspection DIRECTE du XML du fichier .slx renvoye (pas suppose).
% Cause racine : en supprimant "PID Controller" (ETAPE A), sa ligne de
% SORTIE vers "PWM Generator"/1 n'est pas nettoyee par Simulink -- il
% reste une ligne FANTOME sur le port d'ENTREE de PWM Generator (Dst
% present dans le XML, Src absent). C'est l'exact symetrique, cote
% destination, du phenomene deja identifie et corrige cote source pour
% Vout/Constant1 apres la suppression de Sum1 (voir purge_branches_
% orphelines plus bas) -- mais seul le cote source avait ete traite dans
% la version precedente de ce script ; le cote destination (consequence
% de la suppression de "PID Controller", pas de "Sum1") avait ete oublie.
% Consequence : get_param(port,'Line') sur ce port ne retourne PAS -1
% (une ligne fantome y est toujours accrochee), donc ligne_si_possible
% (ETAPE D) conclut a tort que le port est deja cable et NE POSE JAMAIS
% la vraie connexion Loi_Incrementale_Fuzzy(mu) -> PWM Generator. Le
% Mosfet ne recoit alors aucune commande de rapport cyclique reelle,
% d'ou Vout/iL ecrases pres de zero, avec neanmoins une reaction visible
% aux instants 0.05s/0.07s puisque le mecanisme de perturbation, lui,
% est intact et independant de ce bug. Correction : nouvelle fonction
% purger_ligne_orpheline_entree, appelee juste apres la suppression de
% "PID Controller", qui libere reellement le port d'entree de PWM
% Generator avant que ETAPE D ne tente de le cabler.
%
% RAPPEL DE LA DEFINITION (Lu et al. 2021, section 5.3, "disturbance F2(t)
% is added to the load of the buck circuit") -- VERIFIEE DIRECTEMENT DANS
% LE TEXTE DU PAPIER (project_search sur "Paper de rulté .pdf") :
%
%   F2(t) = 0        , 0    < t < 0.05
%         = -2*R/15  , 0.05 < t < 0.07
%         = 0        , 0.07 < t < 0.2
%
% avec R = 5 ohms (valeur nominale du circuit), donc F2(t) = -0.6666... ohm
% sur la fenetre active : une variation RESISTIVE de la charge, R_eff(t) =
% R + F2(t). CE SCRIPT NE CONSTRUIT PAS ce mecanisme -- il est deja
% present, tel quel, dans le fichier de reference herite (voir plus bas).
%
% MECANISME PHYSIQUE HERITE (deja verifie par inspection XML directe du
% fichier de reference lors de la premiere version de ce script, non
% reproduit ici en detail -- voir l'historique de ce fichier) : une
% branche resistive Delta_R = (-2/15)*5 ohms en serie avec la resistance
% de charge principale R=5 ohms, un Ideal Switch en parallele de la seule
% branche Delta_R, commande par Step1(Time=0.05,Before=1,After=0) +
% Step2(Time=0.07,Before=0,After=1) sommes (Sum, Inputs=|+-). AVERTISSEMENT
% DE NOMMAGE : dans CE fichier de reference (contrairement au nominal), la
% resistance de charge PRINCIPALE s'appelle "Series RLC Branch3" et la
% branche Delta_R "Series RLC Branch2" -- noms herites tels quels, ce
% script ne les renomme pas (aucune raison de toucher a des blocs qu'il ne
% cable jamais).
%
% VALEURS DE REFERENCE DU PAPIER -- POUR ELM-PID UNIQUEMENT, PAS UNE CIBLE
% POUR FUZZY-PID (voir aussi Construction_Simulink_Fuzzy_PID_F1.m) : le
% papier rapporte, pour SON controleur ELM-PID (structure de commande
% differente), un pic de Vout a 110.6V et Kp/Ki/Kd stabilises a 18, 11 et
% 2.3e-4. Aucun chiffre specifique a Fuzzy-PID n'est fourni par le papier.
% Le vrai critere de validation reste le meme que pour F1 : retour COMPLET
% a Vref apres t=0.07s, mesure sur la vraie courbe, jamais suppose.
%
% CE QUE CE SCRIPT NE TOUCHE PAS :
% Ke, Kec, Kpu, Kiu, Kdu, la table de regles, KP_MAX/KI_MAX/KD_MAX et
% MU_MIN/MU_MAX (0.01/0.99, INCHANGES vs nominal -- F2 ne perturbe jamais
% mu, contrairement a F1) restent ceux valides en nominal : ils arrivent
% tels quels par la copie de bloc (add_block copie l'integralite du
% contenu Stateflow d'un bloc, y compris son Script), pas par reinjection
% de code. Une verification legere (ETAPE C) confirme malgre tout que le
% code copie encode bien ces valeurs -- jamais suppose acquis sans lecture.
% L'etage de puissance et le mecanisme de perturbation herites du fichier
% de reference ne sont JAMAIS modifies par ce script (aucun add_line ni
% delete_line sur un port LConn/RConn nulle part dans ce fichier).
%
% PREREQUIS :
%   - PID_Classique_Control_load_disturbance.slx (fichier de reference
%     fourni par l'utilisateur) dans le meme dossier.
%   - Fuzzy_PID_Control.slx (nominal Fuzzy-PID DEJA VALIDE) dans le meme
%     dossier -- source de la chaine de commande copiee ici.
%   - fuzzy_pid_buck.mat dans le meme dossier (reutilise tel quel).
% =========================================================================

clear; clc;

Vin  = 200;
Vref = 100;
T    = 5e-6;

fprintf('=== Parametres physiques (identiques au nominal Fuzzy-PID) ===\n');
fprintf('Vin=%.3g V  Vref=%.3g V  T=%.3g s\n', Vin, Vref, T);

% -------------------------------------------------------------------
% FIS ET FACTEURS D'ECHELLE : repris tels quels du nominal valide, aucun
% recalibrage.
% -------------------------------------------------------------------
if ~exist('fuzzy_pid_buck.mat', 'file')
    error(['Fichier fuzzy_pid_buck.mat introuvable. Il doit deja exister ' ...
           '(produit lors de la construction du nominal Fuzzy-PID).']);
end
d_fis = load('fuzzy_pid_buck.mat');
fisFuzzyPID = d_fis.fis;
Ke  = d_fis.Ke;
Kec = d_fis.Kec;
Kpu = d_fis.Kpu;
Kiu = d_fis.Kiu;
Kdu = d_fis.Kdu;
assignin('base', 'fisFuzzyPID', fisFuzzyPID);

fprintf('\nFIS repris du nominal (inchange) : %d regles, Ke=%.3g Kec=%.3g Kpu=%.3g Kiu=%.3g Kdu=%.3g\n', ...
    numel(fisFuzzyPID.Rules), Ke, Kec, Kpu, Kiu, Kdu);

% -------------------------------------------------------------------
% BORNES : TOUTES inchangees vs nominal (F2 ne touche jamais mu).
% Utilisees uniquement pour la VERIFICATION post-copie (ETAPE C).
% -------------------------------------------------------------------
KP_MAX = 50; KI_MAX = 50000; KD_MAX = 0.01;
MU_MIN_F2 = 0.01; MU_MAX_F2 = 0.99;

fprintf('Bornes controleur (inchangees) : KP_MAX=%.4g KI_MAX=%.4g KD_MAX=%.4g\n', KP_MAX, KI_MAX, KD_MAX);
fprintf('Bornes MU (inchangees vs nominal) : [%.2g, %.2g]\n', MU_MIN_F2, MU_MAX_F2);

% =====================================================================
% CONSTRUCTION DU MODELE SIMULINK
% Base = fichier de reference (etage de puissance + perturbation herites
% tels quels). Source de la chaine de commande = nominal Fuzzy-PID valide.
% =====================================================================
modele_reference = 'PID_Classique_Control_load_disturbance';
modele_nominal    = 'Fuzzy_PID_Control';
mdl = 'Fuzzy_PID_Control_F2';

if ~exist([modele_reference '.slx'], 'file')
    error(['Fichier %s.slx introuvable (fichier de reference du mecanisme de perturbation de ' ...
           'charge, fourni par l''utilisateur). Placez-le dans le meme dossier que ce script.'], ...
           modele_reference);
end
if ~exist([modele_nominal '.slx'], 'file')
    error(['Fichier %s.slx introuvable (nominal Fuzzy-PID deja valide, source de la chaine de ' ...
           'commande). Placez-le dans le meme dossier que ce script.'], modele_nominal);
end
if bdIsLoaded(modele_reference); close_system(modele_reference, 0); end
if bdIsLoaded(modele_nominal); close_system(modele_nominal, 0); end
if bdIsLoaded(mdl); close_system(mdl, 0); end

if ~exist([mdl '.slx'], 'file')
    copyfile([modele_reference '.slx'], [mdl '.slx']);
    fprintf('\n%s.slx cree (copie du fichier de reference %s.slx, original non modifie).\n', mdl, modele_reference);
else
    fprintf('\n%s.slx existe deja -- reutilise (pas de re-copie).\n', mdl);
end
load_system(mdl);
load_system(modele_nominal);   % doit rester charge : source des blocs copies ci-dessous (add_block)

set_param(mdl, 'ReturnWorkspaceOutputs', 'off');   % regle de construction n=8 (memoire de projet) -- le fichier de reference l'a a 'on' par defaut
set_param(mdl, 'StopTime', '0.2');                  % deja 0.2 dans le fichier de reference, fixe explicitement par securite

nom_pwm = sprintf('PWM Generator\n(DC-DC)');

% -------------------------------------------------------------------
% ETAPE A : retrait du PID classique herite du fichier de reference
% (Sum1 = calcul d'erreur Vref-Vout, "PID Controller" = bloc PID continu
% standard Simulink). Idempotent (verifie avant de supprimer).
% -------------------------------------------------------------------
if ~isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'PID Controller'))
    delete_block([mdl '/PID Controller']);
    fprintf('Bloc "PID Controller" (PID classique herite) supprime dans %s.\n', mdl);
else
    fprintf('Bloc "PID Controller" deja absent dans %s.\n', mdl);
end

% PURGE DE LA LIGNE FANTOME LAISSEE SUR L'ENTREE DE PWM GENERATOR --
% "PID Controller" pilotait PWM Generator/1 dans le fichier de reference ;
% le supprimer laisse une ligne fantome (Dst present, Src absent dans le
% XML) sur ce port d'entree -- symetrique, cote destination, du phenomene
% deja traite plus bas cote source pour Vout/Constant1 apres suppression
% de Sum1. Sans cette purge, ligne_si_possible (ETAPE D) croit ce port
% deja cable et NE POSE JAMAIS le vrai signal mu -- c'est la cause
% racine, confirmee par inspection XML directe, du resultat "desastreux"
% (Vout/iL ecrases pres de zero) obtenu avec la version precedente de ce
% script. Idempotent : si le port est deja cable par une VRAIE source
% (Loi_Incrementale_Fuzzy, apres un run precedent reussi), la fonction ne
% touche a rien.
purger_ligne_orpheline_entree(mdl, nom_pwm, 1);

if ~isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Sum1'))
    delete_block([mdl '/Sum1']);
    fprintf('Bloc "Sum1" (calcul d''erreur du PID classique herite) supprime dans %s.\n', mdl);
else
    fprintf('Bloc "Sum1" deja absent dans %s.\n', mdl);
end

if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Constant1'))
    error('Bloc "Constant1" introuvable dans %s -- copie du fichier de reference corrompue ou incomplete.', mdl);
end
valConstant1_F2 = str2double(get_param([mdl '/Constant1'], 'Value'));
if abs(valConstant1_F2 - Vref) > 1e-9
    error(['"Constant1" vaut %.10g dans %s, different du Vref=%.10g utilise par ce script. ' ...
           'Ne pas cabler aveuglement.'], valConstant1_F2, mdl, Vref);
end
fprintf('Bloc "Constant1" (herite du fichier de reference) verifie = Vref = %.10g -- conserve et reutilise.\n', Vref);

% PURGE DES BRANCHES FANTOMES LAISSEES PAR LA SUPPRESSION DE SUM1 --
% meme technique que dans le nominal/F1 (voir ces fichiers pour le
% diagnostic complet). Necessaire ici : "Vout" alimentait Sum1 ET "Goto1"
% (branche vers le scope) -- supprimer Sum1 laisse une branche fantome sur
% cette ligne a embranchements (Constant1, elle, n'avait qu'une seule
% destination -- Sum1 -- donc rien a purger de son cote, mais l'appel
% reste inoffensif dans ce cas et sert de verification).
purge_branches_orphelines(mdl, 'Constant1', 1);
if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Vout'))
    error('Bloc "Vout" introuvable dans %s -- copie du fichier de reference corrompue ou incomplete.', mdl);
end
purge_branches_orphelines(mdl, 'Vout', 1);
if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'iL'))
    error('Bloc "iL" introuvable dans %s -- copie du fichier de reference corrompue ou incomplete.', mdl);
end

% -------------------------------------------------------------------
% ETAPE B : copie de la chaine de commande Fuzzy-PID depuis le nominal,
% bloc par bloc (add_block copie l'integralite du contenu d'un bloc,
% Stateflow inclus -- KP_MAX/KI_MAX/KD_MAX/MU_MIN/MU_MAX et la table de
% regles arrivent donc deja corrects, sans reinjection de code). Idempo-
% tent (copier_bloc_si_possible ne recopie pas un bloc deja present).
% Decalage de position (+0,+420) pour ne pas chevaucher la mise en page
% herite du fichier de reference -- purement cosmetique.
% -------------------------------------------------------------------
DECALAGE_Y = 420;
blocsChaineCommande = { ...
    'Echantillonneur_Fuzzy', 'Calcul_Erreur_Fuzzy', 'Echelle_e', 'Echelle_ce', ...
    'Mux_Entrees_FLC', 'FLC_Fuzzy_PID', 'Demux_Sorties_FLC', ...
    'Echelle_dKp', 'Echelle_dKi', 'Echelle_dKd', 'Loi_Incrementale_Fuzzy', ...
    'Log_mu_fuzzy', 'Log_Kp_fuzzy', 'Log_Ki_fuzzy', 'Log_Kd_fuzzy', ...
    'Scope_Commande_Fuzzy', 'Scope_Kp_Ki_Fuzzy', 'Scope_Kd_Fuzzy', ...
    'To Workspace', 'To Workspace1' ...
};
for i = 1:numel(blocsChaineCommande)
    copier_bloc_si_possible(mdl, modele_nominal, blocsChaineCommande{i}, [0 DECALAGE_Y]);
end
fprintf('Chaine de commande Fuzzy-PID copiee depuis "%s" (%d blocs, contenu Stateflow/FIS inclus).\n', ...
    modele_nominal, numel(blocsChaineCommande));

% Verification des ports APRES copie (jamais suppose identique au
% nominal sans lecture -- meme discipline que partout ailleurs) :
nb_ports_erreur = get_param([mdl '/Calcul_Erreur_Fuzzy'], 'Ports');
if nb_ports_erreur(1) ~= 2 || nb_ports_erreur(2) ~= 3
    error('"Calcul_Erreur_Fuzzy" copie a %d entree(s)/%d sortie(s) au lieu de 2/3 dans %s.', ...
        nb_ports_erreur(1), nb_ports_erreur(2), mdl);
end
nb_ports_loi = get_param([mdl '/Loi_Incrementale_Fuzzy'], 'Ports');
if nb_ports_loi(1) ~= 6 || nb_ports_loi(2) ~= 4
    error('"Loi_Incrementale_Fuzzy" copie a %d entree(s)/%d sortie(s) au lieu de 6/4 dans %s.', ...
        nb_ports_loi(1), nb_ports_loi(2), mdl);
end
fprintf('Verifie : "Calcul_Erreur_Fuzzy" (2 entrees/3 sorties) et "Loi_Incrementale_Fuzzy" (6 entrees/4 sorties) conformes apres copie.\n');

% -------------------------------------------------------------------
% ETAPE C : verification (pas reinjection -- voir en-tete) des bornes
% portees par le code Stateflow copie avec "Loi_Incrementale_Fuzzy".
% -------------------------------------------------------------------
S = sfroot;
chartLoi = S.find('-isa', 'Stateflow.EMChart', 'Path', [mdl '/Loi_Incrementale_Fuzzy']);
if isempty(chartLoi); error('Objet Stateflow.EMChart introuvable pour Loi_Incrementale_Fuzzy dans %s.', mdl); end
scriptLoi = chartLoi.Script;

valKP    = regexp(scriptLoi, 'KP_MAX\s*=\s*([0-9.eE+-]+);', 'tokens', 'once');
valKI    = regexp(scriptLoi, 'KI_MAX\s*=\s*([0-9.eE+-]+);', 'tokens', 'once');
valKD    = regexp(scriptLoi, 'KD_MAX\s*=\s*([0-9.eE+-]+);', 'tokens', 'once');
valMUMIN = regexp(scriptLoi, 'MU_MIN\s*=\s*([0-9.eE+-]+);', 'tokens', 'once');
valMUMAX = regexp(scriptLoi, 'MU_MAX\s*=\s*([0-9.eE+-]+);', 'tokens', 'once');

if isempty(valKP) || isempty(valKI) || isempty(valKD) || isempty(valMUMIN) || isempty(valMUMAX)
    error(['Verification "Loi_Incrementale_Fuzzy" impossible : au moins une des constantes ' ...
        'KP_MAX/KI_MAX/KD_MAX/MU_MIN/MU_MAX est introuvable dans le code Stateflow copie du ' ...
        'nominal -- copie corrompue. Arret plutot que de supposer correct sans verification.']);
end
ecart = [abs(str2double(valKP{1})    - KP_MAX), ...
         abs(str2double(valKI{1})    - KI_MAX), ...
         abs(str2double(valKD{1})    - KD_MAX), ...
         abs(str2double(valMUMIN{1}) - MU_MIN_F2), ...
         abs(str2double(valMUMAX{1}) - MU_MAX_F2)];
if any(ecart > 1e-9)
    error(['"Loi_Incrementale_Fuzzy" copie depuis le nominal encode KP_MAX=%s KI_MAX=%s KD_MAX=%s ' ...
        'MU_MIN=%s MU_MAX=%s, different des valeurs attendues (%.10g/%.10g/%.10g/%.10g/%.10g). ' ...
        'Le nominal source a change depuis la derniere validation -- ne pas continuer sans ' ...
        'reexaminer la situation.'], valKP{1}, valKI{1}, valKD{1}, valMUMIN{1}, valMUMAX{1}, ...
        KP_MAX, KI_MAX, KD_MAX, MU_MIN_F2, MU_MAX_F2);
end
fprintf(['Verifie : "Loi_Incrementale_Fuzzy" copie encode KP_MAX=%.10g KI_MAX=%.10g KD_MAX=%.10g ' ...
    'MU_MIN=%.10g MU_MAX=%.10g -- valeurs correctes.\n'], KP_MAX, KI_MAX, KD_MAX, MU_MIN_F2, MU_MAX_F2);

% -------------------------------------------------------------------
% ETAPE D : cablage de la chaine de commande -- CHAQUE connexion listee
% ci-dessous a ete extraite DIRECTEMENT du XML du nominal Fuzzy_PID_
% Control.slx (system_root.xml, section <Line> hors LineType="Connection"),
% pas devinee ni reconstruite de memoire. Uniquement des ports de SIGNAL
% (In/Out) -- ligne_si_possible, deja eprouvee sur le nominal et F1.
% -------------------------------------------------------------------
ligne_si_possible(mdl, 'Vout/1', 'Echantillonneur_Fuzzy/1');
ligne_si_possible(mdl, 'Vout/1', 'To Workspace/1');
ligne_si_possible(mdl, 'iL/1', 'To Workspace1/1');
ligne_si_possible(mdl, 'Constant1/1', 'Calcul_Erreur_Fuzzy/2');
ligne_si_possible(mdl, 'Echantillonneur_Fuzzy/1', 'Calcul_Erreur_Fuzzy/1');

ligne_si_possible(mdl, 'Calcul_Erreur_Fuzzy/1', 'Echelle_e/1');
ligne_si_possible(mdl, 'Calcul_Erreur_Fuzzy/1', 'Loi_Incrementale_Fuzzy/1');
ligne_si_possible(mdl, 'Calcul_Erreur_Fuzzy/2', 'Echelle_ce/1');
ligne_si_possible(mdl, 'Calcul_Erreur_Fuzzy/2', 'Loi_Incrementale_Fuzzy/2');
ligne_si_possible(mdl, 'Calcul_Erreur_Fuzzy/3', 'Loi_Incrementale_Fuzzy/3');

ligne_si_possible(mdl, 'Echelle_e/1', 'Mux_Entrees_FLC/1');
ligne_si_possible(mdl, 'Echelle_ce/1', 'Mux_Entrees_FLC/2');
ligne_si_possible(mdl, 'Mux_Entrees_FLC/1', 'FLC_Fuzzy_PID/1');
ligne_si_possible(mdl, 'FLC_Fuzzy_PID/1', 'Demux_Sorties_FLC/1');

ligne_si_possible(mdl, 'Demux_Sorties_FLC/1', 'Echelle_dKp/1');
ligne_si_possible(mdl, 'Demux_Sorties_FLC/2', 'Echelle_dKi/1');
ligne_si_possible(mdl, 'Demux_Sorties_FLC/3', 'Echelle_dKd/1');
ligne_si_possible(mdl, 'Echelle_dKp/1', 'Loi_Incrementale_Fuzzy/4');
ligne_si_possible(mdl, 'Echelle_dKi/1', 'Loi_Incrementale_Fuzzy/5');
ligne_si_possible(mdl, 'Echelle_dKd/1', 'Loi_Incrementale_Fuzzy/6');

ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/1', sprintf('%s/1', nom_pwm));
ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/1', 'Log_mu_fuzzy/1');
ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/1', 'Scope_Commande_Fuzzy/1');
ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/2', 'Log_Kp_fuzzy/1');
ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/2', 'Scope_Kp_Ki_Fuzzy/1');
ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/3', 'Log_Ki_fuzzy/1');
ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/3', 'Scope_Kp_Ki_Fuzzy/2');
ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/4', 'Log_Kd_fuzzy/1');
ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/4', 'Scope_Kd_Fuzzy/1');

fprintf('Cablage de la chaine de commande Fuzzy-PID verifie/complete (28 connexions, toutes verifiees contre le XML du nominal).\n');

% -------------------------------------------------------------------
% ETAPE E : verification que le mecanisme de perturbation herite n'a pas
% ete touche -- lecture seule, aucune modification. Sert de garde-fou
% contre une erreur de copie de fichier (mauvais fichier de reference,
% version modifiee entre-temps), pas contre une action de ce script
% lui-meme (qui ne cable jamais ces blocs).
% -------------------------------------------------------------------
blocsAttendus = {'Series RLC Branch2', 'Series RLC Branch3', 'Ideal Switch', 'Step1', 'Step2', 'Sum'};
for i = 1:numel(blocsAttendus)
    if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', blocsAttendus{i}))
        error(['Bloc "%s" (mecanisme de perturbation herite du fichier de reference) introuvable ' ...
            'dans %s -- fichier de reference incorrect ou corrompu.'], blocsAttendus{i}, mdl);
    end
end
valResistanceDeltaR = strtrim(get_param([mdl '/Series RLC Branch2'], 'Resistance'));
if ~strcmp(valResistanceDeltaR, '(-2/15)*5')
    error(['"Series RLC Branch2" (branche Delta_R heritee) a Resistance="%s" au lieu de ' ...
        '"(-2/15)*5" attendu -- fichier de reference different de celui deja verifie.'], valResistanceDeltaR);
end
fprintf('Verifie : mecanisme de perturbation herite du fichier de reference present et intact (aucune modification apportee par ce script).\n');

save_system(mdl, [], 'OverwriteIfChangedOnDisk', true);
fprintf('\nModele sauvegarde : %s.slx\n', mdl);

% =====================================================================
% ETAPE FINALE : nettoyage + verification du fichier .slx SUR DISQUE
% (purge des lignes decoratives + preuve que le fichier reste chargeable
% par Simulink -- meme technique que nominal/F1). PAS de comparaison de
% topologie stricte contre le nominal : la topologie physique de F2 est
% INTENTIONNELLEMENT differente (mecanisme de perturbation en plus,
% herite du fichier de reference plutot que du nominal).
% =====================================================================
if bdIsLoaded(mdl); close_system(mdl, 0); end
if bdIsLoaded(modele_nominal); close_system(modele_nominal, 0); end
finaliser_fichier_slx_F2([mdl '.slx']);
open_system(mdl);

fprintf(['\nRappel : le mecanisme de perturbation (etage de puissance) provient du fichier de ' ...
    'reference et n''a subi AUCUNE modification programmatique -- le seul travail de ce script a ' ...
    'ete la copie et le cablage de la chaine de commande Fuzzy-PID (operations signal uniquement, ' ...
    'deja eprouvees dans ce projet). Une inspection visuelle rapide de %s.slx avant le premier run ' ...
    'reste une bonne pratique (verifier que rien ne se chevauche visuellement apres le decalage de ' ...
    'position), mais ne porte plus sur un risque de court-circuit ou de topologie incorrecte.\n\n'], mdl);

% =====================================================================
% FONCTIONS LOCALES (doivent rester en fin de fichier)
% =====================================================================
function ligne_si_possible(mdl, src, dst)
% Identique a la fonction du script de construction nominal et de F1 --
% voir ces fichiers pour la justification complete (verification directe
% de l'etat du port de destination via PortHandles/Line, plutot que
% d'intercepter et d'interpreter le texte d'une erreur d'add_line).
    idxSlash = find(dst == '/', 1, 'last');
    if isempty(idxSlash)
        add_line(mdl, src, dst, 'autorouting', 'on');
        return;
    end
    blocDst = dst(1:idxSlash-1);
    numPort = str2double(dst(idxSlash+1:end));
    ph = get_param([mdl '/' blocDst], 'PortHandles');
    if numPort > numel(ph.Inport)
        error('ligne_si_possible:portIntrouvable', ...
            ['Le port d''entree %d de "%s" n''existe pas (%d port(s) d''entree ' ...
             'trouve(s) sur ce bloc). Verifiez le nom/l''index de port.'], ...
            numPort, blocDst, numel(ph.Inport));
    end
    if get_param(ph.Inport(numPort), 'Line') ~= -1
        fprintf('Ligne %s -> %s deja presente (port verifie occupe) -- ignoree.\n', src, dst);
    else
        add_line(mdl, src, dst, 'autorouting', 'on');
        fprintf('Ligne %s -> %s posee.\n', src, dst);
    end
end

function purge_branches_orphelines(mdl, blocSrc, numPortSrc)
% Identique a la fonction du script de construction nominal et de F1 --
% voir ces fichiers pour le diagnostic complet (branche fantome laissee
% par delete_block sur une ligne a embranchements, confirme par
% inspection directe du XML du .slx). Capture les vraies destinations,
% supprime la ligne entiere, la reconstruit sans la branche fantome.
% Idempotent -- et inoffensif quand il n'y a rien a purger (rapporte
% simplement "rien a purger").
    ph = get_param([mdl '/' blocSrc], 'PortHandles');
    if numPortSrc > numel(ph.Outport)
        error('purge_branches_orphelines:portIntrouvable', ...
            'Le port de sortie %d de "%s" n''existe pas.', numPortSrc, blocSrc);
    end
    portSrc = ph.Outport(numPortSrc);
    ligneH = get_param(portSrc, 'Line');
    if ligneH == -1
        fprintf('"%s" (sortie %d) : aucune ligne posee -- rien a purger.\n', blocSrc, numPortSrc);
        return;
    end

    dstBlocH = get_param(ligneH, 'DstBlockHandle');
    dstPortH = get_param(ligneH, 'DstPortHandle');
    nbTotal = numel(dstBlocH);

    dstChemins = {};
    dstNumPorts = [];
    for i = 1:nbTotal
        if dstBlocH(i) ~= -1 && ishandle(dstBlocH(i))
            dstChemins{end+1} = getfullname(dstBlocH(i)); %#ok<AGROW>
            dstNumPorts(end+1) = get_param(dstPortH(i), 'PortNumber'); %#ok<AGROW>
        end
    end
    nbAvant = numel(dstChemins);

    if nbAvant < nbTotal
        fprintf('%d branche(s) fantome(s) (sans destination reelle) detectee(s) et eliminee(s) sur la ligne issue de "%s" (sortie %d).\n', ...
            nbTotal - nbAvant, blocSrc, numPortSrc);
    end
    if nbAvant == 0
        fprintf(2, ['*** ATTENTION : la ligne issue de "%s" (sortie %d) n''a AUCUNE destination ' ...
            'reelle. Suppression sans reconnexion -- verifiez manuellement si un cablage etait ' ...
            'pourtant attendu ici.\n'], blocSrc, numPortSrc);
    end

    delete_line(ligneH);

    ph = get_param([mdl '/' blocSrc], 'PortHandles');
    portSrc = ph.Outport(numPortSrc);
    for i = 1:nbAvant
        phDst = get_param(dstChemins{i}, 'PortHandles');
        add_line(mdl, portSrc, phDst.Inport(dstNumPorts(i)), 'autorouting', 'on');
    end

    fprintf(['Ligne issue de "%s" (sortie %d) reconstruite : %d destination(s) reelle(s) ' ...
        'conservee(s), toute branche fantome (sans destination) eliminee.\n'], ...
        blocSrc, numPortSrc, nbAvant);
end

function purger_ligne_orpheline_entree(mdl, blocDst, numPortDst)
% Symetrique de purge_branches_orphelines, mais cote ENTREE. Necessaire
% quand un bloc X est supprime alors que SA PROPRE sortie alimentait le
% port d'entree d'un autre bloc encore present (ici : "PID Controller",
% supprime, alimentait "PWM Generator"/1, qui reste). Simulink ne
% nettoie pas toujours cette ligne des deux cotes : elle peut rester
% accrochee au port de destination avec un handle de ligne valide
% (get_param(port,'Line') ~= -1) mais sans source reelle (SrcBlockHandle
% == -1) -- confirme par inspection directe du XML (<Line> avec <P
% Name="Dst"> mais sans <P Name="Src">). Un tel port trompe
% ligne_si_possible, qui le croit deja cable et n'y pose jamais le vrai
% signal. Cette fonction detecte precisement ce cas (ligne presente MAIS
% sans source valide) et la supprime pour liberer reellement le port.
% Idempotente et sans danger : si une VRAIE ligne existe deja (source
% valide), elle n'est pas touchee.
    ph = get_param([mdl '/' blocDst], 'PortHandles');
    if numPortDst > numel(ph.Inport)
        error('purger_ligne_orpheline_entree:portIntrouvable', ...
            'Le port d''entree %d de "%s" n''existe pas.', numPortDst, blocDst);
    end
    portDst = ph.Inport(numPortDst);
    ligneH = get_param(portDst, 'Line');
    if ligneH == -1
        fprintf('"%s" (entree %d) : aucune ligne posee -- rien a purger.\n', blocDst, numPortDst);
        return;
    end

    srcBlocH = get_param(ligneH, 'SrcBlockHandle');
    if ~isempty(srcBlocH) && srcBlocH ~= -1 && ishandle(srcBlocH)
        fprintf(['"%s" (entree %d) : ligne existante avec source reelle valide ("%s") -- ' ...
            'conservee (ce n''est pas une orpheline).\n'], ...
            blocDst, numPortDst, getfullname(srcBlocH));
        return;
    end

    delete_line(ligneH);
    fprintf(['"%s" (entree %d) : ligne fantome (sans source valide, laissee par la suppression ' ...
        'du bloc qui l''alimentait) supprimee -- port desormais reellement libre.\n'], ...
        blocDst, numPortDst);
end

function copier_bloc_si_possible(mdl, modeleSource, nomBloc, decalagePosition)
% Copie un bloc depuis "modeleSource" (deja charge) vers "mdl", sous le
% MEME nom, via add_block -- copie l'integralite du contenu du bloc,
% Stateflow/FIS/parametres inclus (contrairement a une reinjection de
% code, qui ne recopie que le texte d'un script Stateflow). Idempotent :
% ne recopie pas un bloc deja present sous ce nom dans "mdl". Applique un
% decalage de position (purement cosmetique, pour ne pas chevaucher la
% mise en page heritee du fichier de reference) -- l'echec de ce
% positionnement (try/catch) n'empeche jamais la copie elle-meme de
% reussir, seul le bloc resterait a sa position par defaut.
    if ~isempty(find_system(mdl, 'SearchDepth', 1, 'Name', nomBloc))
        fprintf('Bloc "%s" deja present dans %s -- pas de nouvelle copie.\n', nomBloc, mdl);
        return;
    end
    if isempty(find_system(modeleSource, 'SearchDepth', 1, 'Name', nomBloc))
        error('copier_bloc_si_possible:sourceIntrouvable', ...
            'Bloc "%s" introuvable dans le modele source "%s" -- copie impossible.', nomBloc, modeleSource);
    end
    add_block([modeleSource '/' nomBloc], [mdl '/' nomBloc]);
    try
        posSource = get_param([modeleSource '/' nomBloc], 'Position');
        set_param([mdl '/' nomBloc], 'Position', posSource + [decalagePosition, decalagePosition]);
    catch
        % Purement cosmetique -- une position par defaut n'affecte ni la
        % connectivite ni le comportement du bloc copie.
    end
    fprintf('Bloc "%s" copie depuis "%s".\n', nomBloc, modeleSource);
end

function finaliser_fichier_slx_F2(fichierCible)
% Purge les lignes purement decoratives et prouve que le fichier reecrit
% reste chargeable par Simulink -- meme technique que nominal/F1. PAS de
% comparaison de topologie contre le nominal (voir justification au point
% d'appel, dans le corps principal du script) : l'etage de puissance de
% F2 est intentionnellement different (herite du fichier de reference,
% jamais du nominal).
    if ~isfile(fichierCible)
        error('finaliser_fichier_slx_F2:fichierIntrouvable', ...
            'Fichier introuvable : %s', fichierCible);
    end

    texte = lire_system_root_xml(fichierCible);
    [texteNettoye, nbSupprimees] = purger_lignes_decoratives_texte(texte);

    if nbSupprimees > 0
        ecrire_system_root_xml(fichierCible, texteNettoye);
        fprintf('Finalisation : %d ligne(s) purement decorative(s) supprimee(s) de %s.\n', ...
            nbSupprimees, fichierCible);
    else
        fprintf('Finalisation : aucune ligne decorative dans %s.\n', fichierCible);
    end

    reseauxCible = extraire_reseaux_physiques_texte(lire_system_root_xml(fichierCible));
    if isempty(reseauxCible)
        error('finaliser_fichier_slx_F2:lectureEchouee', ...
            ['Aucun noeud physique extrait de "%s" -- lecture/extraction probablement en echec ' ...
             '(fichier vide, corrompu, ou bug d''extraction). Verification interrompue plutot que ' ...
             'de valider a tort.'], fichierCible);
    end

    [~, nomModele] = fileparts(fichierCible);
    try
        load_system(fichierCible);
        close_system(nomModele, 0);
    catch ME
        error('finaliser_fichier_slx_F2:fichierIllisibleParSimulink', ...
            ['Le fichier "%s" a ete rebati (contenu XML verifie non vide ci-dessus) mais Simulink ' ...
             'lui-meme ne parvient pas a le charger : %s. L''archive .slx est donc invalide malgre ' ...
             'un contenu textuel correct -- NE PAS utiliser ce fichier tel quel.'], fichierCible, ME.message);
    end

    fprintf('Finalisation : %d noeud(s) physique(s) present(s) dans "%s", fichier confirme chargeable par Simulink (load_system reussi).\n', ...
        numel(reseauxCible), fichierCible);
end

function texte = lire_system_root_xml(fichierSlx)
% Identique a la fonction du script de construction nominal et de F1.
    dossierTmp = tempname();
    mkdir(dossierTmp);
    nettoyeur = onCleanup(@() rmdir(dossierTmp, 's')); %#ok<NASGU>
    try
        unzip(fichierSlx, dossierTmp);
    catch ME
        error('lire_system_root_xml:unzipEchec', ...
            'Echec de l''extraction de "%s" : %s', fichierSlx, ME.message);
    end
    cheminXml = fullfile(dossierTmp, 'simulink', 'systems', 'system_root.xml');
    if ~isfile(cheminXml)
        error('lire_system_root_xml:xmlIntrouvable', ...
            '"simulink/systems/system_root.xml" introuvable dans %s -- fichier .slx inattendu.', ...
            fichierSlx);
    end
    texte = fileread(cheminXml);
end

function ecrire_system_root_xml(fichierSlx, texteNouveau)
% Identique a la fonction du script de construction nominal et de F1.
    dossierTmp = tempname();
    mkdir(dossierTmp);
    nettoyeur = onCleanup(@() rmdir(dossierTmp, 's')); %#ok<NASGU>

    unzip(fichierSlx, dossierTmp);

    cheminXml = fullfile(dossierTmp, 'simulink', 'systems', 'system_root.xml');
    fid = fopen(cheminXml, 'w');
    if fid == -1
        error('ecrire_system_root_xml:ecritureEchec', ...
            'Impossible d''ouvrir "%s" en ecriture.', cheminXml);
    end
    try
        fwrite(fid, unicode2native(texteNouveau, 'UTF-8'), 'uint8');
    catch ME
        fclose(fid);
        rethrow(ME);
    end
    fclose(fid);

    fichiers = recenser_fichiers(dossierTmp);

    fichierZipTmp = [fichierSlx '.tmp'];
    if isfile(fichierZipTmp); delete(fichierZipTmp); end
    flux = java.io.FileOutputStream(fichierZipTmp);
    zipOut = java.util.zip.ZipOutputStream(flux);
    try
        for i = 1:numel(fichiers)
            cheminAbsolu = fichiers{i};
            nomEntree = strrep(erase(cheminAbsolu, [dossierTmp filesep]), filesep, '/');
            zipOut.putNextEntry(java.util.zip.ZipEntry(nomEntree));
            fidLecture = fopen(cheminAbsolu, 'r');
            if fidLecture == -1
                zipOut.close();
                error('ecrire_system_root_xml:lectureEchec', ...
                    'Impossible d''ouvrir "%s" en lecture.', cheminAbsolu);
            end
            octetsFichier = fread(fidLecture, Inf, '*uint8');
            fclose(fidLecture);
            if ~isempty(octetsFichier)
                zipOut.write(typecast(octetsFichier, 'int8'), 0, numel(octetsFichier));
            end
            zipOut.closeEntry();
        end
    catch ME
        zipOut.close();
        rethrow(ME);
    end
    zipOut.close();

    if ~isfile(fichierZipTmp)
        error('ecrire_system_root_xml:zipEchec', ...
            'La reecriture de l''archive n''a pas produit le fichier attendu (%s).', fichierZipTmp);
    end

    if isfile(fichierSlx); delete(fichierSlx); end
    movefile(fichierZipTmp, fichierSlx);
end

function fichiers = recenser_fichiers(dossier)
% Identique a la fonction du script de construction nominal et de F1.
    tout = dir(fullfile(dossier, '**', '*'));
    tout = tout(~[tout.isdir]);
    fichiers = fullfile({tout.folder}, {tout.name});
end

function [texteNettoye, nbSupprimees] = purger_lignes_decoratives_texte(texte)
% Identique a la fonction du script de construction nominal et de F1.
    [debuts, fins] = regexp(texte, '<Line>.*?</Line>', 'start', 'end', 'dotall');
    nbSupprimees = 0;
    morceaux = {};
    curseur = 1;
    for i = 1:numel(debuts)
        d = debuts(i); f = fins(i);
        contenu = texte(d:f);
        aSrcOuDst = contains(contenu, 'Name="Src"') || contains(contenu, 'Name="Dst"');
        morceaux{end+1} = texte(curseur:d-1); %#ok<AGROW>
        if aSrcOuDst
            morceaux{end+1} = contenu; %#ok<AGROW>
        else
            nbSupprimees = nbSupprimees + 1;
        end
        curseur = f + 1;
    end
    morceaux{end+1} = texte(curseur:end); %#ok<AGROW>
    texteNettoye = strjoin(morceaux, '');
end

function reseaux = extraire_reseaux_physiques_texte(texte)
% Identique a la fonction du script de construction nominal et de F1.
    [debuts, fins] = regexp(texte, '<Line[^>]*>.*?</Line>', 'start', 'end', 'dotall');
    reseaux = {};
    for i = 1:numel(debuts)
        contenu = texte(debuts(i):fins(i));
        enTete = regexp(contenu, '^<Line[^>]*>', 'match', 'once');
        if isempty(strfind(enTete, 'LineType="Connection"')) %#ok<STREMP>
            continue;
        end
        refs = regexp(contenu, '<P Name="(?:Src|Dst)">([^<]+)</P>', 'tokens');
        extremites = {};
        for k = 1:numel(refs)
            extremites{end+1} = refs{k}{1}; %#ok<AGROW>
        end
        if ~isempty(extremites)
            extremites = unique(extremites);
            reseaux{end+1} = strjoin(sort(extremites), ' | '); %#ok<AGROW>
        end
    end
    reseaux = unique(reseaux);
end
