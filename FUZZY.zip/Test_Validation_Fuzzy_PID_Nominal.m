%% Test_Validation_Fuzzy_PID_Nominal.m
% =========================================================================
%                                                                         %
%   TEST DE NON-REGRESSION -- CAS NOMINAL FUZZY-PID                     %
%   apres le correctif des branches fantomes / ligne flottante          %
%                                                                         %
% =========================================================================
%
% OBJECTIF DE CE SCRIPT
% ----------------------
% Le nettoyage applique dans Construction_Simulink_Fuzzy_PID.m (ETAPE A :
% suppression de Sum1, purge des branches fantomes sur Constant1 et Vout,
% purge de la ligne totalement flottante) n'a touche QUE le cablage du
% schema -- aucun parametre physique, aucune borne (KP_MAX/KI_MAX/KD_MAX,
% MU_MIN/MU_MAX), aucun facteur d'echelle (Ke/Kec/Kpu/Kiu/Kdu), aucune
% ligne de code des blocs MATLAB Function/Stateflow. Ce script ne SUPPOSE
% PAS que ce raisonnement est juste : il relance reellement la simulation
% et compare aux chiffres precedemment valides, courbe par courbe, jamais
% sur un seul chiffre agrege (regle de validation du projet, non
% negociable).
%
% CORRECTIF IMPORTANT (diagnostic pose apres avoir compare, octet pour
% octet via le XML de l'archive .slx, le fichier de la derniere
% validation confirmee au fichier reconstruit aujourd'hui) -- ERREUR A NE
% PAS REPRODUIRE : KI_REF/RIPPLE_REF ci-dessous proviennent d'un
% Fuzzy_PID_Control.slx OU LES BLOCS Echelle_e/Echelle_ce/Echelle_dKd
% N'AVAIENT PAS de parametre Gain explicite (donc Gain=1 par defaut,
% Simulink omet de l'archive une valeur qui coincide avec le defaut du
% bloc) -- c'est-a-dire un modele ou Ke/Kec/Kdu valaient tous 1, PAS
% Ke=100/Kec=1e4/Kdu=5e-6 comme le rapporte le texte de la console. Le
% script de construction actuel configure bien ces gains a chaque
% execution (voir ETAPE de configuration des blocs Echelle_*), mais ce
% fichier de reference a ete produit par une version plus ancienne du
% script, d'avant l'ajout de cette configuration. Comparer la simulation
% d'aujourd'hui (mise a l'echelle reellement appliquee) a ces chiffres
% (mise a l'echelle jamais appliquee) revient a comparer deux modeles
% differents, pas a verifier une non-regression -- le Ki, motrice
% integrale qui converge de toute facon vers la valeur annulant l'erreur
% en regime etabli quel que soit le chemin d'adaptation emprunte, matche
% par coincidence (0.00% d'ecart observe) ; le ripple, lui, depend
% directement de la dynamique d'adaptation floue et diverge donc (5.34%
% observes) -- ce n'est PAS le signe d'une reconnexion sur le mauvais
% port. La ETAPE 1bis ci-dessous verifie desormais directement, sur le
% fichier construit aujourd'hui, que ces gains sont bien ceux annonces
% par la console de construction, pour ne plus jamais rejouer cette
% confusion. Le VRAI sujet ouvert, revele par cette mise a l'echelle
% desormais realmente appliquee, est que Kp/Kd/mu saturent l'essentiel de
% la simulation (voir ETAPE 4bis) -- symptome attendu de facteurs
% d'echelle encore en placeholders, pas un bug de cablage.
%
% CE QUE CE SCRIPT NE FAIT PAS
% ------------------------------
% Il ne reconstruit rien et ne modifie ni ne sauvegarde le modele
% (aucun save_system) -- lecture et simulation seulement, execution sans
% aucun risque pour Fuzzy_PID_Control.slx. Si vous n'avez pas encore
% relance Construction_Simulink_Fuzzy_PID.m avec le dernier correctif,
% faites-le d'abord : ce test suppose le fichier deja a jour sur le
% disque.
%
% CE QUE "REUSSITE" VEUT DIRE ICI
% ---------------------------------
% Le Ki reste compare a la reference a 1% pres (metrique robuste, sa
% convergence en regime etabli ne depend que faiblement du chemin
% d'adaptation). Le ripple n'est plus juge contre KI_REF/RIPPLE_REF --
% voir le correctif ci-dessus -- il est affiche a titre informatif
% seulement, en attendant qu'une nouvelle reference soit capturee une
% fois les facteurs d'echelle calibres.
%
% AJOUT (ETAPE 4ter) : un run reel precedent a QUANTIFIE la saturation
% deja visible sur les courbes (ETAPE 4bis) -- Kp quasi-nul 96.5% du
% temps, Kd a sa borne 90.9%, mu a son plafond 50.3%. L'hypothese posee a
% ce moment (Ke=100/Kec=1e4 poussant e_fis/ce_fis hors de la zone coeur du
% FIS, [-6,+6], meme en regime etabli) a ete TESTEE par mesure directe --
% et FALSIFIEE : e_fis et ce_fis restent quasi-totalement dans [-6,+6] en
% regime etabli (0.0% hors coeur pour les deux, max mesure 0.09 et 0.94
% respectivement). Ke/Kec ne sont donc PAS la cause de la saturation
% Kp/Kd/mu -- conclusion a ne plus reproduire.
%
% AJOUT (ETAPE 4quater) : deuxieme hypothese, formee apres lecture directe
% du code de "loi_incrementale_fuzzy" (Construction_Simulink_Fuzzy_PID.m) :
% Kp/Ki/Kd n'y sont pas recalcules a chaque pas depuis le FIS, ce sont des
% INTEGRATEURS bornes (Kp=min(KP_MAX,max(0,Kp1+dKp)), etc.), sans terme de
% fuite/anti-windup. Un increment dKp/dKi/dKd legerement biaise pres de
% l'equilibre (meme avec e_fis/ce_fis quasi nuls) suffit, accumule sur
% ~40000 pas, a faire deriver ces integrateurs jusqu'a une borne et les y
% maintenir. mu=duty cycle a son plafond 0.99 est d'autant plus suspect
% que le point de fonctionnement physique attendu est mu=Vref/Vin=100/200
% =0.5, tres loin de 0.99 -- ce n'est pas un regime nominal plausible.
% L'ETAPE 4quater mesure directement dKp/dKi/dKd (apres Kpu/Kiu/Kdu) en
% regime etabli pour verifier s'ils restent biaises de facon persistante
% pendant que le FIS lit pourtant une erreur quasi nulle.
%
% AJOUT (apres correction reelle de la regle (e=ZE,ce=ZE) dans
% construction_FIS_Fuzzy_PID.m -- dKp/dKd : NS->ZE) : un run reel
% CONFIRME l'effet attendu sur Kd (colle a sa borne 90.9%->0.0%) et sur
% Kp (quasi-nul 96.5%->0.2%, dKp desormais positif et variable, plus
% jamais negatif dans la fenetre mesuree). MAIS mu est reste QUASI
% INCHANGE (50.3%->50.2% de temps au plafond) -- la these que "mu herite
% du windup de Kd" ne tient donc PAS telle quelle : Kd sain ne suffit pas
% a guerir mu. ETAPE 4bis verifie maintenant AUSSI le plafond de Kp (le
% meme defaut pourrait s'etre deplace en signe oppose) et distingue un
% vrai gel de mu (un seul long contact continu) d'un simple battement
% haute frequence qui touche frequemment le plafond sans jamais s'y
% figer. ETAPE 4quinquies mesure directement xc1/xc2/xc3 (les entrees de
% la loi d'incrementation de mu, DISTINCTES de e_fis/ce_fis qui
% n'alimentent que le FIS) pour determiner si mu a son PROPRE biais
% structurel, independant de Kp/Kd.
% =========================================================================

clear; clc;

mdl = 'Fuzzy_PID_Control';

% Valeurs de reference de la derniere validation confirmee -- ATTENTION,
% voir le correctif ci-dessus : capturees sur un modele ou Ke/Kec/Kdu
% valaient encore 1 (mise a l'echelle non appliquee). RIPPLE_REF n'est
% plus une cible de non-regression valable ; KI_REF le reste (voir
% justification ci-dessus).
KI_REF     = 6183.17;   % A/s (gain integral en regime etabli)
RIPPLE_REF = 0.37;      % V crete a crete -- INFORMATIF SEULEMENT (modele de reference non a l'echelle)
TOLERANCE_PCT = 1.0;    % ecart maximal tolere sur Ki avant de parler de regression reelle

% DUREE DE SIMULATION ET FENETRE DE "REGIME ETABLI" -- rendues explicites
% et centralisees ici (au lieu des litteraux 0.18/0.2 disperses dans tout
% le fichier) suite au 9e test : Kp affichait encore une pente residuelle
% claire (+125/s) sur les derniers 20ms d'un run de 0.2s, ce qui ne
% permettait PAS de conclure s'il converge sous KP_MAX ou s'il derive
% juste plus lentement que Kd vers le meme sort (extrapolation naive :
% t=0.42s). T_SIM_STOP porte le run a 1s pour trancher reellement la
% question -- set_param ci-dessous l'applique au modele CHARGE EN MEMOIRE
% uniquement (aucun save_system dans ce fichier, comme pour tous les
% blocs de logging temporaires : Fuzzy_PID_Control.slx sur disque n'est
% jamais modifie par ce script). La fenetre de regime etabli reste les
% 20 derniers ms du run, quelle que soit sa duree totale -- change ici
% une seule fois, se repercute partout (ETAPE 3 a 4sexies) au lieu de
% devoir mettre a jour ~15 occurrences eparpillees a la main.
T_SIM_STOP   = 1;      % secondes -- ancien : 0.2s (jugee trop courte pour statuer sur Kp)
FENETRE_DEBUT = T_SIM_STOP - 0.02;
FENETRE_FIN   = T_SIM_STOP;

% Facteurs d'echelle attendus dans LE MODELE CONSTRUIT AUJOURD'HUI (tels
% que rapportes par la console de Construction_Simulink_Fuzzy_PID.m) --
% verifies directement sur les blocs Echelle_* en ETAPE 1bis, pour ne
% plus jamais decouvrir apres coup qu'une mise a l'echelle censee etre
% appliquee ne l'etait pas reellement.
KE_ATTENDU  = 100;
KEC_ATTENDU = 1e4;
KDU_ATTENDU = 5e-6;

if ~exist([mdl '.slx'], 'file')
    error(['%s.slx introuvable dans le dossier courant -- executez d''abord ' ...
           'Construction_Simulink_Fuzzy_PID.m (avec le dernier correctif).'], mdl);
end
if bdIsLoaded(mdl); close_system(mdl, 0); end
load_system(mdl);

% CORRECTIF (apres echec reel : "Unrecognized function or variable
% 'fisFuzzyPID'") -- le bloc natif "Fuzzy Logic Controller" (FLC_Fuzzy_PID)
% ne stocke pas son FIS par valeur : il le resout par NOM DE VARIABLE dans
% le workspace de base au moment de la simulation (deja documente dans
% Construction_Simulink_Fuzzy_PID.m, ETAPE C). Le "clear" en tete de ce
% script vide cette variable sans la recharger -- il faut donc reproduire
% ici exactement le meme chargement que le script de construction, avant
% tout sim().
if ~exist('fuzzy_pid_buck.mat', 'file')
    error(['fuzzy_pid_buck.mat introuvable dans le dossier courant -- ce fichier doit etre ' ...
           'present a cote de %s.slx (meme prerequis que pour la construction).'], mdl);
end
d_fis = load('fuzzy_pid_buck.mat');
assignin('base', 'fisFuzzyPID', d_fis.fis);
fprintf('FIS "fisFuzzyPID" recharge dans le workspace de base (%d regles).\n\n', numel(d_fis.fis.Rules));

% =========================================================================
% ETAPE 1 : VERIFICATION STRUCTURELLE
% (avant tout calcul numerique -- inutile de simuler un modele dont le
% cablage n'est pas dans l'etat attendu)
% =========================================================================
fprintf('=== ETAPE 1 : verification structurelle ===\n');

assert(isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'PID Controller')), ...
    'ECHEC STRUCTUREL : "PID Controller" est encore present -- fichier inattendu.');
fprintf('OK : "PID Controller" absent (attendu).\n');

assert(isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Sum1')), ...
    'ECHEC STRUCTUREL : "Sum1" est encore present -- fichier inattendu.');
fprintf('OK : "Sum1" absent (attendu).\n');

phConst = get_param([mdl '/Constant1'], 'PortHandles');
assert(get_param(phConst.Outport(1), 'Line') ~= -1, ...
    'ECHEC STRUCTUREL : "Constant1" n''est plus connecte -- regression du cablage.');
fprintf('OK : "Constant1" connecte.\n');

% Recherche de toute ligne totalement decorative residuelle -- lecture
% DIRECTE du fichier .slx sur disque (meme methode que
% "finaliser_fichier_slx" dans le script de construction), PAS via
% get_param('SrcBlockHandle'/'DstBlockHandle') sur le modele live comme
% le faisait une version anterieure de ce test. Ce critere live s'est
% revele peu fiable sur les lignes physiques Simscape (branches
% ConnectType=DEST_SRC/SRC_DEST/DEST_DEST, sans Src/Dst simple au niveau
% de la Line elle-meme) et aurait ici tres probablement signale a tort
% les connexions physiques reelles du circuit de puissance comme
% "flottantes", faisant echouer ce test pour une fausse raison -- exactement
% l'erreur deja commise une fois cette session sur ce meme critere. Ce
% script ne modifiant ni ne sauvegardant le modele, le fichier sur disque
% reflete exactement l'etat du modele charge : le lire directement est
% donc equivalent ici, et sans hypothese sur le comportement de l'API
% Simulink live.
nDecoratives = compter_lignes_decoratives_fichier([mdl '.slx']);
assert(nDecoratives == 0, ...
    'ECHEC STRUCTUREL : %d ligne(s) purement decorative(s) (sans Src ni Dst) subsiste(nt) dans %s.slx.', ...
    nDecoratives, mdl);
fprintf('OK : 0 ligne totalement decorative (verifie sur le fichier .slx, pas via l''API live).\n');

% ETAPE 1bis : verification directe que la mise a l'echelle est REELLEMENT
% appliquee sur les blocs Echelle_* -- ajoutee suite a la decouverte
% (voir en-tete de ce fichier) qu'un Fuzzy_PID_Control.slx anterieur
% annoncait Ke=100/Kec=1e4/Kdu=5e-6 en console sans que ces valeurs
% n'aient jamais ete reellement ecrites sur les blocs (Gain reste au
% defaut Simulink =1 tant que set_param n'a pas ete appele avec succes).
% Lire le TEXTE de la console ne suffit donc pas a garantir que la mise a
% l'echelle a eu lieu -- il faut l'interroger sur le modele lui-meme.
ke_reel  = str2double(get_param([mdl '/Echelle_e'],   'Gain'));
kec_reel = str2double(get_param([mdl '/Echelle_ce'],  'Gain'));
kdu_reel = str2double(get_param([mdl '/Echelle_dKd'], 'Gain'));
assert(abs(ke_reel - KE_ATTENDU) < 1e-9, ...
    'ECHEC STRUCTUREL : Echelle_e/Gain = %g, attendu %g -- la mise a l''echelle Ke n''est pas reellement appliquee.', ...
    ke_reel, KE_ATTENDU);
assert(abs(kec_reel - KEC_ATTENDU) < 1e-9, ...
    'ECHEC STRUCTUREL : Echelle_ce/Gain = %g, attendu %g -- la mise a l''echelle Kec n''est pas reellement appliquee.', ...
    kec_reel, KEC_ATTENDU);
assert(abs(kdu_reel - KDU_ATTENDU) < 1e-9, ...
    'ECHEC STRUCTUREL : Echelle_dKd/Gain = %g, attendu %g -- la mise a l''echelle Kdu n''est pas reellement appliquee.', ...
    kdu_reel, KDU_ATTENDU);
fprintf('OK : facteurs d''echelle reellement appliques (Ke=%g, Kec=%g, Kdu=%g) -- pas juste annonces en console.\n', ...
    ke_reel, kec_reel, kdu_reel);
fprintf('Verification structurelle COMPLETE -- passage a la simulation.\n\n');

% ETAPE 1ter : ajout de blocs "To Workspace" TEMPORAIRES pour logger
% directement e_fis (sortie Echelle_e) et ce_fis (sortie Echelle_ce) --
% ajoutee pour trancher, par une MESURE reelle et non plus une hypothese,
% la question laissee ouverte par l'ETAPE 4bis (Kp/Kd/mu satures
% l'essentiel du run). Hypothese a tester : Ke=100/Kec=1e4 poussent (e,
% ce) hors de la zone "coeur" ([-6,+6], voir construction_FIS_Fuzzy_PID.m
% : NS/ZE/PS couvrent exactement [-6,+6] pour e ET pour ce, au-dela ce
% sont des trapezes plats jusqu'a l'univers declare -- [-80,80] pour e,
% [-1000,1000] pour ce) meme en regime etabli (pas seulement au
% demarrage), ce qui ferait lire au FIS une "erreur extreme" en
% permanence.
%
% CORRECTIF (apres echec reel : "line does not have a parameter named
% 'DataLogging'") -- ERREUR A NE PAS REPRODUIRE : la premiere version de
% cette etape tentait d'activer le signal logging Simulink directement
% via set_param(ligne, 'DataLogging', 'on', ...) sur la ligne recuperee
% par get_param(PortHandles.Outport(1), 'Line'). Cette API existe mais
% s'est revelee indisponible telle quelle sur cette installation -- plutot
% que de deviner pourquoi (version de Simulink, configuration de projet,
% etc.), ce script reutilise le mecanisme deja EPROUVE sur ce meme modele
% : des blocs "To Workspace" (identique a Log_mu/Kp/Ki/Kd_fuzzy, deja lus
% avec succes plus bas dans ce script, et a la fonction
% extraire_temps_valeurs deja ecrite pour "y"). Blocs ajoutes SUR LE
% MODELE CHARGE EN MEMOIRE uniquement -- toujours aucun save_system, donc
% Fuzzy_PID_Control.slx sur disque n'est pas touche (invariant annonce en
% en-tete de ce fichier). Le branchement se fait par piquage (branch) sur
% la ligne existante Echelle_e->Mux_Entrees_FLC et Echelle_ce->Mux, sans
% toucher la connexion d'origine (un port de sortie Simulink peut driver
% plusieurs lignes).
add_block('simulink/Sinks/To Workspace', [mdl '/Log_e_fis_tmp'], ...
    'VariableName', 'e_fis_log', 'SaveFormat', 'Timeseries', 'Position', [400 20 460 40]);
add_block('simulink/Sinks/To Workspace', [mdl '/Log_ce_fis_tmp'], ...
    'VariableName', 'ce_fis_log', 'SaveFormat', 'Timeseries', 'Position', [400 60 460 80]);
add_line(mdl, 'Echelle_e/1', 'Log_e_fis_tmp/1', 'autorouting', 'on');
add_line(mdl, 'Echelle_ce/1', 'Log_ce_fis_tmp/1', 'autorouting', 'on');

% Idem pour les increments dKp/dKi/dKd APRES mise a l'echelle (Kpu/Kiu/Kdu),
% c'est-a-dire exactement ce que "Loi_Incrementale_Fuzzy" ajoute a
% Kp1/Ki1/Kd1 a chaque pas (voir ETAPE 4quater plus bas -- Kp/Ki/Kd y sont
% des INTEGRATEURS bornes, sans terme de fuite/anti-windup : un increment
% legerement biaise pres de l'equilibre suffit a les faire deriver jusqu'a
% une borne et y rester, meme si e_fis/ce_fis restent minuscules).
add_block('simulink/Sinks/To Workspace', [mdl '/Log_dKp_tmp'], ...
    'VariableName', 'dKp_log', 'SaveFormat', 'Timeseries', 'Position', [400 100 460 120]);
add_block('simulink/Sinks/To Workspace', [mdl '/Log_dKi_tmp'], ...
    'VariableName', 'dKi_log', 'SaveFormat', 'Timeseries', 'Position', [400 140 460 160]);
add_block('simulink/Sinks/To Workspace', [mdl '/Log_dKd_tmp'], ...
    'VariableName', 'dKd_log', 'SaveFormat', 'Timeseries', 'Position', [400 180 460 200]);
add_line(mdl, 'Echelle_dKp/1', 'Log_dKp_tmp/1', 'autorouting', 'on');
add_line(mdl, 'Echelle_dKi/1', 'Log_dKi_tmp/1', 'autorouting', 'on');
add_line(mdl, 'Echelle_dKd/1', 'Log_dKd_tmp/1', 'autorouting', 'on');

% Idem pour xc1/xc2(=ecn)/xc3, sorties de "Calcul_Erreur_Fuzzy" (eq. 13-14,
% Lu et al.) qui alimentent DIRECTEMENT l'incrementation de mu dans
% "loi_incrementale_fuzzy" : dmu = Kp1*xc1 + Ki1*xc2 + Kd1*xc3. C'est un
% integrateur borne DISTINCT de Kp/Ki/Kd (meme fonction, meme absence de
% terme de fuite), pilote par des signaux DIFFERENTS de e_fis/ce_fis (qui
% n'alimentent que le FIS, pas directement mu) -- Kp/Kd desormais sains
% (voir ETAPE 4bis apres correction de la regle (e=ZE,ce=ZE)) ne garantit
% donc PAS que mu le soit : un xc1 ou xc3 structurellement biaise en
% regime etabli suffirait a lui seul a faire deriver mu, meme avec des
% gains Kp1/Kd1 par ailleurs bien comportes.
add_block('simulink/Sinks/To Workspace', [mdl '/Log_xc2_tmp'], ...
    'VariableName', 'xc2_log', 'SaveFormat', 'Timeseries', 'Position', [400 220 460 240]);
add_block('simulink/Sinks/To Workspace', [mdl '/Log_xc1_tmp'], ...
    'VariableName', 'xc1_log', 'SaveFormat', 'Timeseries', 'Position', [400 260 460 280]);
add_block('simulink/Sinks/To Workspace', [mdl '/Log_xc3_tmp'], ...
    'VariableName', 'xc3_log', 'SaveFormat', 'Timeseries', 'Position', [400 300 460 320]);
add_line(mdl, 'Calcul_Erreur_Fuzzy/1', 'Log_xc2_tmp/1', 'autorouting', 'on');
add_line(mdl, 'Calcul_Erreur_Fuzzy/2', 'Log_xc1_tmp/1', 'autorouting', 'on');
add_line(mdl, 'Calcul_Erreur_Fuzzy/3', 'Log_xc3_tmp/1', 'autorouting', 'on');
fprintf(['Blocs de logging temporaires ajoutes (Echelle_e/ce -> e_fis_log/ce_fis_log, ' ...
    'Echelle_dKp/dKi/dKd -> dKp_log/dKi_log/dKd_log, Calcul_Erreur_Fuzzy/1-2-3 -> ' ...
    'xc2_log/xc1_log/xc3_log) pour les ETAPES 4ter/4quater/4quinquies.\n\n']);

% =========================================================================
% ETAPE 2 : SIMULATION
% =========================================================================
fprintf('=== ETAPE 2 : simulation ===\n');
set_param(mdl, 'ReturnWorkspaceOutputs', 'off');   % regle de construction n=8 (memoire de projet)
set_param(mdl, 'StopTime', num2str(T_SIM_STOP));   % 1s au lieu de 0.2s -- voir justification ci-dessus (statuer sur Kp)
tic;
sim(mdl);
fprintf('Simulation terminee en %.1f s.\n\n', toc);

% =========================================================================
% ETAPE 3 : EXTRACTION DES SIGNAUX
% =========================================================================
% "y" (bloc "To Workspace", variable Vout) n'a pas de SaveFormat explicite
% dans le fichier -- il herite du format par defaut de l'installation
% MATLAB qui l'a cree, potentiellement different d'une machine a l'autre
% (Timeseries, Structure, ou Array selon la version/les preferences).
% Plutot que de supposer un format unique, cette fonction locale detecte
% le format reellement obtenu et en extrait (temps, valeurs) de maniere
% robuste, quel que soit le cas.
[t_y, vals_y] = extraire_temps_valeurs(evalin('base', 'y'), 'y (Vout)');

% CORRECTIF (apres echec reel : "The logical indices contain a true
% value outside of the array bounds" plus loin sur fenetre_y) -- cause
% racine : le bloc "To Workspace" de "y" heritait du modele d'origine
% sans SaveFormat explicite, ce qui pouvait desynchroniser en interne le
% vecteur .Time et le vecteur .Data -- corrige depuis a la source dans
% Construction_Simulink_Fuzzy_PID.m (le bloc est desormais force en
% Timeseries ; SampleTime reste hERITE a -1, cale sur la sortie CONTINUE
% du reseau Simscape, pour ne pas sous-echantillonner l'ondulation
% reelle -- un timeseries garantit structurellement .Time et .Data de
% meme longueur, donc SaveFormat seul suffit). Verification explicite
% ici plutot que de laisser une eventuelle incoherence future ressurgir
% sous la forme opaque d'une erreur d'indexation logique plus bas dans
% ce script.
assert(numel(t_y) == numel(vals_y), ...
    ['ECHEC : "y" (Vout) a %d point(s) de temps pour %d valeur(s) -- grille temporelle ' ...
     'incoherente. Verifiez que le bloc "To Workspace" de "y" a bien SaveFormat=Timeseries ' ...
     '(relancez Construction_Simulink_Fuzzy_PID.m a jour si besoin).'], ...
    numel(t_y), numel(vals_y));

% Ki_fuzzy, Kp_fuzzy, Kd_fuzzy, mu_fuzzy : formes en Timeseries, imposees
% explicitement par le script de construction (SaveFormat='Timeseries') --
% format connu avec certitude, extraction directe.
ki_ts = evalin('base', 'Ki_fuzzy');
kp_ts = evalin('base', 'Kp_fuzzy');
kd_ts = evalin('base', 'Kd_fuzzy');
mu_ts = evalin('base', 'mu_fuzzy');

t_ki = ki_ts.Time; ki_vals = squeeze(ki_ts.Data);
t_kp = kp_ts.Time; kp_vals = squeeze(kp_ts.Data);
t_kd = kd_ts.Time; kd_vals = squeeze(kd_ts.Data);
t_mu = mu_ts.Time; mu_vals = squeeze(mu_ts.Data);

fprintf('Signaux extraits : y (%d points), Ki_fuzzy (%d points), Kp_fuzzy (%d points), Kd_fuzzy (%d points), mu_fuzzy (%d points).\n\n', ...
    numel(vals_y), numel(ki_vals), numel(kp_vals), numel(kd_vals), numel(mu_vals));

% =========================================================================
% ETAPE 4 : METRIQUES EN REGIME ETABLI
% =========================================================================
% Fenetre de regime etabli : derniers 20ms de la simulation (FENETRE_DEBUT
% a FENETRE_FIN, definies en tete de fichier -- 0.98 a 1s depuis le 9e
% test, contre 0.18 a 0.2s avant), coherente avec le reste du projet
% (regime etabli deja atteint bien avant ce point d'apres les runs
% precedents -- pas une fenetre choisie pour arranger le resultat).
fprintf('=== ETAPE 3 : metriques en regime etabli (fenetre [%.2f, %.2f]s) ===\n', FENETRE_DEBUT, FENETRE_FIN);

fenetre_y  = (t_y >= FENETRE_DEBUT) & (t_y <= FENETRE_FIN);
fenetre_ki = (t_ki >= FENETRE_DEBUT) & (t_ki <= FENETRE_FIN);

ripple_mesure = max(vals_y(fenetre_y)) - min(vals_y(fenetre_y));
ki_mesure = mean(ki_vals(fenetre_ki));
vout_moyen = mean(vals_y(fenetre_y));

fprintf('Vout moyen en regime etabli : %.4f V (cible : 100 V)\n', vout_moyen);
fprintf('Ripple Vout crete-a-crete   : %.4f V\n', ripple_mesure);
fprintf('Ki moyen en regime etabli   : %.4f\n\n', ki_mesure);

% =========================================================================
% ETAPE 4bis : FRACTION DU TEMPS PASSEE SATUREE (Kp, Kd, mu)
% =========================================================================
% Ajoutee suite a l'inspection visuelle des courbes de gains (discipline
% de validation du projet -- jamais un chiffre agrege seul). Bornes issues
% de la console de construction (KP_MAX=50, KD_MAX=0.01, MU=[0.01,0.99]).
%
% MISE A JOUR (apres correction de la regle (e=ZE,ce=ZE), voir en-tete) :
% l'ancienne ATTENTION ci-dessous accusait Ke/Kec -- deja definitivement
% ecarte par l'ETAPE 4ter. Kp est desormais verifie aux DEUX bornes (il
% ne s'effondrait plus a 0 apres le fix, mais rien ne garantit qu'il ne
% derive pas au contraire vers KP_MAX -- meme classe de defaut, signe
% oppose, a verifier explicitement plutot que suppose regle par
% deduction).
%
% MISE A JOUR (apres le 8e test) : EXACTEMENT LA MEME LECON EST APPLIQUEE
% ICI A Kd. Jusqu'a present, Kd n'etait verifie qu'a SA BORNE NEGATIVE
% (-KD_MAX) -- l'unique borne ou l'ancien bug (avant le 6e test) le
% coincait. Rien ne garantissait qu'il ne derive pas au contraire vers SA
% BORNE POSITIVE (+KD_MAX) une fois ce cote-la "gueri" -- c'est exactement
% le piege deja tombe une fois sur Kp entre le 6e et le 7e test (guerir un
% cote ne prouve rien sur l'autre). ETAPE 4quater (post-8e-test, run reel)
% donne dKd : moyenne=+3.13e-07, min=+6.46e-11 -- JAMAIS negatif sur les
% 4000 points de la fenetre [0.18,0.2]s, alors que Kd etait annonce "sain"
% depuis le 6e test sur la seule foi de sa borne negative. Le graphique
% reel (validation_nominale_gains.png) montre Kd grimper a ce qui
% ressemble a son plafond en ~5ms puis rester plat jusqu'a t=0.2s -- signe
% visuel d'un gel, pas d'une adaptation active. Ajout symetrique au check
% Kp ci-dessus : frac_kd_max mesure maintenant EXPLICITEMENT le temps
% passe a +KD_MAX, pour remplacer l'inference (moyenne/mine + lecture de
% graphique) par une mesure directe avant de conclure quoi que ce soit.
% DIAGNOSTIC KP_MAX EXECUTE ET CONCLU (voir Construction_Simulink_Fuzzy_
% PID.m, commentaire complet juste avant "KP_MAX = 50 ; ..." pour le
% raisonnement et les chiffres) : le relachement temporaire a 1000 a
% montre que Kp continue de grimper (~882 a t=1s, pente +87,7/s) SANS
% plafonnement naturel -- l'increment brut dKp (avant ecretage, logue
% independamment de la valeur de Kp) reste quasi constant (~+4,4 a
% +5,1e-4) quelle que soit la valeur de Kp ou son plafond, signature d'un
% WINDUP NON BORNE et non d'une convergence (la deceleration observee a
% KP_MAX=50 n'etait qu'un artefact de l'ecretage pres du plafond). Le
% plafond revient donc a sa valeur ELM-PID d'origine (50), qui n'est PAS
% un equilibre "decouvert" mais un choix delibere conserve tel quel --
% Kp partage desormais le meme diagnostic architectural que Kd (windup de
% table non elimine, mais impact negligeable sur dmu tant que le plafond
% reste raisonnable, voir ETAPE 4sexies). DOIT RESTER SYNCHRONISE avec la
% valeur reellement injectee dans loi_incrementale_fuzzy, sinon "Kp a son
% plafond" mesurerait contre le mauvais seuil et le resultat ne voudrait
% rien dire.
KP_MAX_ATTENDU = 50;
KD_MAX_ATTENDU = 0.01;
MU_MAX_ATTENDU = 0.99;
TOL_SATURATION = 1e-3;

frac_kp_nul   = 100 * mean(abs(kp_vals) < TOL_SATURATION);
frac_kp_max   = 100 * mean(kp_vals >= KP_MAX_ATTENDU - TOL_SATURATION);
frac_kd_borne = 100 * mean(kd_vals <= -KD_MAX_ATTENDU + TOL_SATURATION);
frac_kd_max   = 100 * mean(kd_vals >= KD_MAX_ATTENDU - TOL_SATURATION);
frac_mu_borne = 100 * mean(mu_vals >= MU_MAX_ATTENDU - TOL_SATURATION);

% Duree ininterrompue la plus longue a mu=plafond : distingue un vrai
% "gel" (windup, un seul bloc continu) d'un simple battement haute
% frequence qui touche frequemment le plafond sans jamais s'y figer
% (chaque contact bref, beaucoup de contacts) -- les deux donnent le MEME
% pourcentage global mais n'ont rien a voir mecaniquement.
au_plafond = mu_vals >= MU_MAX_ATTENDU - TOL_SATURATION;
transitions = diff([0; au_plafond(:); 0]);
debuts_run = find(transitions == 1);
fins_run   = find(transitions == -1) - 1;
if isempty(debuts_run)
    duree_max_plafond_s = 0;
    nb_contacts_plafond = 0;
else
    dt_moyen = mean(diff(t_mu));
    duree_max_plafond_s = max(fins_run - debuts_run + 1) * dt_moyen;
    nb_contacts_plafond = numel(debuts_run);
end

fprintf('=== ETAPE 4bis : fraction du temps en saturation (sur les 0.2s complets) ===\n');
fprintf('Kp quasi-nul (< %.0e)         : %5.1f%% du temps\n', TOL_SATURATION, frac_kp_nul);
fprintf('Kp a son plafond (%g)         : %5.1f%% du temps\n', KP_MAX_ATTENDU, frac_kp_max);
fprintf('Kd a sa borne negative (-%.g) : %5.1f%% du temps\n', KD_MAX_ATTENDU, frac_kd_borne);
fprintf('Kd a sa borne positive (+%.g) : %5.1f%% du temps\n', KD_MAX_ATTENDU, frac_kd_max);
fprintf('mu a son plafond (%.2f)       : %5.1f%% du temps, en %d contact(s), le plus long : %.4f s\n', ...
    MU_MAX_ATTENDU, frac_mu_borne, nb_contacts_plafond, duree_max_plafond_s);
if duree_max_plafond_s > 0.05
    fprintf(['ATTENTION : mu reste colle en un seul bloc continu de plus de 50ms -- signature d''un ' ...
        'gel/windup reel de son integrateur propre (loi_incrementale_fuzzy : mu=min(MU_MAX,max(' ...
        'MU_MIN,mu1+dmu)), avec dmu=Kp1*xc1+Ki1*xc2+Kd1*xc3), PAS un battement haute frequence normal. ' ...
        'A investiguer directement sur xc1/xc2/xc3 (sorties de Calcul_Erreur_Fuzzy), pas sur Kp/Kd eux-' ...
        'memes (deja verifies sains ci-dessus) ni sur Ke/Kec (deja ecartes par l''ETAPE 4ter).\n']);
elseif frac_mu_borne > 20
    fprintf(['NOTE : mu touche son plafond frequemment mais par contacts courts (le plus long : ' ...
        '%.4f s) -- plausiblement un battement haute frequence lie au ripple de commutation plutot ' ...
        'qu''un gel de l''integrateur. A confirmer par inspection visuelle de validation_nominale_' ...
        'gains.png (zoom temporel court) avant de conclure.\n'], duree_max_plafond_s);
end
if frac_kp_max > 20
    fprintf(['ATTENTION : Kp passe une part significative du run a SON PLAFOND (%g) -- a verifier : ' ...
        'meme classe de defaut que l''ancien Kd colle a sa borne negative, signe oppose. Voir si ' ...
        'd''autres cellules pres de l''equilibre (ce=NS/PS notamment, frequemment visitees d''apres ' ...
        'l''ETAPE 4ter) meritent le meme traitement que la regle (e=ZE,ce=ZE) deja corrigee.\n'], ...
        KP_MAX_ATTENDU);
end
if frac_kd_max > 5
    fprintf(['ATTENTION : Kd passe une part significative du run a SON PLAFOND POSITIF (+%g) -- meme ' ...
        'classe de defaut que Kp entre le 6e et le 7e test (guerir la borne negative ne prouve rien ' ...
        'sur la borne positive). Voir ETAPE 4quater : si la MOYENNE de dKd reste positive et son MIN ' ...
        'ne descend jamais sous zero sur cette fenetre, l''integrateur de Kd est pousse dans un seul ' ...
        'sens en permanence -- inspecter les regles ou e ET ce sont simultanement non nuls (cellules ' ...
        '(e=NS,ce=NS), (e=NS,ce=PS), (e=PS,ce=NS), (e=PS,ce=PS)), deja identifiees comme cellules de ' ...
        'bruit de ripple pur pour dKi (4e test) mais jamais revues pour dKp/dKd.\n'], KD_MAX_ATTENDU);
end
fprintf('\n');

% =========================================================================
% ETAPE 4ter : e_fis / ce_fis HORS ZONE COEUR -- VERIFICATION DIRECTE DE
% L'HYPOTHESE (plus une supposition depuis l'ETAPE 1ter)
% =========================================================================
% CORE_ZONE=6 : les fonctions d'appartenance NS/ZE/PS de "e" ET de "ce"
% couvrent exactement [-6,+6] (construction_FIS_Fuzzy_PID.m) ; au-dela, ce
% sont des trapezes PLATS (NB/PB) jusqu'a l'univers declare -- le FIS lit
% alors la MEME appartenance "extreme" que la valeur soit a 7 ou a 500.
CORE_ZONE = 6;

% Meme fonction d'extraction robuste que pour "y" (SaveFormat force en
% Timeseries a la creation du bloc en ETAPE 1ter -- format connu avec
% certitude, mais on reutilise extraire_temps_valeurs par coherence et
% defense en profondeur plutot que de supposer .Time/.Data directement).
[t_e, e_vals]   = extraire_temps_valeurs(evalin('base', 'e_fis_log'),  'e_fis_log');
[t_ce, ce_vals] = extraire_temps_valeurs(evalin('base', 'ce_fis_log'), 'ce_fis_log');
assert(numel(t_e) == numel(e_vals) && numel(t_ce) == numel(ce_vals), ...
    'ECHEC : e_fis_log/ce_fis_log ont un temps et des valeurs de longueurs differentes -- logging incoherent.');

% Nettoyage des blocs temporaires (ETAPE 1ter) : les donnees sont deja
% extraites dans e_vals/ce_vals ci-dessus, plus besoin des blocs. Purement
% cosmetique (le modele n'est de toute facon jamais sauvegarde), mais evite
% d'accumuler des blocs si ce script est relance plusieurs fois dans la
% meme session MATLAB sans fermer completement le modele entre deux runs.
delete_block([mdl '/Log_e_fis_tmp']);
delete_block([mdl '/Log_ce_fis_tmp']);
% Log_dKp_tmp/Log_dKi_tmp/Log_dKd_tmp sont nettoyes plus bas, apres
% l'ETAPE 4quater qui en a besoin.

fenetre_e  = (t_e >= FENETRE_DEBUT) & (t_e <= FENETRE_FIN);
fenetre_ce = (t_ce >= FENETRE_DEBUT) & (t_ce <= FENETRE_FIN);

frac_e_total    = 100 * mean(abs(e_vals)              > CORE_ZONE);
frac_e_regime   = 100 * mean(abs(e_vals(fenetre_e))   > CORE_ZONE);
frac_ce_total   = 100 * mean(abs(ce_vals)             > CORE_ZONE);
frac_ce_regime  = 100 * mean(abs(ce_vals(fenetre_ce)) > CORE_ZONE);
max_e_regime  = max(abs(e_vals(fenetre_e)));
max_ce_regime = max(abs(ce_vals(fenetre_ce)));

fprintf('=== ETAPE 4ter : e_fis / ce_fis hors zone coeur [-%g, +%g] ===\n', CORE_ZONE, CORE_ZONE);
fprintf('e_fis  hors coeur : %5.1f%% du run complet, %5.1f%% en regime etabli [%.2f,%.2f]s (max |e_fis|=%.2f)\n', ...
    frac_e_total, frac_e_regime, FENETRE_DEBUT, FENETRE_FIN, max_e_regime);
fprintf('ce_fis hors coeur : %5.1f%% du run complet, %5.1f%% en regime etabli [%.2f,%.2f]s (max |ce_fis|=%.2f)\n', ...
    frac_ce_total, frac_ce_regime, FENETRE_DEBUT, FENETRE_FIN, max_ce_regime);
if max(frac_e_regime, frac_ce_regime) > 50
    fprintf(['HYPOTHESE CONFIRMEE PAR MESURE (et non plus supposee) : e_fis et/ou ce_fis passent la ' ...
        'majorite du regime etabli hors de la zone coeur du FIS -- le controleur lit une "erreur ' ...
        'extreme" en permanence meme quand Vout a converge, ce qui explique directement la ' ...
        'saturation Kp/Kd/mu de l''ETAPE 4bis. PROCHAINE ETAPE : reduire Ke et/ou Kec (calibration ' ...
        'iterative, meme demarche que les bornes MU d''ELM-PID) jusqu''a ce que e_fis/ce_fis restent ' ...
        'dans [-%g,+%g] en regime etabli, puis recapturer KI_REF/RIPPLE_REF sur ce nouveau reglage.\n'], ...
        CORE_ZONE, CORE_ZONE);
else
    fprintf(['Hypothese NON confirmee par la mesure directe : e_fis/ce_fis restent majoritairement ' ...
        'dans la zone coeur en regime etabli -- la saturation Kp/Kd/mu de l''ETAPE 4bis a donc une ' ...
        'autre cause, a rechercher ailleurs (bornes KP_MAX/KD_MAX elles-memes, dynamique des regles ' ...
        'du FIS, ou logique d''adaptation Kp/Ki/Kd/mu en aval du FIS).\n']);
end
fprintf('\n');

% =========================================================================
% ETAPE 4quater : dKp/dKi/dKd (increments APRES Kpu/Kiu/Kdu) pres de
% l'equilibre -- deuxieme hypothese, formee APRES avoir lu le code reel de
% "loi_incrementale_fuzzy" (Construction_Simulink_Fuzzy_PID.m) suite a
% l'echec de la premiere (ETAPE 4ter) : Kp/Ki/Kd n'y sont pas recalcules
% directement depuis le FIS a chaque pas, ce sont des INTEGRATEURS bornes
% sans terme de fuite/anti-windup :
%   Kp = min(KP_MAX, max(0,        Kp1 + dKp))
%   Kd = min(KD_MAX, max(-KD_MAX,  Kd1 + dKd))
% Un increment legerement biaise (non nul en moyenne) meme pres de
% l'equilibre (e_fis/ce_fis proches de 0, confirme ETAPE 4ter) suffit,
% accumule sur 40000 pas, a pousser ces integrateurs jusqu'a une borne et
% a les y maintenir -- sans que l'entree du FIS ait besoin de sortir de sa
% zone coeur. Mesure directe des increments APRES mise a l'echelle
% (Echelle_dKp/dKi/dKd), c'est-a-dire exactement ce qui est ajoute a
% Kp1/Ki1/Kd1 a chaque pas.
[t_dkp, dkp_vals] = extraire_temps_valeurs(evalin('base', 'dKp_log'), 'dKp_log');
[t_dki, dki_vals] = extraire_temps_valeurs(evalin('base', 'dKi_log'), 'dKi_log');
[t_dkd, dkd_vals] = extraire_temps_valeurs(evalin('base', 'dKd_log'), 'dKd_log');
assert(numel(t_dkp) == numel(dkp_vals) && numel(t_dki) == numel(dki_vals) && numel(t_dkd) == numel(dkd_vals), ...
    'ECHEC : dKp_log/dKi_log/dKd_log ont un temps et des valeurs de longueurs differentes -- logging incoherent.');
delete_block([mdl '/Log_dKp_tmp']);
delete_block([mdl '/Log_dKi_tmp']);
delete_block([mdl '/Log_dKd_tmp']);

fenetre_dkp = (t_dkp >= FENETRE_DEBUT) & (t_dkp <= FENETRE_FIN);
fenetre_dki = (t_dki >= FENETRE_DEBUT) & (t_dki <= FENETRE_FIN);
fenetre_dkd = (t_dkd >= FENETRE_DEBUT) & (t_dkd <= FENETRE_FIN);

fprintf('=== ETAPE 4quater : increments dKp/dKi/dKd en regime etabli [%.2f,%.2f]s (apres Kpu/Kiu/Kdu) ===\n', FENETRE_DEBUT, FENETRE_FIN);
fprintf('dKp : moyenne=%+.4e, min=%+.4e, max=%+.4e\n', ...
    mean(dkp_vals(fenetre_dkp)), min(dkp_vals(fenetre_dkp)), max(dkp_vals(fenetre_dkp)));
fprintf('dKi : moyenne=%+.4e, min=%+.4e, max=%+.4e\n', ...
    mean(dki_vals(fenetre_dki)), min(dki_vals(fenetre_dki)), max(dki_vals(fenetre_dki)));
fprintf('dKd : moyenne=%+.4e, min=%+.4e, max=%+.4e\n', ...
    mean(dkd_vals(fenetre_dkd)), min(dkd_vals(fenetre_dkd)), max(dkd_vals(fenetre_dkd)));
fprintf(['Interpretation : si la MOYENNE de dKd (par exemple) reste clairement non nulle et de signe ' ...
    'constant pendant que Kd est deja colle a sa borne (ETAPE 4bis), c''est la preuve directe que ' ...
    'l''integrateur borne de "loi_incrementale_fuzzy" est pousse en permanence dans un seul sens ' ...
    'pres de l''equilibre -- defaut de la table de regles/defuzzification du FIS pour la zone ZE, ' ...
    'PAS un probleme de mise a l''echelle Ke/Kec (deja ecarte par l''ETAPE 4ter). Si au contraire les ' ...
    'increments oscillent bien autour de zero, la piste integrateur/regle ZE est a son tour ecartee ' ...
    'et il faudra inspecter la table de regles elle-meme (fisFuzzyPID.Rules) et non plus seulement ' ...
    'ses entrees/sorties agregees.\n\n']);

% =========================================================================
% ETAPE 4quinquies : xc1/xc2/xc3 et dmu -- mu a SON PROPRE integrateur,
% DISTINCT de Kp/Ki/Kd
% =========================================================================
% Ajoutee suite a un run reel ou la correction de la regle (e=ZE,ce=ZE)
% (voir en-tete) a bien elimine le blocage de Kd (90.9%->0.0%) et fait
% disparaitre le plancher de Kp (96.5%->0.2% de temps quasi-nul), MAIS
% mu est reste colle a son plafond quasi inchange (50.3%->50.2%). Kp/Kd
% sains ne suffit donc PAS a expliquer/garantir un mu sain : mu suit sa
% PROPRE loi d'incrementation (equation 13, Lu et al.) --
%   dmu = Kp1*xc1 + Ki1*xc2 + Kd1*xc3
%   mu  = min(MU_MAX, max(MU_MIN, mu1 + dmu))
% -- un integrateur borne distinct, sans terme de fuite lui non plus,
% pilote par xc1/xc2/xc3 (sorties de Calcul_Erreur_Fuzzy, PAS e_fis/ce_fis
% qui n'alimentent que le FIS). Un xc1 ou xc3 structurellement biaise en
% regime etabli suffit a lui seul a faire deriver mu, meme avec des gains
% Kp1/Kd1 par ailleurs bien comportes.
[t_xc1, xc1_vals] = extraire_temps_valeurs(evalin('base', 'xc1_log'), 'xc1_log');
[t_xc2, xc2_vals] = extraire_temps_valeurs(evalin('base', 'xc2_log'), 'xc2_log');
[t_xc3, xc3_vals] = extraire_temps_valeurs(evalin('base', 'xc3_log'), 'xc3_log');
assert(numel(t_xc1) == numel(xc1_vals) && numel(t_xc2) == numel(xc2_vals) && numel(t_xc3) == numel(xc3_vals), ...
    'ECHEC : xc1_log/xc2_log/xc3_log ont un temps et des valeurs de longueurs differentes -- logging incoherent.');
delete_block([mdl '/Log_xc1_tmp']);
delete_block([mdl '/Log_xc2_tmp']);
delete_block([mdl '/Log_xc3_tmp']);

fenetre_xc1 = (t_xc1 >= FENETRE_DEBUT) & (t_xc1 <= FENETRE_FIN);
fenetre_xc2 = (t_xc2 >= FENETRE_DEBUT) & (t_xc2 <= FENETRE_FIN);
fenetre_xc3 = (t_xc3 >= FENETRE_DEBUT) & (t_xc3 <= FENETRE_FIN);

fprintf('=== ETAPE 4quinquies : xc1/xc2/xc3 (entrees de mu) en regime etabli [%.2f,%.2f]s ===\n', FENETRE_DEBUT, FENETRE_FIN);
fprintf('xc1 (ecart 1) : moyenne=%+.4e, min=%+.4e, max=%+.4e\n', ...
    mean(xc1_vals(fenetre_xc1)), min(xc1_vals(fenetre_xc1)), max(xc1_vals(fenetre_xc1)));
fprintf('xc2 (=ecn)    : moyenne=%+.4e, min=%+.4e, max=%+.4e\n', ...
    mean(xc2_vals(fenetre_xc2)), min(xc2_vals(fenetre_xc2)), max(xc2_vals(fenetre_xc2)));
fprintf('xc3 (ecart 3) : moyenne=%+.4e, min=%+.4e, max=%+.4e\n', ...
    mean(xc3_vals(fenetre_xc3)), min(xc3_vals(fenetre_xc3)), max(xc3_vals(fenetre_xc3)));

% Recoupement independant, SANS nouveau tap : la ou mu n'est PAS a son
% plafond, mu(k)-mu(k-1) = dmu(k) EXACTEMENT (aucun ecretage ne deforme
% la valeur) -- reutilise mu_fuzzy deja logue plus haut. Une
% moyenne clairement non nulle et de signe constant sur ces points NON
% ecretes confirme un biais reel de dmu lui-meme, independant de Kp/Kd.
% Masque sur la DESTINATION de chaque pas (mu_vals(k+1)), pas sur son
% origine : c'est la valeur d'ARRIVEE qui indique si min/max a ecrete ce
% pas-la, pas la valeur de depart.
dmu_observe = diff(mu_vals);
mu_arrivee_hors_plafond = mu_vals(2:end) < (MU_MAX_ATTENDU - TOL_SATURATION);
dmu_hors_plafond = dmu_observe(mu_arrivee_hors_plafond);
if isempty(dmu_hors_plafond)
    fprintf('mu ne quitte JAMAIS son plafond sur tout le run -- gel total, aucun point de comparaison disponible.\n');
else
    fprintf('diff(mu) la ou mu N''EST PAS au plafond (%d points) : moyenne=%+.4e, min=%+.4e, max=%+.4e\n', ...
        numel(dmu_hors_plafond), mean(dmu_hors_plafond), min(dmu_hors_plafond), max(dmu_hors_plafond));
end
fprintf(['Interpretation : un biais net et de signe constant sur xc1/xc2/xc3 et/ou sur diff(mu) hors ' ...
    'plafond confirme que le gel de mu vient de SA PROPRE loi d''incrementation (donc de xc1/xc2/xc3, ' ...
    'PAS de Kp/Kd deja verifies sains) -- meme classe de defaut que la regle (e=ZE,ce=ZE) deja ' ...
    'corrigee, mais localise cette fois dans calcul_erreur_fuzzy plutot que dans la table du FIS. Si ' ...
    'au contraire xc1/xc2/xc3 et diff(mu) hors plafond oscillent proprement autour de zero, le gel de ' ...
    'mu (voir duree du plus long contact, ETAPE 4bis) n''est pas un windup au sens deja diagnostique ' ...
    'ici, et merite une inspection visuelle directe de la courbe mu(t) avant toute autre hypothese.\n\n']);

% =========================================================================
% ETAPE 4sexies : POIDS REEL DE CHAQUE TERME DE dmu, ET STABILITE REELLE DE Kp
% =========================================================================
% Ajoutee suite au 9e test. Le run post-9e-test a donne un resultat a deux
% visages : dKd est desormais authentiquement nul en regime etabli
% (moyenne 2.66e-22, meme ordre que dKi=5.3e-17 -- bruit flottant, pas un
% biais residuel : le defaut de table est bien corrige). MAIS Kd reste
% colle a +KD_MAX 98.5% du temps -- PLUS qu'avant la correction. Ce n'est
% plus un defaut de table de regles : Kd a ete pousse a son plafond par un
% transitoire initial legitime (visible sur le graphique, ~5ms) et rien ne
% l'en fait redescendre depuis (integrateur sans fuite, ni terme de
% moment -- ecart assume par rapport a ELM-PID, voir en-tete du script de
% construction du FIS). Chasser encore une regle ne changerait rien : il
% n'y a plus de biais a corriger. La question qui reste est architecturale,
% pas une question de table -- et elle se tranche par la mesure, pas par
% intuition : la seule influence de Kd sur le systeme passe par
% dmu = Kp1*xc1 + Ki1*xc2 + Kd1*xc3 (loi_incrementale_fuzzy). Si Kd1*xc3
% est negligeable devant les deux autres termes, la valeur exacte de Kd --
% colle a son plafond ou non -- ne change rigoureusement rien a la
% dynamique observee de mu/Vout.
fenetre_kp = (t_kp >= FENETRE_DEBUT) & (t_kp <= FENETRE_FIN);
fenetre_kd = (t_kd >= FENETRE_DEBUT) & (t_kd <= FENETRE_FIN);

kp_moyen_etabli = mean(kp_vals(fenetre_kp));
kd_moyen_etabli = mean(kd_vals(fenetre_kd));

xc1_absmax = max(abs(xc1_vals(fenetre_xc1)));
xc2_absmax = max(abs(xc2_vals(fenetre_xc2)));
xc3_absmax = max(abs(xc3_vals(fenetre_xc3)));

% Majorants (produit des moyennes/maximums, pas un produit point-a-point --
% xc1_log/xc2_log/xc3_log et Kp_fuzzy/Kd_fuzzy proviennent de blocs de
% logging distincts, un alignement temporel exact point-a-point n'est pas
% garanti ; un majorant par magnitude typique suffit largement pour
% trancher un ecart de plusieurs ordres de grandeur).
contrib_kp = abs(kp_moyen_etabli * xc1_absmax);
contrib_ki = abs(ki_mesure       * xc2_absmax);
contrib_kd = abs(kd_moyen_etabli * xc3_absmax);
contrib_totale = contrib_kp + contrib_ki + contrib_kd;

fprintf('=== ETAPE 4sexies : poids de chaque terme dans dmu = Kp*xc1 + Ki*xc2 + Kd*xc3 (regime etabli) ===\n');
fprintf('Kp1*xc1 (majorant) : %.4e  (%5.2f%% du total)\n', contrib_kp, 100*contrib_kp/contrib_totale);
fprintf('Ki1*xc2 (majorant) : %.4e  (%5.2f%% du total)\n', contrib_ki, 100*contrib_ki/contrib_totale);
fprintf('Kd1*xc3 (majorant) : %.4e  (%5.2f%% du total)\n', contrib_kd, 100*contrib_kd/contrib_totale);
if contrib_kd / contrib_totale < 0.01
    fprintf(['NOTE : la contribution de Kd a dmu est negligeable (< 1%% du total) -- que Kd soit colle ' ...
        'a +KD_MAX ou a toute autre valeur ne change quasiment rien a la dynamique de mu/Vout dans ce ' ...
        'regime. Le blocage de Kd reste un fait reel a documenter (consequence de l''architecture sans ' ...
        'fuite/sans moment, pas un bug de table), mais ne remet PAS en cause la validite des resultats ' ...
        'deja obtenus (Vout, ripple, Ki).\n']);
else
    fprintf(['ATTENTION : la contribution de Kd a dmu n''est PAS negligeable -- son blocage a +KD_MAX ' ...
        'affecte reellement la dynamique de mu/Vout. A investiguer avant de conclure quoi que ce soit ' ...
        'sur le cas nominal.\n']);
end
fprintf('\n');

% Kp est-il reellement stabilise, ou derive-t-il encore lentement vers son
% PROPRE plafond ? Sur le run a 0.2s (avant le present allongement a
% T_SIM_STOP), le graphique montrait Kp encore clairement en hausse sur
% toute la fenetre [0.18,0.2]s (pas de plateau visible) -- une pente
% residuelle meme faible, si elle se maintenait, finirait par saturer Kp
% exactement comme Kd, juste plus lentement. Un ajustement lineaire donne
% cette pente et l'extrapolation naive du temps avant KP_MAX -- CE N'EST
% PAS UNE PREDICTION (la pente peut tres bien ralentir/s'annuler au-dela
% de la fenetre mesuree, rien ne le garantit non plus), c'est un signal
% d'alarme quantifie qui remplace la simple lecture visuelle du graphique.
% C'est exactement pour trancher cette question que T_SIM_STOP est passe
% de 0.2s a 1s (voir en-tete du fichier, 9e test) : si Kp est encore
% clairement en hausse sur LA NOUVELLE fenetre [FENETRE_DEBUT,FENETRE_FIN]
% (les 20 derniers ms de 1s), la piste windup-lent reste ouverte malgre
% l'allongement ; si la pente s'est effondree vers zero, Kp converge
% reellement et le sujet est clos.
coeffs_kp = polyfit(t_kp(fenetre_kp) - t_kp(find(fenetre_kp,1)), kp_vals(fenetre_kp), 1);
pente_kp_par_s = coeffs_kp(1);
fprintf('Kp en regime etabli [%.2f,%.2f]s : pente residuelle = %+.3f /s (valeur moyenne %.3f).\n', ...
    FENETRE_DEBUT, FENETRE_FIN, pente_kp_par_s, kp_moyen_etabli);
if pente_kp_par_s > 0 && kp_moyen_etabli < KP_MAX_ATTENDU - TOL_SATURATION
    temps_extrapole_s = t_kp(find(fenetre_kp,1)) + (KP_MAX_ATTENDU - kp_moyen_etabli) / pente_kp_par_s;
    fprintf(['ATTENTION : Kp continue de monter en "regime etabli", ce n''en est peut-etre pas un. Si ' ...
        'cette pente se maintenait telle quelle (extrapolation naive, non garantie), Kp atteindrait ' ...
        'KP_MAX (%g) vers t=%.2fs -- soit au-dela des %.0fs deja simules ici (T_SIM_STOP). Diagnostic ' ...
        'KP_MAX deja execute (voir Construction_Simulink_Fuzzy_PID.m) : il s''agit d''un windup de table ' ...
        'connu, pas d''une convergence attendue -- ne conclure a une derive NOUVELLE que si cette pente ' ...
        'est nettement plus forte que celle deja documentee (~+4 a +9e-4 en increment brut).\n'], ...
        KP_MAX_ATTENDU, temps_extrapole_s, T_SIM_STOP);
elseif kp_moyen_etabli >= KP_MAX_ATTENDU - TOL_SATURATION
    fprintf(['NOTE : Kp est colle a son plafond (%g) sur cette fenetre (pente residuelle mesuree %+.3f/s, ' ...
        'proche de zero) -- CE N''EST PAS UNE CONVERGENCE. Diagnostic KP_MAX deja execute et conclu (voir ' ...
        'Construction_Simulink_Fuzzy_PID.m, commentaire "DIAGNOSTIC KP_MAX EXECUTE ET CONCLU") : ' ...
        'l''increment brut dKp (avant ecretage) reste quasi constant (~+4,4 a +5,1e-4) quelle que soit la ' ...
        'valeur de Kp ou son plafond -- signature d''un windup non borne, PAS d''un equilibre naturel. La ' ...
        'platitude apparente ici est un artefact de l''ecretage pres du plafond, pas une preuve de sante. ' ...
        'Kp partage donc le meme diagnostic architectural que Kd (ETAPE 4sexies) : sans consequence ' ...
        'pratique tant que Kp1*xc1 reste negligeable dans dmu, mais NON RESOLU au niveau de la table de ' ...
        'regles.\n'], KP_MAX_ATTENDU, pente_kp_par_s);
else
    fprintf(['Kp : pente residuelle nulle ou negative sur cette fenetre ET Kp n''est PAS colle a son ' ...
        'plafond -- signe d''un veritable palier sous KP_MAX, distinct du windup deja diagnostique. ' ...
        'Combine au poids negligeable de Kp1*xc1 dans dmu (ETAPE 4sexies ci-dessus), Kp peut ' ...
        'raisonnablement etre considere converge sur cette fenetre precise.\n']);
end
fprintf('\n');

% =========================================================================
% ETAPE 5 : COMPARAISON A LA DERNIERE VALIDATION CONFIRMEE
% =========================================================================
fprintf('=== ETAPE 4 : comparaison a la reference validee ===\n');
fprintf('%-25s %15s %15s %12s\n', 'Metrique', 'Reference', 'Mesure', 'Ecart (%)');

ecart_ki = 100 * abs(ki_mesure - KI_REF) / abs(KI_REF);
ecart_ripple = 100 * abs(ripple_mesure - RIPPLE_REF) / abs(RIPPLE_REF);

fprintf('%-25s %15.4f %15.4f %11.2f%%\n', 'Ki (regime etabli)', KI_REF, ki_mesure, ecart_ki);
fprintf('%-25s %15.4f %15.4f %11.2f%%  (informatif -- voir note)\n', 'Ripple Vout (V pp)', RIPPLE_REF, ripple_mesure, ecart_ripple);
fprintf('\n');

% Seul Ki est juge contre une tolerance stricte : sa convergence en
% regime etabli ne depend que de l'annulation de l'erreur en regime
% permanent, peu importe le chemin d'adaptation emprunte pour y arriver
% -- une metrique raisonnablement robuste a une difference de mise a
% l'echelle en amont. Le ripple NE l'est PAS (voir en-tete du fichier :
% RIPPLE_REF vient d'un modele ou Ke/Kec/Kdu valaient 1, pas leurs
% valeurs actuelles) -- il est affiche mais ne fait plus echouer ce test.
verdict_ok = (ecart_ki <= TOLERANCE_PCT);
if verdict_ok
    fprintf(['VERDICT NUMERIQUE : Ki conforme (ecart <= %.1f%%). Le nettoyage du cablage n''a ' ...
        'pas modifie le comportement du controleur.\n'], TOLERANCE_PCT);
else
    fprintf(2, ['*** VERDICT NUMERIQUE : ECART REEL SUR Ki (> %.1f%%) -- NE PAS CONCLURE A UNE ' ...
        'REUSSITE. Contrairement au ripple (voir note en-tete), un ecart sur Ki N''EST PAS ' ...
        'explique par la mise a l''echelle -- ceci reste un signal d''alerte reel a investiguer ' ...
        '(reconnexion sur le mauvais port ?) avant de continuer vers F1/F2.\n'], TOLERANCE_PCT);
end
fprintf(['\nLe ripple n''est plus compare a RIPPLE_REF en tant que critere de reussite : ce ' ...
    'chiffre de reference provient d''un modele sans mise a l''echelle floue reelle (voir en-tete). ' ...
    'Une nouvelle reference devra etre capturee une fois Ke/Kec/Kdu calibres.\n']);
fprintf(['\nRAPPEL (discipline de validation du projet) : ce verdict chiffre ne remplace PAS ' ...
    'l''inspection visuelle des courbes ci-dessous -- une moyenne/un ripple corrects peuvent\n' ...
    'masquer une dynamique incoherente (plateau puis saut brutal, etc.). Regardez les figures\n' ...
    'avant de considerer ce test concluant.\n\n']);

% =========================================================================
% ETAPE 6 : INSPECTION VISUELLE (obligatoire par la discipline du projet --
% jamais un chiffre agrege seul)
% =========================================================================
figure('Name', 'Validation nominale -- Vout', 'NumberTitle', 'off');
subplot(2,1,1);
plot(t_y, vals_y, 'LineWidth', 1);
grid on; xlabel('t (s)'); ylabel('Vout (V)');
title(sprintf('Vout(t) -- vue complete [0, %.0fs]', T_SIM_STOP));
yline(100, '--', 'Vref=100V');

subplot(2,1,2);
plot(t_y(fenetre_y), vals_y(fenetre_y), 'LineWidth', 1);
grid on; xlabel('t (s)'); ylabel('Vout (V)');
title(sprintf('Vout(t) -- zoom regime etabli [%.2f, %.2fs] (ripple mesure : %.3f V pp)', FENETRE_DEBUT, FENETRE_FIN, ripple_mesure));
saveas(gcf, 'validation_nominale_vout.png');

figure('Name', 'Validation nominale -- gains et commande', 'NumberTitle', 'off');
subplot(4,1,1); plot(t_kp, kp_vals, 'LineWidth', 1); grid on; ylabel('Kp'); title('Gains adaptatifs et commande (vue complete)');
subplot(4,1,2); plot(t_ki, ki_vals, 'LineWidth', 1); grid on; ylabel('Ki');
subplot(4,1,3); plot(t_kd, kd_vals, 'LineWidth', 1); grid on; ylabel('Kd');
subplot(4,1,4); plot(t_mu, mu_vals, 'LineWidth', 1); grid on; ylabel('\mu'); xlabel('t (s)');
saveas(gcf, 'validation_nominale_gains.png');

fprintf('Figures sauvegardees : validation_nominale_vout.png, validation_nominale_gains.png\n');
fprintf(['Inspectez-les : Vout doit converger sans plateau-puis-saut, Ki doit se stabiliser ' ...
    'proprement (pas de battement permanent entre 2 bornes).\n']);

% =========================================================================
% FONCTION LOCALE
% =========================================================================
function [t, vals] = extraire_temps_valeurs(donnee, nomAffiche)
% Extrait (temps, valeurs) d'une variable de sortie "To Workspace" quel
% que soit son SaveFormat reel (Timeseries, Structure/StructureWithTime,
% ou Array brut + temps separe dans "tout") -- verifie le type EFFECTIF
% de l'objet recu plutot que de supposer lequel a ete produit.
    if isa(donnee, 'timeseries')
        t = donnee.Time;
        vals = squeeze(donnee.Data);
    elseif isstruct(donnee) && isfield(donnee, 'time') && isfield(donnee, 'signals')
        t = donnee.time;
        vals = squeeze(donnee.signals.values);
    elseif isnumeric(donnee)
        % Format "Array" : la variable elle-meme ne contient que les
        % valeurs, le temps est cense se trouver dans "tout" (variable de
        % temps globale exportee par sim() quand ReturnWorkspaceOutputs
        % est "off" mais qu'un bloc utilise le format Array).
        vals = donnee;
        if evalin('base', 'exist(''tout'', ''var'')')
            t = evalin('base', 'tout');
        else
            error(['"%s" est un tableau numerique brut (SaveFormat=Array) mais aucune variable ' ...
                   '"tout" n''a ete trouvee pour lui associer un axe de temps. Ouvrez le bloc ' ...
                   '"To Workspace" concerne dans %s.slx et mettez son SaveFormat sur "Timeseries" ' ...
                   'pour eviter cette ambiguite, puis relancez ce test.'], nomAffiche, 'Fuzzy_PID_Control');
        end
    else
        error('Format de "%s" non reconnu (classe : %s) -- extraction impossible sans inspection manuelle.', ...
            nomAffiche, class(donnee));
    end
    vals = vals(:);
    t = t(:);
end

function n = compter_lignes_decoratives_fichier(fichierSlx)
% Lit simulink/systems/system_root.xml directement depuis l'archive .slx
% et compte les <Line>...</Line> ne contenant, nulle part dans leur
% texte, ni Name="Src" ni Name="Dst". Lecture seule -- rien n'est
% modifie ici.
%
% CORRECTION (meme bug reel que dans Construction_Simulink_Fuzzy_PID.m,
% identifie a partir d'un log d'execution reel montrant une verification
% de topologie faussement "OK" avec 0 noeud trouve) -- ERREUR A NE PAS
% REPRODUIRE : la version precedente lisait l'archive via
% java.util.zip.ZipFile + une boucle manuelle InputStream.read(byte[],
% int, int). MATLAB passe les tableaux aux methodes Java PAR COPIE : ce
% "read" est cense ECRIRE dans le tableau qu'on lui passe, mais
% n'ecrivait que dans une copie temporaire cote Java, jamais dans la
% variable MATLAB "tampon" -- le buffer accumule avait la bonne longueur
% mais restait rempli de ZEROS. Ici, cela produisait silencieusement
% n=0 (0 ligne decorative trouvee) MEME quand des lignes decoratives
% existaient reellement : un faux NEGATIF qui rendait ce controle
% totalement vide de sens sans jamais lever d'erreur. Fix : lecture via
% unzip() (extraction native MATLAB) + fileread() (vecteur ligne de
% caracteres garanti) -- aucun tableau ne sert de parametre de sortie a
% une methode Java, donc ce bug est ici structurellement impossible.
    if ~isfile(fichierSlx)
        error('compter_lignes_decoratives_fichier:fichierIntrouvable', ...
            'Fichier introuvable : %s', fichierSlx);
    end
    dossierTmp = tempname();
    mkdir(dossierTmp);
    nettoyeur = onCleanup(@() rmdir(dossierTmp, 's')); %#ok<NASGU>
    try
        unzip(fichierSlx, dossierTmp);
    catch ME
        error('compter_lignes_decoratives_fichier:unzipEchec', ...
            'Echec de l''extraction de "%s" : %s', fichierSlx, ME.message);
    end
    cheminXml = fullfile(dossierTmp, 'simulink', 'systems', 'system_root.xml');
    if ~isfile(cheminXml)
        error('compter_lignes_decoratives_fichier:xmlIntrouvable', ...
            '"simulink/systems/system_root.xml" introuvable dans %s -- fichier .slx inattendu.', ...
            fichierSlx);
    end
    texte = fileread(cheminXml);

    % Garde-fou anti-faux-negatif (directement motive par le bug
    % ci-dessus) : system_root.xml n'est jamais vide dans un modele
    % reel -- s'il l'est, la lecture a echoue silencieusement quelque
    % part, et il faut le signaler plutot que de renvoyer n=0 a tort.
    if isempty(texte)
        error('compter_lignes_decoratives_fichier:lectureEchouee', ...
            '"%s" a ete lu comme un texte vide -- lecture probablement en echec.', fichierSlx);
    end

    [debuts, fins] = regexp(texte, '<Line>.*?</Line>', 'start', 'end', 'dotall');
    n = 0;
    for i = 1:numel(debuts)
        contenu = texte(debuts(i):fins(i));
        if ~contains(contenu, 'Name="Src"') && ~contains(contenu, 'Name="Dst"')
            n = n + 1;
        end
    end
end
