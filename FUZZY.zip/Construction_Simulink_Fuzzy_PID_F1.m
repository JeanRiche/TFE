%% Construction_Simulink_Fuzzy_PID_F1.m
% =========================================================================
%                                                                         %
%   SCENARIO F1 (PERTURBATION DE COMMANDE) POUR FUZZY-PID                %
%   -- construit a partir du modele nominal DEJA VALIDE                 %
%      Fuzzy_PID_Control.slx, jamais modifie en place                   %
%                                                                         %
% =========================================================================
%
% RAPPEL DE LA DEFINITION (Lu et al. 2021, section 5.2, "disturbance F1(t)
% of the control terminal") -- CORRIGEE une seconde fois par rapport a la
% premiere version de ce script :
%
%   F1(t) = 0                        , 0    < t < 0.05
%         = 2 * exp(cos(10*pi*t))    , 0.05 < t < 0.07
%         = 0                        , 0.07 < t < 0.2
%
% HISTORIQUE DE LA CORRECTION (a ne pas refaire) : le texte OCR brut du
% PDF affiche "2e" puis, sur une ligne separee, "cos(10*pi*t)", sans
% operateur visible entre les deux -- exactement le meme artefact
% d'extraction que pour F2(t), ou "-", "2R", "15" apparaissent aussi sur
% trois lignes separees et forment SANS AMBIGUITE la fraction -2R/15 (la
% barre de fraction perdue a l'OCR). La toute premiere version de ce
% script avait interprete l'empilement de F1 comme "2e (constante) fois
% cos(10*pi*t)" (multiplication, operateur perdu) ; c'etait une erreur.
% Une lecture en FRACTION (2e / cos(10*pi*t), par analogie avec F2) est
% mathematiquement impossible : cos(10*pi*0.05) = cos(pi/2) = 0 pile a
% l'instant de declenchement, ce qui donnerait une division par zero des
% le premier instant actif -- un papier ne definit pas une perturbation
% qui diverge a l'infini a son propre declenchement. Il ne reste que la
% lecture en EXPOSANT : "2e" = base 2*e, "cos(10*pi*t)" = exposant, donc
% F1(t) = 2 * e^(cos(10*pi*t)) = 2*exp(cos(10*pi*t)).
% Confirmation textuelle independante (pas seulement typographique) :
% Fig. 16 du papier dit explicitement que c'est "the output CONTROL
% SIGNAL" qui fluctue sous F1, et Fig. 18 dit que la perturbation agit
% "at the control end" -- deux formulations qui corroborent a la fois le
% point d'injection (voir plus bas) ET, indirectement, la coherence de
% cette lecture : Fig. 12 rapporte que Vout AUGMENTE d'abord (101.9V) des
% le declenchement, ce qui est exactement ce que produit F1(t) toujours
% POSITIF (voir plus bas) ajoute directement sur mu -- alors que l'ancienne
% lecture (multiplication, F1 toujours negatif sur la fenetre active)
% aurait produit une baisse initiale de mu, donc de Vout, contredisant le
% papier.
%
% CORRECTION D'UNE NOTE DE LA MEMOIRE DE PROJET : l'affirmation stockee
% "F1(t) et vraisemblablement F2(t) valent exactement zero a l'instant de
% declenchement (cos(pi/2)=0 par construction)" ne tient PAS sous cette
% lecture corrigee, et ne s'appliquait de toute facon jamais a F2 (une
% simple constante, sans cosinus). A ne plus reutiliser telle quelle.
%
% VALEURS NUMERIQUES SUR LA FENETRE ACTIVE [0.05,0.07] (a retenir pour la
% calibration des bornes MU, voir plus bas) : F1 SAUTE de 0 a
% 2*exp(cos(pi/2))=2*exp(0)=2 pile a t=0.05 (discontinuite reelle, pas une
% montee progressive), puis DECROIT doucement et continument jusqu'a
% 2*exp(cos(0.7*pi))=2*exp(-0.588)=1.11 a t=0.07, avant de retomber a 0
% instantanement. F1(t) est TOUJOURS POSITIF sur cette fenetre (entre 1.11
% et 2), jamais negatif, jamais proche de l'amplitude "brute" 2e=5.436
% (qui ne serait atteinte qu'a cos=1, hors de la fenetre active).
%
% POINT D'INJECTION -- CONFIRME PAR LE TEXTE DU PAPIER, PAS SEULEMENT PAR
% LE TITRE DE LA SECTION : Fig. 16 dit explicitement que c'est "the
% output CONTROL SIGNAL" (donc mu, pas Vref) qui fluctue sous F1, et
% Fig. 18 dit que la perturbation agit "at the control end". F1 est donc
% injectee sur le signal de commande mu, au point ou il sort de la loi
% incrementale, AVANT la saturation physique -- exactement le montage
% retenu pour ELM-PID d'apres la memoire de ce projet (Sum apres la
% sortie du controleur, saturation externe [0.01,0.99] appliquee une
% seule fois APRES cette somme). Le bloc "Constant1" (Vref), toujours
% inutilise depuis la suppression du PID classique, n'a AUCUN role ici :
% perturber Vref serait une perturbation de CONSIGNE, une categorie que
% ce papier ne traite pas (seuls "terminal de commande" et "charge" sont
% definis). Un Sum sur mu reste donc necessaire.
%
% SIGNE DE LA SOMME -- CONFIRME PAR LA FORME CORRIGEE DE F1(t) :
% mu_perturbe = mu + F1(t) (addition directe). F1(t) etant TOUJOURS
% POSITIF sur la fenetre active (2 a t=0.05, decroissant vers 1.11 a
% t=0.07 -- voir plus haut), cette addition fait immediatement MONTER mu
% au declenchement, donc monter Vout via la dynamique du filtre LC --
% cela correspond exactement a ce que rapporte le papier (Fig. 12 :
% "the output voltage... initially increases to 101.9V" des le
% declenchement de la perturbation). Coherence obtenue sans avoir besoin
% d'inverser le signe, contrairement a ce qu'aurait exige l'ancienne
% lecture erronee de F1(t) (toujours negative sur cette fenetre).
%
% BORNES MU INTERNES POUR CE SCENARIO :
% Le nominal utilise MU_MIN=0.01, MU_MAX=0.99 (identiques a la saturation
% physique -- suffisant SANS perturbation externe). Des qu'on ajoute F1(t)
% (jusqu'a +2, voir plus haut) directement sur mu AVANT la saturation
% physique, la meme pathologie que celle documentee pour ELM-PID (regle
% de construction n=12 de la memoire de projet) apparait : mu sort
% instantanement de [0.01,0.99], la saturation externe l'y ramene
% brutalement, et le correcteur devient invisible/sans marge de reaction
% pendant toute la fenetre de perturbation. Solution retenue, IDENTIQUE
% au principe applique pour ELM-PID (regle n=13) : elargir les bornes
% INTERNES de la loi incrementale, garder UNE SEULE saturation physique
% [0.01,0.99] appliquee une fois, en aval de la somme.
% Point de depart choisi : MU_MIN_F1=-0.8 (repris tel quel du compromis
% final RETENU pour ELM-PID-F1, cote negatif inchange car F1 ne pousse
% jamais mu vers le bas), MU_MAX_F1=3.5 (RELEVE par rapport a la premiere
% version de ce script, qui reprenait 1.8 d'ELM-PID sous l'ancienne
% lecture erronee de F1(t) -- avec mu au repos autour de 0.5 et F1
% culminant a 2 pile au declenchement, l'excursion attendue avoisine 2.5,
% donc 1.8 aurait ecrete tout le transitoire des le premier instant. 3.5
% laisse une marge raisonnable au-dessus de ce pic attendu, MAIS reste un
% point de depart a recalibrer sur la vraie courbe, pas une valeur
% definitive -- exactement comme toutes les autres bornes de ce projet.
%
% CE QUE CE SCRIPT NE TOUCHE PAS :
% Ke, Kec, Kpu, Kiu, Kdu (facteurs d'echelle de la FIS) et KP_MAX/KI_MAX/
% KD_MAX restent ceux valides en nominal. Ce sont des proprietes du
% controleur (la table de regles et son calibrage), pas du scenario.
%
% CORRECTION D'UNE AFFIRMATION DE CE FICHIER (10e test de la saga de la
% table de regles, voir construction_FIS_Fuzzy_PID.m) : cette section
% affirmait jusqu'ici que "rien n'indique que la table floue elle-meme
% doive changer juste parce qu'on ajoute une perturbation externe". FAUX
% -- le premier run reel de ce scenario l'a directement contredit. F1(t)
% pousse Vout AU-DESSUS de Vref, la toute premiere situation ou l'erreur
% e visite reellement sa zone NB (jamais atteinte en nominal, ou Vout ne
% depasse jamais sa cible tout seul) : la ligne e=NB de la table Ki,
% ecrite comme un "anti-windup" jamais teste, a affame Ki des le
% basculement de signe de l'erreur et bloque Vout a ~145V au lieu des
% 100V attendus, sans aucun mecanisme pour en repartir. Corrige dans
% construction_FIS_Fuzzy_PID.m (dKi=PB sur toute la ligne e=NB, comme
% deja fait pour e=PB). Contrairement a ELM-PID (qui recalibre KP_SEED et
% les bornes MU par scenario), la table de regles Fuzzy-PID n'a PAS
% besoin d'un jeu different par scenario -- mais elle doit etre CORRECTE
% sur tout le domaine (e,ce) reellement visite, y compris les zones
% qu'un scenario donne est seul a atteindre. Seule la loi incrementale
% (bornes MU) reste, elle, veritablement adaptee au scenario.
%
% PREREQUIS :
%   - Fuzzy_PID_Control.slx (nominal DEJA VALIDE) dans le meme dossier.
%   - fuzzy_pid_buck.mat dans le meme dossier (reutilise tel quel).
% =========================================================================

clear; clc;

Vin  = 200;
Vref = 100;
T    = 5e-6;

fprintf('=== Parametres physiques (identiques au nominal Fuzzy-PID) ===\n');
fprintf('Vin=%.3g V  Vref=%.3g V  T=%.3g s\n', Vin, Vref, T);

% -------------------------------------------------------------------
% FIS ET FACTEURS D'ECHELLE : repris tels quels du nominal valide, aucun
% recalibrage (voir justification en tete de fichier).
% -------------------------------------------------------------------
if ~exist('fuzzy_pid_buck.mat', 'file')
    error(['Fichier fuzzy_pid_buck.mat introuvable. Il doit deja exister ' ...
           '(produit lors de la construction du nominal Fuzzy-PID).']);
end
d_fis = load('fuzzy_pid_buck.mat');
fisFuzzyPID = d_fis.fis;
Ke  = d_fis.Ke;
Kec = d_fis.Kec;
Kpu = d_fis.Kpu;
Kiu = d_fis.Kiu;
Kdu = d_fis.Kdu;
assignin('base', 'fisFuzzyPID', fisFuzzyPID);

fprintf('\nFIS repris du nominal (inchange) : %d regles, Ke=%.3g Kec=%.3g Kpu=%.3g Kiu=%.3g Kdu=%.3g\n', ...
    numel(fisFuzzyPID.Rules), Ke, Kec, Kpu, Kiu, Kdu);

% -------------------------------------------------------------------
% BORNES : KP_MAX/KI_MAX/KD_MAX inchanges (proprietes du controleur) ;
% MU_MIN/MU_MAX elargis pour ce scenario (propriete du scenario).
% -------------------------------------------------------------------
KP_MAX = 50; KI_MAX = 50000; KD_MAX = 0.01;   % inchanges vs nominal valide
MU_MIN_F1 = -0.8; MU_MAX_F1 = 3.5;            % elargis pour F1, point de depart motive (voir en-tete)

fprintf('Bornes controleur (inchangees) : KP_MAX=%.4g KI_MAX=%.4g KD_MAX=%.4g\n', KP_MAX, KI_MAX, KD_MAX);
fprintf('Bornes MU internes pour F1 (point de depart, a recalibrer) : [%.2g, %.2g]\n', MU_MIN_F1, MU_MAX_F1);

% =====================================================================
% GENERATION DU CODE DES BLOCS MATLAB FUNCTION / STATEFLOW
% =====================================================================

% ---- Bloc de calcul d'erreur, IDENTIQUE au nominal deja corrige ----
% Reproduit ici (plutot que suppose herite par copie) pour que ce script
% reste auto-suffisant : si Fuzzy_PID_Control_F1.slx a deja ete construit
% une fois AVANT la correction Vref/Constant1/Sum1 du script nominal, une
% simple copie ne suffirait pas a la lui apporter (la copie ne se refait
% que si le fichier .slx destination n'existe pas encore -- voir plus
% bas). Cette re-injection corrige donc F1 independamment de l'ordre dans
% lequel les scripts ont ete lances.
code_erreur_F1 = sprintf([ ...
'function [ecn, xc1, xc3] = calcul_erreur_fuzzy(y, Vref)\n' ...
'%%#codegen\n' ...
'%% Erreur normalisee et ses combinaisons (eq. 13, meme convention que le\n' ...
'%% controleur ELM-PID : ecn=(Vref-y)/Vin). Vref est fourni en entree\n' ...
'%% (cable depuis "Constant1"), Vin reste un parametre physique fixe.\n' ...
'\n' ...
'persistent ecn1 ecn2 initialise\n' ...
'\n' ...
'Vin = %.10g;\n' ...
'\n' ...
'if isempty(initialise)\n' ...
'    ecn1 = Vref/Vin;\n' ...
'    ecn2 = Vref/Vin;\n' ...
'    initialise = true;\n' ...
'end\n' ...
'\n' ...
'ecn = (Vref - y) / Vin;\n' ...
'xc1 = ecn - ecn1;\n' ...
'xc3 = ecn - 2*ecn1 + ecn2;\n' ...
'\n' ...
'ecn2 = ecn1;\n' ...
'ecn1 = ecn;\n' ...
'end\n' ...
], Vin);

% ---- Bloc de la loi incrementale, IDENTIQUE au nominal sauf MU_MIN/MU_MAX ----
% Code copie tel quel du script de construction nominal
% (Construction_Simulink_Fuzzy_PID.m), seules les bornes MU changent.
code_loi_F1 = sprintf([ ...
'function [mu, Kp, Ki, Kd] = loi_incrementale_fuzzy(xc2, xc1, xc3, dKp, dKi, dKd)\n' ...
'%%#codegen\n' ...
'%% Loi de commande PID incrementale (eq. 13-14, Lu et al.), gains fournis\n' ...
'%% par la FIS. IDENTIQUE au nominal, sauf MU_MIN/MU_MAX elargis pour\n' ...
'%% laisser mu evoluer sous l''effet de la perturbation F1(t) AVANT la\n' ...
'%% saturation physique unique appliquee en aval (voir schema du scenario\n' ...
'%% F1 : Sum_Commande_F1 -> Saturation_Commande_F1 -> PWM Generator).\n' ...
'\n' ...
'persistent Kp1 Ki1 Kd1 mu1 initialise\n' ...
'\n' ...
'KP_MAX = %.10g; KI_MAX = %.10g; KD_MAX = %.10g;\n' ...
'MU_MIN = %.10g; MU_MAX = %.10g;\n' ...
'\n' ...
'if isempty(initialise)\n' ...
'    Kp1 = 0; Ki1 = 0; Kd1 = 0;\n' ...
'    mu1 = 0.5;\n' ...
'    initialise = true;\n' ...
'end\n' ...
'\n' ...
'dmu = Kp1*xc1 + Ki1*xc2 + Kd1*xc3;\n' ...
'mu  = min(MU_MAX, max(MU_MIN, mu1 + dmu));\n' ...
'\n' ...
'Kp = min(KP_MAX, max(0, Kp1 + dKp));\n' ...
'Ki = min(KI_MAX, max(0, Ki1 + dKi));\n' ...
'Kd = min(KD_MAX, max(-KD_MAX, Kd1 + dKd));\n' ...
'\n' ...
'Kp1 = Kp; Ki1 = Ki; Kd1 = Kd; mu1 = mu;\n' ...
'end\n' ...
], KP_MAX, KI_MAX, KD_MAX, MU_MIN_F1, MU_MAX_F1);

fid = fopen('code_loi_incrementale_fuzzy_F1.txt', 'w');
fprintf(fid, '%s', code_loi_F1);
fclose(fid);

% ---- Bloc de la perturbation F1(t) : fonction pure du temps, sans etat ----
code_F1 = sprintf([ ...
'function F1 = perturbation_F1(t)\n' ...
'%%#codegen\n' ...
'%% Perturbation de commande F1(t), Lu et al. (2021) section 5.2 :\n' ...
'%%   F1(t) = 0                     , 0    <= t < 0.05\n' ...
'%%         = 2*exp(cos(10*pi*t))   , 0.05 <= t < 0.07\n' ...
'%%         = 0                     , 0.07 <= t <= 0.2\n' ...
'%% Lecture "exposant" confirmee (pas une multiplication par 2*e=5.436) --\n' ...
'%% voir la justification complete en tete de ce script. Toujours positif\n' ...
'%% sur la fenetre active : saute de 0 a 2 pile a t=0.05, decroit ensuite\n' ...
'%% vers 1.11 a t=0.07. Fonction pure du temps de simulation (pas d''etat\n' ...
'%% persistant necessaire, contrairement aux blocs de la boucle de commande).\n' ...
'if t >= 0.05 && t < 0.07\n' ...
'    F1 = 2*exp(cos(10*pi*t));\n' ...
'else\n' ...
'    F1 = 0;\n' ...
'end\n' ...
'end\n' ...
]);

fid = fopen('code_perturbation_F1.txt', 'w');
fprintf(fid, '%s', code_F1);
fclose(fid);

fprintf('\nCode genere : code_loi_incrementale_fuzzy_F1.txt, code_perturbation_F1.txt\n');

% =====================================================================
% CONSTRUCTION DU MODELE SIMULINK (copie du nominal, jamais modifie)
% =====================================================================
modele_nominal = 'Fuzzy_PID_Control';
mdl = 'Fuzzy_PID_Control_F1';

if ~exist([modele_nominal '.slx'], 'file')
    error(['Fichier %s.slx introuvable (nominal Fuzzy-PID deja valide). ' ...
           'Placez-le dans le meme dossier que ce script.'], modele_nominal);
end
if bdIsLoaded(modele_nominal); close_system(modele_nominal, 0); end
if bdIsLoaded(mdl); close_system(mdl, 0); end

if ~exist([mdl '.slx'], 'file')
    copyfile([modele_nominal '.slx'], [mdl '.slx']);
    fprintf('\n%s.slx cree (copie du nominal %s.slx, original non modifie).\n', mdl, modele_nominal);
else
    fprintf('\n%s.slx existe deja -- reutilise (pas de re-copie).\n', mdl);
end
load_system(mdl);

set_param(mdl, 'ReturnWorkspaceOutputs', 'off');   % regle de construction n=8 (memoire de projet), reaffirme par securite
set_param(mdl, 'StopTime', '0.2');                  % fenetre complete du scenario F1 (0 a 0.2s), inchangee vs nominal

nom_pwm = sprintf('PWM Generator\n(DC-DC)');

% -------------------------------------------------------------------
% ETAPE A0 : meme nettoyage Sum1/Constant1 que le script nominal corrige
% (Sum1 supprime, Constant1 conserve et reconnecte comme vraie entree
% Vref de Calcul_Erreur_Fuzzy) -- reapplique ici independamment, pas
% suppose herite par la copie du nominal (voir justification de
% code_erreur_F1 plus haut). Idempotent : si le nominal source a deja ete
% corrige avant la copie, "Sum1 deja absent" et le recablage ne fait rien
% de plus qu'une verification.
% -------------------------------------------------------------------
if ~isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Sum1'))
    delete_block([mdl '/Sum1']);
    fprintf('Bloc "Sum1" supprime dans %s (plus aucune fonction -- voir script nominal pour la justification).\n', mdl);
else
    fprintf('Bloc "Sum1" deja absent dans %s.\n', mdl);
end

if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Constant1'))
    error('Bloc "Constant1" introuvable dans %s -- copie du nominal corrompue ou incomplete.', mdl);
end
valConstant1_F1 = str2double(get_param([mdl '/Constant1'], 'Value'));
if abs(valConstant1_F1 - Vref) > 1e-9
    error(['"Constant1" vaut %.10g dans %s, different du Vref=%.10g utilise par ce script. ' ...
           'Ne pas cabler aveuglement.'], valConstant1_F1, mdl, Vref);
end

% PURGE DES BRANCHES FANTOMES LAISSEES PAR LA SUPPRESSION DE SUM1 --
% IDENTIQUE au script nominal corrige (Construction_Simulink_Fuzzy_PID.m,
% voir ce fichier pour le diagnostic complet pose par inspection directe
% du XML du .slx). Reapplique ici independamment (meme logique que pour
% Sum1/Constant1 plus haut : ce script reste auto-suffisant, ne suppose
% jamais que la copie du nominal a deja ete corrigee) et de facon
% inconditionnelle a chaque execution -- donc capable de reparer
% Fuzzy_PID_Control_F1.slx meme s'il a ete construit AVANT ce correctif.
purge_branches_orphelines(mdl, 'Constant1', 1);
if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Vout'))
    error('Bloc "Vout" introuvable dans %s -- copie du nominal corrompue ou incomplete.', mdl);
end
purge_branches_orphelines(mdl, 'Vout', 1);

% LIGNES TOTALEMENT DECORATIVES (sans Src ni Dst) : pas traitees ici.
% Identique au script nominal (Construction_Simulink_Fuzzy_PID.m) apres
% son propre nettoyage -- voir ce fichier pour l'historique complet (deux
% approches abandonnees : suppression automatique via l'API live, qui a
% reellement supprime une connexion physique Simscape par erreur ; puis
% un simple diagnostic listant ces lignes pour suppression manuelle dans
% l'editeur). Les deux sont inutiles ici aussi : l'ETAPE FINALE de ce
% script (finaliser_fichier_slx, plus bas) purge deja ces lignes
% automatiquement, en lisant le XML brut du .slx sauvegarde plutot que
% l'API live -- aucune ambiguite possible avec une connexion physique, et
% aucune intervention manuelle requise.

if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Calcul_Erreur_Fuzzy'))
    error('Bloc "Calcul_Erreur_Fuzzy" introuvable dans %s -- copie du nominal corrompue ou incomplete.', mdl);
end
S = sfroot;
chartErr = S.find('-isa', 'Stateflow.EMChart', 'Path', [mdl '/Calcul_Erreur_Fuzzy']);
if isempty(chartErr); error('Objet Stateflow.EMChart introuvable pour Calcul_Erreur_Fuzzy.'); end
chartErr.Script = code_erreur_F1;
fprintf('Code (re)injecte dans "Calcul_Erreur_Fuzzy" (Vref en entree) dans %s.\n', mdl);

try
    set_param(mdl, 'SimulationCommand', 'update');
catch
end
nb_ports_erreur_F1 = get_param([mdl '/Calcul_Erreur_Fuzzy'], 'Ports');
if nb_ports_erreur_F1(1) ~= 2 || nb_ports_erreur_F1(2) ~= 3
    error('"Calcul_Erreur_Fuzzy" a %d entree(s)/%d sortie(s) au lieu de 2/3 dans %s.', ...
        nb_ports_erreur_F1(1), nb_ports_erreur_F1(2), mdl);
end
ligne_si_possible(mdl, 'Constant1/1', 'Calcul_Erreur_Fuzzy/2');
fprintf('Bloc "Constant1" verifie et (re)connecte a "Calcul_Erreur_Fuzzy" dans %s.\n', mdl);

% -------------------------------------------------------------------
% ETAPE A : re-injection de la loi incrementale avec les bornes MU
% elargies (le bloc existe deja, copie depuis le nominal -- on ne
% touche que son contenu Stateflow, sans le detruire : contrairement au
% bloc FLC natif, chart.Script ecrit sans condition de detection de
% changement, voir la note du script nominal a ce sujet).
% -------------------------------------------------------------------
if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Loi_Incrementale_Fuzzy'))
    error('Bloc "Loi_Incrementale_Fuzzy" introuvable dans %s -- copie du nominal corrompue ou incomplete.', mdl);
end
S = sfroot;
chart = S.find('-isa', 'Stateflow.EMChart', 'Path', [mdl '/Loi_Incrementale_Fuzzy']);
if isempty(chart); error('Objet Stateflow.EMChart introuvable pour Loi_Incrementale_Fuzzy.'); end
chart.Script = code_loi_F1;
fprintf('Bornes MU de "Loi_Incrementale_Fuzzy" mises a jour pour F1 : [%.2g, %.2g].\n', MU_MIN_F1, MU_MAX_F1);

try
    set_param(mdl, 'SimulationCommand', 'update');
catch
end
nb_sorties_loi = get_param([mdl '/Loi_Incrementale_Fuzzy'], 'Ports');
if nb_sorties_loi(2) ~= 4
    error('"Loi_Incrementale_Fuzzy" a %d sortie(s) au lieu de 4 apres re-injection.', nb_sorties_loi(2));
end
fprintf('Verifie : "Loi_Incrementale_Fuzzy" a toujours 4 sorties (mu, Kp, Ki, Kd).\n');

% -------------------------------------------------------------------
% ETAPE B : suppression des lignes DIRECTES issues du nominal qui vont
% court-circuiter le nouveau montage (mu -> PWM Generator directement,
% mu -> Scope_Commande_Fuzzy directement). Verification explicite de la
% source avant suppression, comme partout ailleurs dans ce projet :
% seule une ligne provenant bien de "Loi_Incrementale_Fuzzy" est
% supprimee, jamais une ligne deja correctement redirigee lors d'une
% relance precedente de ce script.
% -------------------------------------------------------------------
supprime_ligne_si_source(mdl, [nom_pwm '/1'], 'Loi_Incrementale_Fuzzy');
supprime_ligne_si_source(mdl, 'Scope_Commande_Fuzzy/1', 'Loi_Incrementale_Fuzzy');

% -------------------------------------------------------------------
% ETAPE C : horloge + bloc de perturbation F1(t)
% -------------------------------------------------------------------
if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Horloge_F1'))
    add_block('simulink/Sources/Clock', [mdl '/Horloge_F1']);
    set_param([mdl '/Horloge_F1'], 'Position', [640 460 660 480]);
    fprintf('Bloc "Horloge_F1" cree.\n');
else
    fprintf('Bloc "Horloge_F1" deja present -- reutilise.\n');
end

if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Perturbation_F1'))
    add_block('simulink/User-Defined Functions/MATLAB Function', [mdl '/Perturbation_F1']);
    set_param([mdl '/Perturbation_F1'], 'Position', [700 445 830 495]);
    fprintf('Bloc "Perturbation_F1" cree.\n');
else
    fprintf('Bloc "Perturbation_F1" deja present -- reutilise.\n');
end

try
    S = sfroot;
    chartF1 = S.find('-isa', 'Stateflow.EMChart', 'Path', [mdl '/Perturbation_F1']);
    if isempty(chartF1); error('Objet Stateflow.EMChart introuvable pour Perturbation_F1.'); end
    chartF1.Script = code_F1;
    fprintf('Code (re)injecte dans "Perturbation_F1".\n');
catch ME
    fprintf(2, ['\n*** ATTENTION : injection automatique echouee (%s).\n' ...
        '*** SECOURS MANUEL : ouvrez le bloc "Perturbation_F1" dans %s.slx,\n' ...
        '*** effacez son contenu par defaut, collez-y code_perturbation_F1.txt,\n' ...
        '*** sauvegardez, puis relancez ce script.\n\n'], ME.message, mdl);
end

try
    set_param(mdl, 'SimulationCommand', 'update');
catch
end
nb_sorties_F1 = get_param([mdl '/Perturbation_F1'], 'Ports');
if nb_sorties_F1(2) ~= 1
    error('"Perturbation_F1" a %d sortie(s) au lieu de 1 : injection non prise en compte.', nb_sorties_F1(2));
end
fprintf('Verifie : "Perturbation_F1" a bien 1 sortie (F1(t)).\n');

% -------------------------------------------------------------------
% ETAPE D : sommation mu + F1(t), puis saturation physique unique
% -------------------------------------------------------------------
if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Sum_Commande_F1'))
    add_block('simulink/Math Operations/Sum', [mdl '/Sum_Commande_F1']);
    set_param([mdl '/Sum_Commande_F1'], 'Inputs', '++', 'Position', [860 300 890 340]);
    fprintf('Bloc "Sum_Commande_F1" cree (++, voir en-tete pour la discussion du signe).\n');
else
    fprintf('Bloc "Sum_Commande_F1" deja present -- reutilise.\n');
end

if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Saturation_Commande_F1'))
    add_block('simulink/Discontinuities/Saturation', [mdl '/Saturation_Commande_F1']);
    set_param([mdl '/Saturation_Commande_F1'], 'UpperLimit', '0.99', 'LowerLimit', '0.01', ...
        'Position', [920 300 950 340]);
    fprintf('Bloc "Saturation_Commande_F1" cree ([0.01, 0.99], saturation physique unique -- regle n=13).\n');
else
    fprintf('Bloc "Saturation_Commande_F1" deja present -- reutilise.\n');
end

% -------------------------------------------------------------------
% ETAPE E : logs et scope dedies a F1 (verification du profil de
% perturbation lui-meme + signal de commande final reellement applique
% au PWM Generator, distinct du mu "brut" deja logue en Log_mu_fuzzy)
% -------------------------------------------------------------------
if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Log_F1_signal'))
    add_block('simulink/Sinks/To Workspace', [mdl '/Log_F1_signal']);
    set_param([mdl '/Log_F1_signal'], 'VariableName', 'F1_signal', 'SaveFormat', 'Timeseries', ...
        'SampleTime', num2str(T), 'Position', [860 460 940 480]);
    fprintf('Bloc "Log_F1_signal" cree.\n');
else
    fprintf('Bloc "Log_F1_signal" deja present -- reutilise.\n');
end

if isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'Log_Commande_F1'))
    add_block('simulink/Sinks/To Workspace', [mdl '/Log_Commande_F1']);
    set_param([mdl '/Log_Commande_F1'], 'VariableName', 'mu_commande_F1', 'SaveFormat', 'Timeseries', ...
        'SampleTime', num2str(T), 'Position', [980 300 1060 320]);
    fprintf('Bloc "Log_Commande_F1" cree.\n');
else
    fprintf('Bloc "Log_Commande_F1" deja present -- reutilise.\n');
end

% -------------------------------------------------------------------
% ETAPE F : cablage complet du montage F1
% -------------------------------------------------------------------
ligne_si_possible(mdl, 'Horloge_F1/1', 'Perturbation_F1/1');
ligne_si_possible(mdl, 'Loi_Incrementale_Fuzzy/1', 'Sum_Commande_F1/1');
ligne_si_possible(mdl, 'Perturbation_F1/1', 'Sum_Commande_F1/2');
ligne_si_possible(mdl, 'Sum_Commande_F1/1', 'Saturation_Commande_F1/1');
ligne_si_possible(mdl, 'Saturation_Commande_F1/1', sprintf('%s/1', nom_pwm));
ligne_si_possible(mdl, 'Saturation_Commande_F1/1', 'Scope_Commande_Fuzzy/1');   % scope redirige vers le signal final (regle n=14)
ligne_si_possible(mdl, 'Saturation_Commande_F1/1', 'Log_Commande_F1/1');
ligne_si_possible(mdl, 'Perturbation_F1/1', 'Log_F1_signal/1');

fprintf('Cablage du montage F1 verifie/complete.\n');
fprintf(['Rappel : "Log_mu_fuzzy" continue de logger le mu BRUT (avant F1(t) et\n' ...
    'avant saturation) -- utile pour comparer le comportement du correcteur\n' ...
    'seul entre nominal et F1. Le signal REELLEMENT applique au PWM Generator\n' ...
    'est "mu_commande_F1" (Log_Commande_F1), post-Sum et post-saturation.\n']);

% Meme correctif que dans le script de construction nominal (voir ce
% fichier pour la justification complete, y compris l'erreur a ne pas
% reproduire) : "To Workspace"/"To Workspace1" (y/x) viennent du modele
% d'origine, herites sans SaveFormat explicite. On force UNIQUEMENT
% SaveFormat=Timeseries (garantit Time/Data de meme longueur par
% construction, ce qui regle le crash) -- SampleTime reste herite (-1,
% cadence continue du reseau Simscape) pour ne PAS sous-echantillonner le
% ripple de Vout par rapport a la mesure de reference (une premiere
% version forcait aussi SampleTime=T ; constat reel sur le nominal :
% ripple mesure -5.3% par rapport a la reference alors que Ki restait
% identique a 0.00% pres -- signature d'un artefact de mesure, pas d'une
% regression de cablage).
if ~isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'To Workspace'))
    set_param([mdl '/To Workspace'], 'SaveFormat', 'Timeseries');
    fprintf('Bloc "To Workspace" (variable "y"/Vout) : SaveFormat force a Timeseries (SampleTime laisse herite, -1).\n');
end
if ~isempty(find_system(mdl, 'SearchDepth', 1, 'Name', 'To Workspace1'))
    set_param([mdl '/To Workspace1'], 'SaveFormat', 'Timeseries');
    fprintf('Bloc "To Workspace1" (variable "x") : SaveFormat force a Timeseries (SampleTime laisse herite, -1).\n');
end

save_system(mdl, [], 'OverwriteIfChangedOnDisk', true);
fprintf('\nModele sauvegarde : %s.slx\n', mdl);

% =====================================================================
% ETAPE FINALE : nettoyage + verification du fichier .slx SUR DISQUE.
% Identique au script de construction nominal -- voir ce fichier pour la
% justification complete. Reference utilisee ici : le nominal
% Fuzzy_PID_Control.slx (dont F1 est une copie), pas PID_Classique_Control
% directement -- la topologie du circuit de puissance est censee etre
% identique aux deux etages puisque F1 ne fait que copier le nominal deja
% valide sans toucher a l'etage de puissance.
% =====================================================================
if bdIsLoaded(mdl); close_system(mdl, 0); end
finaliser_fichier_slx([mdl '.slx'], [modele_nominal '.slx']);
open_system(mdl);

% =====================================================================
% FONCTIONS LOCALES (doivent rester en fin de fichier)
% =====================================================================
function ligne_si_possible(mdl, src, dst)
% Identique a la fonction du script de construction nominal -- voir ce
% fichier pour la justification complete (verification directe de l'etat
% du port de destination via PortHandles/Line, plutot que d'intercepter
% et d'interpreter le texte d'une erreur d'add_line).
    idxSlash = find(dst == '/', 1, 'last');
    if isempty(idxSlash)
        add_line(mdl, src, dst, 'autorouting', 'on');
        return;
    end
    blocDst = dst(1:idxSlash-1);
    numPort = str2double(dst(idxSlash+1:end));
    ph = get_param([mdl '/' blocDst], 'PortHandles');
    if numPort > numel(ph.Inport)
        error('ligne_si_possible:portIntrouvable', ...
            ['Le port d''entree %d de "%s" n''existe pas (%d port(s) d''entree ' ...
             'trouve(s) sur ce bloc). Verifiez le nom/l''index de port.'], ...
            numPort, blocDst, numel(ph.Inport));
    end
    if get_param(ph.Inport(numPort), 'Line') ~= -1
        fprintf('Ligne %s -> %s deja presente (port verifie occupe) -- ignoree.\n', src, dst);
    else
        add_line(mdl, src, dst, 'autorouting', 'on');
        fprintf('Ligne %s -> %s posee.\n', src, dst);
    end
end

function supprime_ligne_si_source(mdl, dst, nomSourceAttendue)
% Supprime la ligne arrivant sur le port d'entree "dst" UNIQUEMENT si son
% bloc source porte le nom "nomSourceAttendue" -- jamais a l'aveugle.
% Utilise ici pour retirer les deux cablages directs herites du nominal
% (mu -> PWM Generator, mu -> Scope_Commande_Fuzzy) qui doivent ceder la
% place au nouveau montage Sum+Saturation, tout en restant idempotent :
% si ce script a deja tourne une fois et que ces ports pointent desormais
% vers "Saturation_Commande_F1", cette fonction ne touche plus rien.
    idxSlash = find(dst == '/', 1, 'last');
    blocDst = dst(1:idxSlash-1);
    numPort = str2double(dst(idxSlash+1:end));
    ph = get_param([mdl '/' blocDst], 'PortHandles');
    if numPort > numel(ph.Inport)
        return;   % port inexistant : rien a faire, pas une erreur ici (bloc pas encore construit au premier passage)
    end
    ligne = get_param(ph.Inport(numPort), 'Line');
    if ligne == -1
        return;   % rien de connecte, rien a supprimer
    end
    srcH = get_param(ligne, 'SrcBlockHandle');
    nomSource = '';
    if ~isempty(srcH) && all(ishandle(srcH))
        nomSource = get_param(srcH, 'Name');
    end
    if strcmp(nomSource, nomSourceAttendue)
        delete_line(ligne);
        fprintf('Ligne residuelle supprimee : %s recevait directement "%s" (herite du nominal) -- retiree pour laisser place au montage F1.\n', dst, nomSourceAttendue);
    else
        fprintf('Entree %s deja cablee depuis "%s" (pas depuis "%s") -- conservee.\n', dst, nomSource, nomSourceAttendue);
    end
end

function purge_branches_orphelines(mdl, blocSrc, numPortSrc)
% Identique a la fonction du script de construction nominal
% (Construction_Simulink_Fuzzy_PID.m) -- voir ce fichier pour le
% diagnostic complet (branche fantome laissee par delete_block sur une
% ligne a embranchements, confirme par inspection directe du XML du
% .slx). Capture les vraies destinations, supprime la ligne entiere, la
% reconstruit sans la branche fantome. Idempotent : sans branche fantome,
% demonte/remonte a l'identique.
%
% CORRECTION (apres echec reel : "Invalid Simulink port handle", meme bug
% que dans le script nominal) : ne jamais faire transiter un HANDLE a
% travers delete_line (un handle Simulink n'est garanti valide que jusqu'a
% la PROCHAINE modification programmatique du diagramme) -- seulement des
% donnees stables (chemin de bloc via getfullname, numero de port),
% capturees avant, reconverties en handles frais apres.
    ph = get_param([mdl '/' blocSrc], 'PortHandles');
    if numPortSrc > numel(ph.Outport)
        error('purge_branches_orphelines:portIntrouvable', ...
            'Le port de sortie %d de "%s" n''existe pas.', numPortSrc, blocSrc);
    end
    portSrc = ph.Outport(numPortSrc);
    ligneH = get_param(portSrc, 'Line');
    if ligneH == -1
        fprintf('"%s" (sortie %d) : aucune ligne posee -- rien a purger.\n', blocSrc, numPortSrc);
        return;
    end

    dstBlocH = get_param(ligneH, 'DstBlockHandle');
    dstPortH = get_param(ligneH, 'DstPortHandle');
    nbTotal = numel(dstBlocH);

    % CORRECTION (meme 2e echec reel que le script nominal : "Invalid
    % Simulink object handle" sur getfullname) : une branche fantome
    % OCCUPE une entree dans DstBlockHandle/DstPortHandle, avec un handle
    % -1 (convention Simulink standard), elle n'en est pas absente comme
    % suppose initialement. Filtre explicite avant tout getfullname.
    dstChemins = {};
    dstNumPorts = [];
    for i = 1:nbTotal
        if dstBlocH(i) ~= -1 && ishandle(dstBlocH(i))
            dstChemins{end+1} = getfullname(dstBlocH(i)); %#ok<AGROW>
            dstNumPorts(end+1) = get_param(dstPortH(i), 'PortNumber'); %#ok<AGROW>
        end
    end
    nbAvant = numel(dstChemins);

    if nbAvant < nbTotal
        fprintf('%d branche(s) fantome(s) (sans destination reelle) detectee(s) et eliminee(s) sur la ligne issue de "%s" (sortie %d).\n', ...
            nbTotal - nbAvant, blocSrc, numPortSrc);
    end
    if nbAvant == 0
        fprintf(2, ['*** ATTENTION : la ligne issue de "%s" (sortie %d) n''a AUCUNE destination ' ...
            'reelle. Suppression sans reconnexion -- verifiez manuellement si un cablage etait ' ...
            'pourtant attendu ici.\n'], blocSrc, numPortSrc);
    end

    delete_line(ligneH);

    ph = get_param([mdl '/' blocSrc], 'PortHandles');
    portSrc = ph.Outport(numPortSrc);
    for i = 1:nbAvant
        phDst = get_param(dstChemins{i}, 'PortHandles');
        add_line(mdl, portSrc, phDst.Inport(dstNumPorts(i)), 'autorouting', 'on');
    end

    fprintf(['Ligne issue de "%s" (sortie %d) reconstruite : %d destination(s) reelle(s) ' ...
        'conservee(s), toute branche fantome (sans destination) eliminee.\n'], ...
        blocSrc, numPortSrc, nbAvant);
end

function finaliser_fichier_slx(fichierCible, fichierReference)
% Reecrit fichierCible EN PLACE si besoin (suppression des lignes
% purement decoratives) puis verifie que la topologie de son circuit de
% puissance correspond EXACTEMENT a celle de fichierReference. Arrete le
% script (error) si la verification finale echoue.
%
% CORRECTION (bug reel observe en conditions reelles, via un log
% d'execution : "Finalisation ... OK -- 0 noeud(s) physique(s)" -- un
% FAUX POSITIF silencieux) -- voir Construction_Simulink_Fuzzy_PID.m
% pour la justification complete : MATLAB passe les tableaux aux
% methodes Java PAR COPIE, donc l'ancienne boucle manuelle
% InputStream.read(byte[], int, int) ne remplissait jamais reellement
% le tampon MATLAB -- elle renvoyait un tableau de ZEROS de la bonne
% longueur, silencieusement. Fix : abandon complet de java.util.zip
% pour la lecture/reecriture, remplace par les fonctions NATIVES de
% MATLAB -- unzip()/fileread() pour lire (aucun tableau ne sert de
% parametre de sortie a une methode Java, donc ce bug est
% structurellement impossible) et fopen/fwrite/fclose + zip() natif
% pour reecrire.
    if ~isfile(fichierCible)
        error('finaliser_fichier_slx:fichierIntrouvable', ...
            'Fichier introuvable : %s', fichierCible);
    end
    if ~isfile(fichierReference)
        error('finaliser_fichier_slx:fichierIntrouvable', ...
            'Fichier de reference introuvable : %s', fichierReference);
    end

    texte = lire_system_root_xml(fichierCible);
    [texteNettoye, nbSupprimees] = purger_lignes_decoratives_texte(texte);

    if nbSupprimees > 0
        ecrire_system_root_xml(fichierCible, texteNettoye);
        fprintf('Finalisation : %d ligne(s) purement decorative(s) supprimee(s) de %s.\n', ...
            nbSupprimees, fichierCible);
        texteFinal = texteNettoye;
    else
        fprintf('Finalisation : aucune ligne decorative dans %s.\n', fichierCible);
        texteFinal = texte;
    end

    reseauxCible = extraire_reseaux_physiques_texte(texteFinal);

    texteRef = lire_system_root_xml(fichierReference);
    reseauxRef = extraire_reseaux_physiques_texte(texteRef);

    % Garde-fou anti-faux-positif (directement motive par le bug
    % ci-dessus) : un circuit de puissance reel a TOUJOURS au moins 1
    % noeud physique. Si l'un ou l'autre releve est vide, la
    % lecture/l'extraction a echoue quelque part -- on s'arrete plutot
    % que de comparer deux ensembles vides et de conclure a tort a une
    % "identite".
    if isempty(reseauxRef)
        error('finaliser_fichier_slx:lectureReferenceEchouee', ...
            ['Aucun noeud physique extrait de la reference "%s" -- lecture/extraction ' ...
             'probablement en echec (fichier vide, corrompu, ou bug d''extraction). ' ...
             'Verification interrompue plutot que de valider a tort.'], fichierReference);
    end
    if isempty(reseauxCible)
        error('finaliser_fichier_slx:lectureCibleEchouee', ...
            ['Aucun noeud physique extrait de "%s" alors que la reference en a %d -- lecture/extraction ' ...
             'probablement en echec (fichier vide, corrompu, ou bug d''extraction). ' ...
             'Verification interrompue plutot que de valider a tort.'], fichierCible, numel(reseauxRef));
    end

    manquants = setdiff(reseauxRef, reseauxCible);
    imprevus = setdiff(reseauxCible, reseauxRef);

    if isempty(manquants) && isempty(imprevus)
        % Preuve finale, la seule qui compte vraiment : Simulink
        % lui-meme doit pouvoir charger le fichier (voir
        % Construction_Simulink_Fuzzy_PID.m pour la justification
        % complete -- la verification texte ci-dessus, unzip+fileread,
        % ne suffit pas : elle a laisse passer sans le detecter un bug
        % reel d'entrees d'archive nommees avec l'antislash de Windows).
        [~, nomModele] = fileparts(fichierCible);
        try
            load_system(fichierCible);
            close_system(nomModele, 0);
        catch ME
            error('finaliser_fichier_slx:fichierIllisibleParSimulink', ...
                ['Le fichier "%s" a ete rebati (topologie et contenu XML verifies corrects ' ...
                 'ci-dessus) mais Simulink lui-meme ne parvient pas a le charger : %s. ' ...
                 'L''archive .slx est donc invalide malgre un contenu textuel correct -- ' ...
                 'NE PAS utiliser ce fichier tel quel.'], fichierCible, ME.message);
        end

        fprintf(['Finalisation : verification topologie circuit de puissance OK -- %d noeud(s) ' ...
            'physique(s) identiques a "%s".\n'], numel(reseauxRef), fichierReference);
        fprintf('Finalisation : fichier "%s" confirme chargeable par Simulink (load_system reussi).\n', ...
            fichierCible);
        return;
    end

    fprintf(2, '\n*** ECHEC VERIFICATION TOPOLOGIE CIRCUIT DE PUISSANCE (finaliser_fichier_slx) ***\n');
    for i = 1:numel(manquants)
        fprintf(2, '  Noeud attendu ABSENT (circuit fragmente)  : %s\n', manquants{i});
    end
    for i = 1:numel(imprevus)
        fprintf(2, '  Noeud INATTENDU (cablage different)       : %s\n', imprevus{i});
    end
    error('finaliser_fichier_slx:topologieIncorrecte', ...
        ['Le circuit de puissance de "%s" ne correspond PAS a celui de "%s". ' ...
         'Construction interrompue -- NE PAS utiliser ce fichier tel quel (details ci-dessus).'], ...
        fichierCible, fichierReference);
end

function texte = lire_system_root_xml(fichierSlx)
% Lit le contenu de "simulink/systems/system_root.xml" a l'interieur
% d'une archive .slx, comme une chaine de caracteres MATLAB. Utilise
% unzip() (extraction native MATLAB vers un dossier temporaire) puis
% fileread() (lecture native, retourne toujours un vecteur LIGNE de
% caracteres) -- aucun tableau ne transite par une methode Java en tant
% que parametre de sortie, donc le bug de copie decrit dans
% finaliser_fichier_slx est ici structurellement impossible.
    dossierTmp = tempname();
    mkdir(dossierTmp);
    nettoyeur = onCleanup(@() rmdir(dossierTmp, 's')); %#ok<NASGU>
    try
        unzip(fichierSlx, dossierTmp);
    catch ME
        error('lire_system_root_xml:unzipEchec', ...
            'Echec de l''extraction de "%s" : %s', fichierSlx, ME.message);
    end
    cheminXml = fullfile(dossierTmp, 'simulink', 'systems', 'system_root.xml');
    if ~isfile(cheminXml)
        error('lire_system_root_xml:xmlIntrouvable', ...
            '"simulink/systems/system_root.xml" introuvable dans %s -- fichier .slx inattendu.', ...
            fichierSlx);
    end
    texte = fileread(cheminXml);
end

function ecrire_system_root_xml(fichierSlx, texteNouveau)
% Reecrit "simulink/systems/system_root.xml" EN PLACE a l'interieur de
% l'archive .slx : extrait toute l'archive dans un dossier temporaire,
% remplace uniquement ce fichier sur disque (fopen/fwrite/fclose), puis
% recompresse le dossier entier a l'identique.
%
% CORRECTION (2e bug reel, distinct du precedent -- voir
% Construction_Simulink_Fuzzy_PID.m pour la justification complete) --
% ERREUR A NE PAS REPRODUIRE : la version precedente recompressait via
% zip(zipfilename, files, rootDir), qui sur Windows nomme les entrees
% avec l'antislash de l'OS ("simulink\blockdiagram.xml") au lieu du
% slash exige par le format .slx (Open Packaging Conventions, meme
% famille que .docx/.xlsx) -- confirme par une erreur reelle a
% l'open_system() suivant : « does not contain the requested part:
% /simulink/blockdiagram.xml ». Le contenu binaire est intact, seul le
% NOM D'ENTREE ne correspond plus a ce que Simulink recherche.
%
% Fix : abandon de zip() pour l'ECRITURE, remplace par
% java.util.zip.ZipOutputStream/ZipEntry avec CHAQUE nom d'entree force
% en slash explicitement (ZipEntry ne reinterprete jamais la chaine
% qu'on lui donne). Chaque fichier est lu par fread() natif (jamais via
% un InputStream Java) avant d'etre ecrit dans le flux --
% ZipOutputStream.write(byte[], off, len) recoit le tableau en
% parametre d'entree simple, pas en parametre de sortie Java, donc cette
% direction ne souffre pas du bug de copie qui affectait la lecture.
    dossierTmp = tempname();
    mkdir(dossierTmp);
    nettoyeur = onCleanup(@() rmdir(dossierTmp, 's')); %#ok<NASGU>

    unzip(fichierSlx, dossierTmp);

    cheminXml = fullfile(dossierTmp, 'simulink', 'systems', 'system_root.xml');
    fid = fopen(cheminXml, 'w');
    if fid == -1
        error('ecrire_system_root_xml:ecritureEchec', ...
            'Impossible d''ouvrir "%s" en ecriture.', cheminXml);
    end
    try
        fwrite(fid, unicode2native(texteNouveau, 'UTF-8'), 'uint8');
    catch ME
        fclose(fid);
        rethrow(ME);
    end
    fclose(fid);

    % Reconstruit la liste complete des fichiers extraits (toutes les
    % entrees de l'archive d'origine, pas seulement le XML modifie) pour
    % que l'archive reecrite les contienne toutes.
    fichiers = recenser_fichiers(dossierTmp);

    fichierZipTmp = [fichierSlx '.tmp'];
    if isfile(fichierZipTmp); delete(fichierZipTmp); end
    flux = java.io.FileOutputStream(fichierZipTmp);
    zipOut = java.util.zip.ZipOutputStream(flux);
    try
        for i = 1:numel(fichiers)
            cheminAbsolu = fichiers{i};
            % Nom d'entree relatif a dossierTmp, force en slash (voir
            % justification ci-dessus) quel que soit le filesep() de la
            % plateforme.
            nomEntree = strrep(erase(cheminAbsolu, [dossierTmp filesep]), filesep, '/');
            zipOut.putNextEntry(java.util.zip.ZipEntry(nomEntree));
            fidLecture = fopen(cheminAbsolu, 'r');
            if fidLecture == -1
                zipOut.close();
                error('ecrire_system_root_xml:lectureEchec', ...
                    'Impossible d''ouvrir "%s" en lecture.', cheminAbsolu);
            end
            octetsFichier = fread(fidLecture, Inf, '*uint8');
            fclose(fidLecture);
            if ~isempty(octetsFichier)
                zipOut.write(typecast(octetsFichier, 'int8'), 0, numel(octetsFichier));
            end
            zipOut.closeEntry();
        end
    catch ME
        zipOut.close();
        rethrow(ME);
    end
    zipOut.close();

    if ~isfile(fichierZipTmp)
        error('ecrire_system_root_xml:zipEchec', ...
            'La reecriture de l''archive n''a pas produit le fichier attendu (%s).', fichierZipTmp);
    end

    if isfile(fichierSlx); delete(fichierSlx); end
    movefile(fichierZipTmp, fichierSlx);
end

function fichiers = recenser_fichiers(dossier)
% Liste recursivement tous les fichiers (chemins complets) sous
% "dossier", pour les reecrire un par un dans la nouvelle archive.
    tout = dir(fullfile(dossier, '**', '*'));
    tout = tout(~[tout.isdir]);
    fichiers = fullfile({tout.folder}, {tout.name});
end

function [texteNettoye, nbSupprimees] = purger_lignes_decoratives_texte(texte)
% Supprime toute <Line>...</Line> ne contenant, nulle part dans son
% texte (branches imbriquees comprises), ni Name="Src" ni Name="Dst".
% Une <Line> ne contient jamais une autre <Line> imbriquee (seulement
% des <Branch>), donc une correspondance regex non gourmande entre
% <Line> et </Line> suffit.
    [debuts, fins] = regexp(texte, '<Line>.*?</Line>', 'start', 'end', 'dotall');
    nbSupprimees = 0;
    morceaux = {};
    curseur = 1;
    for i = 1:numel(debuts)
        d = debuts(i); f = fins(i);
        contenu = texte(d:f);
        aSrcOuDst = contains(contenu, 'Name="Src"') || contains(contenu, 'Name="Dst"');
        morceaux{end+1} = texte(curseur:d-1); %#ok<AGROW>
        if aSrcOuDst
            morceaux{end+1} = contenu; %#ok<AGROW>
        else
            nbSupprimees = nbSupprimees + 1;
        end
        curseur = f + 1;
    end
    morceaux{end+1} = texte(curseur:end); %#ok<AGROW>
    texteNettoye = strjoin(morceaux, '');
end

function reseaux = extraire_reseaux_physiques_texte(texte)
% Retourne l'ensemble (cellstr trie/unique) des noeuds physiques du
% circuit de puissance : un noeud par <Line LineType="Connection">,
% represente comme la liste triee et concatenee de toutes les
% references SID#port qu'il contient (P Name="Src" ou "Dst", a
% n'importe quelle profondeur de branche). Comparaison par SID brut
% (pas par nom de bloc resolu) -- suffisant et plus simple ici car les
% blocs de l'etage de puissance conservent des SID identiques entre
% PID_Classique_Control.slx et toutes les variantes Fuzzy-PID/F1/F2
% construites a partir de lui (verifie sur ce projet).
    [debuts, fins] = regexp(texte, '<Line[^>]*>.*?</Line>', 'start', 'end', 'dotall');
    reseaux = {};
    for i = 1:numel(debuts)
        contenu = texte(debuts(i):fins(i));
        enTete = regexp(contenu, '^<Line[^>]*>', 'match', 'once');
        if isempty(strfind(enTete, 'LineType="Connection"')) %#ok<STREMP>
            continue;
        end
        refs = regexp(contenu, '<P Name="(?:Src|Dst)">([^<]+)</P>', 'tokens');
        extremites = {};
        for k = 1:numel(refs)
            extremites{end+1} = refs{k}{1}; %#ok<AGROW>
        end
        if ~isempty(extremites)
            extremites = unique(extremites);
            reseaux{end+1} = strjoin(sort(extremites), ' | '); %#ok<AGROW>
        end
    end
    reseaux = unique(reseaux);
end
