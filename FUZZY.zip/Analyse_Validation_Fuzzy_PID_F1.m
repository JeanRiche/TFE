%% Analyse_Validation_Fuzzy_PID_F1.m
% =========================================================================
%   VALIDATION NUMERIQUE DU SCENARIO F1 (PERTURBATION DE COMMANDE) --
%   FUZZY-PID -- meme niveau de rigueur que Analyse_mu_F2_vs_Nominal.m
% =========================================================================
%
% POURQUOI CE SCRIPT : contrairement au nominal (Test_Validation_Fuzzy_
% PID_Nominal.m) et a F2 (Analyse_mu_F2_vs_Nominal.m), le scenario F1 n'a
% jamais eu de script de validation numerique dedie dans ce projet -- sa
% construction (Construction_Simulink_Fuzzy_PID_F1.m) documente bien deux
% corrections reelles trouvees sur des runs passes (lecture de F1(t),
% ligne e=NB de la table de regles affamant Ki), mais aucun chiffre de
% CE script n'a ete mesure ici. Avant d'ecrire quoi que ce soit dans la
% section "Resultats de validation" du memoire, ce script mesure
% reellement, sur le fichier .slx tel qu'il existe aujourd'hui :
%   1) que le profil de F1(t) reellement simule correspond a sa
%      definition (Lu et al. 2021, section 5.2) ;
%   2) que Vout reagit dans le bon sens et revient completement a Vref
%      apres la fin de la perturbation (critere de validation retenu
%      pour ce scenario, voir en-tete du script de construction) ;
%   3) que Ki ne reste pas fige apres le passage de l'erreur en zone NB
%      (verification directe que le bug deja trouve et corrige dans
%      construction_FIS_Fuzzy_PID.m ne s'est pas reintroduit) ;
%   4) que le comportement de chatter de mu, HORS fenetre de
%      perturbation, reste conforme a celui du nominal deja valide
%      (meme demarche que pour F2).
%
% Ce script ne modifie aucun fichier .slx et ne tranche aucune conclusion
% a la place de l'utilisateur -- il mesure et affiche, a charge de
% lecture au meme niveau d'exigence que pour F2.
% =========================================================================

clear; clc;

% Meme mecanisme que Analyse_mu_F2_vs_Nominal.m : le clear ci-dessus vide
% "fisFuzzyPID" du workspace de base, or FLC_Fuzzy_PID (nominal ET F1) le
% referencent par son parametre FIS a l'execution de sim(). Rechargement
% explicite avant toute simulation, identique au fichier .mat/variable
% utilises par la construction d'origine.
if ~exist('fuzzy_pid_buck.mat', 'file')
    error(['Fichier fuzzy_pid_buck.mat introuvable sur le chemin MATLAB courant. ' ...
           'Placez-vous dans le dossier qui le contient avant de relancer ce script.']);
end
d_fis = load('fuzzy_pid_buck.mat');
assignin('base', 'fisFuzzyPID', d_fis.fis);
fprintf('"fisFuzzyPID" recharge dans le workspace de base depuis fuzzy_pid_buck.mat (%d regles).\n\n', ...
    numel(d_fis.fis.Rules));

mdlNominal = 'Fuzzy_PID_Control';
mdlF1      = 'Fuzzy_PID_Control_F1';

Vref = 100;
Vin  = 200;

% -------------------------------------------------------------------
% ETAPE 1 : nominal -- simulation puis extraction IMMEDIATE (avant que F1
% n'ecrase les memes noms de variable dans le workspace de base)
% -------------------------------------------------------------------
fprintf('=========================================================\n');
fprintf(' NOMINAL (%s)\n', mdlNominal);
fprintf('=========================================================\n');
if isempty(which([mdlNominal '.slx']))
    error('Fichier "%s.slx" introuvable sur le chemin MATLAB.', mdlNominal);
end
load_system(mdlNominal);
% CORRECTION (trouvee en relisant deux runs successifs de ce script : le
% nominal est sorti a 200001 points (t=0 a t=1) une fois, puis a 40001
% points (t=0 a t=0.2) une autre fois, SANS qu'aucune ligne de ce script ne
% touche StopTime -- c'est donc le StopTime SAUVEGARDE dans le fichier
% .slx qui a change entre les deux runs, en dehors de ce script. Les deux
% runs donnaient malgre tout le meme Ki a la fenetre [0.18,0.2]s (6183 dans
% les deux cas -- une simulation causale a pas fixe ne peut pas dependre de
% ce qui se passe apres l'instant mesure), donc aucun chiffre deja rapporte
% n'etait faux. Mais rien ne garantit que StopTime reste toujours >= 0.2s :
% fixe ici explicitement a 0.2s (suffisant pour toutes les fenetres
% utilisees par ce script, et identique a la duree de F1) plutot que de
% dependre d'une valeur sauvegardee non controlee par ce script.
set_param(mdlNominal, 'StopTime', '0.2');
% AJOUT (demande explicite : etendre la decomposition de contribution
% Kp*xc1/Ki*xc2/Kd*xc3, ETAPE 4sexies de Test_Validation_Fuzzy_PID_
% Nominal.m, au-dela du seul regime nominal a [0.98,1.00]s -- voir MESURE 6
% plus bas). Blocs de logging temporaires, memes noms/branchements que
% ETAPE 4quinquies de ce meme script nominal (Calcul_Erreur_Fuzzy/1-2-3 =
% xc2/xc1/xc3, PAS un ordre 1-2-3 naturel -- verifie sur ce script-source,
% pas suppose). Ajoutes sur le modele CHARGE EN MEMOIRE uniquement ;
% close_system(...,0) ci-dessous ne sauvegarde jamais rien sur disque.
add_block('simulink/Sinks/To Workspace', [mdlNominal '/Log_xc2_tmp'], ...
    'VariableName', 'xc2_log', 'SaveFormat', 'Timeseries', 'Position', [400 220 460 240]);
add_block('simulink/Sinks/To Workspace', [mdlNominal '/Log_xc1_tmp'], ...
    'VariableName', 'xc1_log', 'SaveFormat', 'Timeseries', 'Position', [400 260 460 280]);
add_block('simulink/Sinks/To Workspace', [mdlNominal '/Log_xc3_tmp'], ...
    'VariableName', 'xc3_log', 'SaveFormat', 'Timeseries', 'Position', [400 300 460 320]);
add_line(mdlNominal, 'Calcul_Erreur_Fuzzy/1', 'Log_xc2_tmp/1', 'autorouting', 'on');
add_line(mdlNominal, 'Calcul_Erreur_Fuzzy/2', 'Log_xc1_tmp/1', 'autorouting', 'on');
add_line(mdlNominal, 'Calcul_Erreur_Fuzzy/3', 'Log_xc3_tmp/1', 'autorouting', 'on');
set_param(mdlNominal, 'ReturnWorkspaceOutputs', 'off');   % regle de construction n=8, reaffirmee avant chaque sim
fprintf('Simulation de %s...\n', mdlNominal);
sim(mdlNominal);
[t_nom, y_nom]  = extraire_temps_valeurs(evalin('base', 'y'),        'y (Vout, nominal)');
[~,     mu_nom] = extraire_temps_valeurs(evalin('base', 'mu_fuzzy'), 'mu_fuzzy (nominal)');
[~,     Kp_nom] = extraire_temps_valeurs(evalin('base', 'Kp_fuzzy'), 'Kp_fuzzy (nominal)');
[~,     Ki_nom] = extraire_temps_valeurs(evalin('base', 'Ki_fuzzy'), 'Ki_fuzzy (nominal)');
[~,     Kd_nom] = extraire_temps_valeurs(evalin('base', 'Kd_fuzzy'), 'Kd_fuzzy (nominal)');
[t_xc1_nom, xc1_nom] = extraire_temps_valeurs(evalin('base', 'xc1_log'), 'xc1_log (nominal)');
[t_xc2_nom, xc2_nom] = extraire_temps_valeurs(evalin('base', 'xc2_log'), 'xc2_log (nominal)');
[t_xc3_nom, xc3_nom] = extraire_temps_valeurs(evalin('base', 'xc3_log'), 'xc3_log (nominal)');
delete_block([mdlNominal '/Log_xc1_tmp']);
delete_block([mdlNominal '/Log_xc2_tmp']);
delete_block([mdlNominal '/Log_xc3_tmp']);
close_system(mdlNominal, 0);
fprintf('Nominal extrait : %d points, de t=%.6g a t=%.6g.\n\n', numel(y_nom), t_nom(1), t_nom(end));

% -------------------------------------------------------------------
% ETAPE 2 : F1 -- simulation puis extraction IMMEDIATE
% -------------------------------------------------------------------
fprintf('=========================================================\n');
fprintf(' F1 (%s)\n', mdlF1);
fprintf('=========================================================\n');
if isempty(which([mdlF1 '.slx']))
    error(['Fichier "%s.slx" introuvable sur le chemin MATLAB. Lancez d''abord ' ...
           'Construction_Simulink_Fuzzy_PID_F1.m.'], mdlF1);
end
load_system(mdlF1);
% Meme ajout que pour le nominal ci-dessus, meme branchement verifie.
add_block('simulink/Sinks/To Workspace', [mdlF1 '/Log_xc2_tmp'], ...
    'VariableName', 'xc2_log', 'SaveFormat', 'Timeseries', 'Position', [400 220 460 240]);
add_block('simulink/Sinks/To Workspace', [mdlF1 '/Log_xc1_tmp'], ...
    'VariableName', 'xc1_log', 'SaveFormat', 'Timeseries', 'Position', [400 260 460 280]);
add_block('simulink/Sinks/To Workspace', [mdlF1 '/Log_xc3_tmp'], ...
    'VariableName', 'xc3_log', 'SaveFormat', 'Timeseries', 'Position', [400 300 460 320]);
add_line(mdlF1, 'Calcul_Erreur_Fuzzy/1', 'Log_xc2_tmp/1', 'autorouting', 'on');
add_line(mdlF1, 'Calcul_Erreur_Fuzzy/2', 'Log_xc1_tmp/1', 'autorouting', 'on');
add_line(mdlF1, 'Calcul_Erreur_Fuzzy/3', 'Log_xc3_tmp/1', 'autorouting', 'on');
set_param(mdlF1, 'ReturnWorkspaceOutputs', 'off');
fprintf('Simulation de %s...\n', mdlF1);
sim(mdlF1);
[t_f1,  y_f1]      = extraire_temps_valeurs(evalin('base', 'y'),             'y (Vout, F1)');
[~,     mu_f1]     = extraire_temps_valeurs(evalin('base', 'mu_fuzzy'),      'mu_fuzzy brut (F1)');
[~,     Kp_f1]     = extraire_temps_valeurs(evalin('base', 'Kp_fuzzy'),      'Kp_fuzzy (F1)');
[~,     Ki_f1]     = extraire_temps_valeurs(evalin('base', 'Ki_fuzzy'),      'Ki_fuzzy (F1)');
[~,     Kd_f1]     = extraire_temps_valeurs(evalin('base', 'Kd_fuzzy'),      'Kd_fuzzy (F1)');
[t_pert, F1_signal] = extraire_temps_valeurs(evalin('base', 'F1_signal'),     'F1_signal');
[~,     mu_cmd_f1] = extraire_temps_valeurs(evalin('base', 'mu_commande_F1'),'mu_commande_F1');
[t_xc1_f1, xc1_f1] = extraire_temps_valeurs(evalin('base', 'xc1_log'), 'xc1_log (F1)');
[t_xc2_f1, xc2_f1] = extraire_temps_valeurs(evalin('base', 'xc2_log'), 'xc2_log (F1)');
[t_xc3_f1, xc3_f1] = extraire_temps_valeurs(evalin('base', 'xc3_log'), 'xc3_log (F1)');
delete_block([mdlF1 '/Log_xc1_tmp']);
delete_block([mdlF1 '/Log_xc2_tmp']);
delete_block([mdlF1 '/Log_xc3_tmp']);
close_system(mdlF1, 0);
fprintf('F1 extrait : %d points, de t=%.6g a t=%.6g.\n\n', numel(y_f1), t_f1(1), t_f1(end));

% Masque partage, reutilise par les mesures 3 et 4 : toute la fenetre
% active de la perturbation [0.05, 0.07]s sur l'axe de temps de F1.
idxFenetreActive_f1 = (t_f1 >= 0.05) & (t_f1 <= 0.07);

% =========================================================================
% MESURE 1 : profil de F1(t) reellement simule vs definition (Lu et al.)
% =========================================================================
fprintf('=========================================================\n');
fprintf(' MESURE 1 : profil de F1(t)\n');
fprintf('=========================================================\n');
idxAvant = t_pert < 0.05 - 1e-9;
idxApres = t_pert > 0.07 + 1e-9;
idxActif = (t_pert >= 0.05) & (t_pert <= 0.07);
fprintf('Hors fenetre [0.05,0.07] : max(|F1|) avant = %.4g, max(|F1|) apres = %.4g (attendu : 0 des deux cotes)\n', ...
    max(abs(F1_signal(idxAvant))), max(abs(F1_signal(idxApres))));
fprintf('Dans la fenetre active : min=%.4f  max=%.4f  (attendu : saut a 2 en t=0.05, decroissance vers ~1.11 en t=0.07, toujours positif)\n', ...
    min(F1_signal(idxActif)), max(F1_signal(idxActif)));
[~, iDebutActif] = min(abs(t_pert - 0.05));
[~, iFinActif]   = min(abs(t_pert - 0.06999));
fprintf('Valeur juste apres t=0.05 : %.4f (attendu ~2.0000)  |  valeur juste avant t=0.07 : %.4f (attendu ~1.11)\n\n', ...
    F1_signal(iDebutActif), F1_signal(iFinActif));

% =========================================================================
% MESURE 2 : reaction de Vout et retour complet a Vref
% =========================================================================
fprintf('=========================================================\n');
fprintf(' MESURE 2 : Vout -- reaction et retour au regime etabli\n');
fprintf('=========================================================\n');
FEN_BASE   = [0.014 0.03];
FEN_REACT  = [0.05  0.055];
FEN_FINALE = [0.18  0.20];

idxBase   = (t_f1 >= FEN_BASE(1))   & (t_f1 <= FEN_BASE(2));
idxReact  = (t_f1 >= FEN_REACT(1))  & (t_f1 <= FEN_REACT(2));
idxFinale = (t_f1 >= FEN_FINALE(1)) & (t_f1 <= FEN_FINALE(2));

vout_base   = mean(y_f1(idxBase));
vout_pic    = max(y_f1(idxReact));
vout_finale = mean(y_f1(idxFinale));
ecart_finale_pct = 100 * (vout_finale - Vref) / Vref;

fprintf('Vout moyen avant perturbation [%.3f,%.3f]s : %.3f V (reference Vref=%.0f V)\n', FEN_BASE(1), FEN_BASE(2), vout_base, Vref);
fprintf('Vout pic sur [%.3f,%.3f]s (tout debut de la fenetre active)   : %.3f V\n', FEN_REACT(1), FEN_REACT(2), vout_pic);
fprintf('Vout moyen en fin de simulation [%.3f,%.3f]s                  : %.3f V (ecart a Vref : %+.3f%%)\n\n', ...
    FEN_FINALE(1), FEN_FINALE(2), vout_finale, ecart_finale_pct);
fprintf(['LECTURE : le critere retenu pour ce scenario est un retour COMPLET a Vref apres t=0.07s (pas une valeur\n' ...
    'de pic particuliere -- le papier ne fournit aucun chiffre cible pour Fuzzy-PID, voir en-tete du script de\n' ...
    'construction). Un pic superieur a Vout_base et un ecart final proche de 0%% confirment ce critere ; un ecart\n' ...
    'final non negligeable indiquerait un residu de windup a investiguer avant de conclure quoi que ce soit.\n\n']);

% =========================================================================
% MESURE 3 : e traverse-t-elle la zone NB, et Ki reste-t-elle geler apres ?
% =========================================================================
fprintf('=========================================================\n');
fprintf(' MESURE 3 : passage en zone NB (e tres negatif) et comportement de Ki\n');
fprintf('=========================================================\n');
e_f1 = (Vref - y_f1) / Vin;   % meme convention que calcul_erreur_fuzzy (ecn)
e_min_pendant = min(e_f1(idxFenetreActive_f1));
fprintf('e minimum observe sur la fenetre active [0.05,0.07]s : %.5f (negatif si Vout > Vref, comme attendu)\n', e_min_pendant);

idxApresPert = (t_f1 > 0.07) & (t_f1 <= 0.09);
idxFinaleKi  = (t_f1 >= FEN_FINALE(1)) & (t_f1 <= FEN_FINALE(2));
idxFinaleNom = (t_nom >= FEN_FINALE(1)) & (t_nom <= FEN_FINALE(2));
Ki_juste_apres = Ki_f1(find(idxApresPert, 1, 'last'));
Ki_finale_moy  = mean(Ki_f1(idxFinaleKi));
Ki_finale_nom  = mean(Ki_nom(idxFinaleNom));
fprintf('Ki juste apres la fin de la perturbation (t~0.09s) : %.4g\n', Ki_juste_apres);
fprintf('Ki moyen en regime final F1 [%.3f,%.3f]s            : %.4g\n', FEN_FINALE(1), FEN_FINALE(2), Ki_finale_moy);
fprintf('Ki moyen en regime final NOMINAL, MEME fenetre       : %.4g  (comparaison a fenetre egale -- pas la\n', Ki_finale_nom);
fprintf(['  reference de 6183 eventuellement gardee d''un run de validation a StopTime=1s : cette derniere est\n' ...
    '  mesuree a un horizon 5x plus long, sur un systeme dont Kp/Ki continuent de deriver lentement meme en\n' ...
    '  "regime etabli" (voir Test_Validation_Fuzzy_PID_Nominal.m, ETAPE 4bis/4quater) -- comparer un chiffre a\n' ...
    '  t=1s a un chiffre a t=0.2s serait comparer deux instants differents de la meme derive, pas detecter un\n' ...
    '  effet de la perturbation F1.)\n']);
fprintf(['LECTURE : si Ki_F1 reste bloque pres de zero entre 0.07s et la fin, la ligne e=NB de la table de regles\n' ...
    'affame de nouveau Ki (regression du bug deja corrige dans construction_FIS_Fuzzy_PID.m). Le chiffre a\n' ...
    'comparer est celui du NOMINAL calcule juste au-dessus, a la meme fenetre -- pas une reference d''un autre\n' ...
    'horizon de simulation.\n\n']);

fprintf('Kp_fuzzy F1 : min=%.4g  max=%.4g  final(moy. [%.3f,%.3f]s)=%.4g   |  Kp_fuzzy NOMINAL, meme fenetre : %.4g\n', ...
    min(Kp_f1), max(Kp_f1), FEN_FINALE(1), FEN_FINALE(2), mean(Kp_f1(idxFinaleKi)), mean(Kp_nom(idxFinaleNom)));
fprintf('Kd_fuzzy F1 : min=%.4g  max=%.4g  final(moy. [%.3f,%.3f]s)=%.4g   |  Kd_fuzzy NOMINAL, meme fenetre : %.4g\n\n', ...
    min(Kd_f1), max(Kd_f1), FEN_FINALE(1), FEN_FINALE(2), mean(Kd_f1(idxFinaleKi)), mean(Kd_nom(idxFinaleNom)));

% =========================================================================
% MESURE 4 : commande finale reellement appliquee -- excursion et saturation
% =========================================================================
fprintf('=========================================================\n');
fprintf(' MESURE 4 : mu_commande_F1 (signal reellement applique au PWM Generator)\n');
fprintf('=========================================================\n');
fprintf('mu_commande_F1 sur la fenetre active [0.05,0.07]s : min=%.4f  max=%.4f  (bornes physiques : [0.01, 0.99])\n', ...
    min(mu_cmd_f1(idxFenetreActive_f1)), max(mu_cmd_f1(idxFenetreActive_f1)));
% Scinde EXPRES en deux fenetres distinctes (pendant vs hors perturbation) --
% une seule statistique sur tout le run confondrait un effet propre a F1(t)
% avec un comportement de fond deja present hors perturbation. Necessaire
% ici : mu_fuzzy BRUT (mesure 5 ci-dessous) affiche une moyenne tres
% eloignee de celle du nominal hors perturbation (1.35 vs 0.51) -- il faut
% savoir si mu_commande_F1, le signal REELLEMENT applique, hors perturbation,
% reste lui aussi colle a sa borne haute de facon anormale, ou si le
% chatter interne saute simplement les deux bornes physiques comme le fait
% deja le nominal.
idxHorsPert_f1 = ~idxFenetreActive_f1;
tempsCollePendant = 100 * mean(mu_cmd_f1(idxFenetreActive_f1) >= 0.99 - 1e-6);
tempsColleHorsPert = 100 * mean(mu_cmd_f1(idxHorsPert_f1) >= 0.99 - 1e-6);
tempsColleMaxTotal = 100 * mean(mu_cmd_f1 >= 0.99 - 1e-6);
fprintf('Temps colle a 0.99 PENDANT la perturbation [0.05,0.07]s : %.2f%%\n', tempsCollePendant);
fprintf('Temps colle a 0.99 HORS perturbation (reste du run)      : %.2f%%\n', tempsColleHorsPert);
fprintf('Temps colle a 0.99 sur la totalite du run                : %.2f%%\n', tempsColleMaxTotal);
fprintf(['LECTURE : si le pourcentage HORS perturbation est deja tres eleve (proche de celui mesure sur tout le\n' ...
    'run), le collage a 0.99 n''est PAS un effet de F1(t) mais un trait de fond du montage F1 -- a rapprocher\n' ...
    'directement de la moyenne inhabituelle de mu_fuzzy brut releve a la mesure 5 (voir plus bas, ne pas\n' ...
    'conclure avant d''avoir lu les deux ensemble).\n\n']);

% =========================================================================
% MESURE 5 : comparaison du chatter de mu (nominal vs F1), HORS perturbation
% =========================================================================
fprintf('=========================================================\n');
fprintf(' MESURE 5 : chatter de mu hors perturbation -- nominal vs F1\n');
fprintf('=========================================================\n');
SEUIL_MEDIAN = 0.5;
fenetres = { ...
    'Nominal, hors perturbation [0.014, 0.03]s', t_nom, mu_nom, [0.014 0.03]; ...
    'F1, hors perturbation [0.014, 0.03]s',      t_f1,  mu_f1,  [0.014 0.03]; ...
    'F1, apres la perturbation [0.12, 0.14]s',   t_f1,  mu_f1,  [0.12  0.14]  ...
};
for i = 1:size(fenetres, 1)
    label = fenetres{i,1}; t = fenetres{i,2}; y = fenetres{i,3}; bornes = fenetres{i,4};
    idx = (t >= bornes(1)) & (t <= bornes(2));
    if ~any(idx)
        fprintf('[%s] : AUCUN point trouve dans cette fenetre.\n\n', label);
        continue;
    end
    yFen = y(idx); tFen = t(idx);
    signeCentre = sign(yFen - SEUIL_MEDIAN); signeCentre(signeCentre == 0) = 1;
    nbFranchissements = sum(abs(diff(signeCentre)) > 0);
    freqHz = (nbFranchissements / 2) / (tFen(end) - tFen(1));
    fprintf('[%s]\n  min=%.4f  max=%.4f  moyenne=%.4f  freq. oscillation estimee ~%.0f Hz\n\n', ...
        label, min(yFen), max(yFen), mean(yFen), freqHz);
    if i == 1
        moyenneNominale = mean(yFen);
    end
end
idxF1HorsPertBase = (t_f1 >= 0.014) & (t_f1 <= 0.03);
moyenneF1HorsPert = mean(mu_f1(idxF1HorsPertBase));
ecartMoyenne = moyenneF1HorsPert - moyenneNominale;
fprintf('Ecart de moyenne (F1 hors perturbation moins nominal) : %+.4f\n', ecartMoyenne);
if abs(ecartMoyenne) > 0.1
    fprintf(['ATTENTION -- CET ECART N''EST PAS NEGLIGEABLE : contrairement a F2 (mu_fuzzy quasiment identique au\n' ...
        'nominal hors perturbation), mu_fuzzy BRUT de F1 se stabilise a une moyenne tres differente de 0.5 des que\n' ...
        'les bornes internes sont elargies a [-0.8, 3.5]. Hypothese la plus probable (a confirmer, PAS a supposer\n' ...
        'acquise) : sans terme de fuite (section 5 du document de theorie), l''integrateur de mu n''a plus aucune\n' ...
        'force de rappel vers 0.5 une fois ses bornes internes elargies -- il derive alors vers un point ou SEULE\n' ...
        'la moyenne du signal SATURE (mu_commande_F1, pas mu_fuzzy brut) doit valoir ~0.5 pour reguler Vout, ce qui\n' ...
        'laisse la statistique du signal brut libre de se stabiliser ailleurs. Vout etant correctement regule hors\n' ...
        'perturbation (mesure 2), la boucle fonctionne malgre cet ecart -- mais le pourcentage de temps colle a\n' ...
        '0.99 HORS perturbation (juste au-dessus) doit etre lu a la lumiere de ce resultat avant de conclure que le\n' ...
        'montage F1 se comporte "comme le nominal en dehors de la fenetre active". Si ce pourcentage hors\n' ...
        'perturbation est lui-meme eleve, ceci merite d''etre documente comme une limite reelle du montage F1 dans\n' ...
        'le memoire, pas passe sous silence.\n']);
else
    fprintf('Ecart negligeable : le comportement de mu_fuzzy brut hors perturbation reste comparable au nominal.\n');
end

% =========================================================================
% MESURE 6 : poids reel de Kp*xc1/Ki*xc2/Kd*xc3 dans dmu, nominal ET F1, a
% fenetre egale [0.18,0.20]s -- meme formule (majorant) que l'ETAPE 4sexies
% de Test_Validation_Fuzzy_PID_Nominal.m, qui ne l'avait verifiee QU'une
% fois, en regime nominal, a [0.98,1.00]s. Rien ne garantissait que la
% meme hierarchie (Ki dominant, Kp/Kd negligeables) tienne a un autre
% instant ou sous F1, dont l'erreur en fenetre active est bien plus grande
% qu'en regime etabli nominal -- a verifier, pas a supposer.
% =========================================================================
fprintf('=========================================================\n');
fprintf(' MESURE 6 : poids de Kp*xc1/Ki*xc2/Kd*xc3 dans dmu -- nominal et F1, meme fenetre [0.18,0.20]s\n');
fprintf('=========================================================\n');
idxXc1Nom = (t_xc1_nom >= FEN_FINALE(1)) & (t_xc1_nom <= FEN_FINALE(2));
idxXc2Nom = (t_xc2_nom >= FEN_FINALE(1)) & (t_xc2_nom <= FEN_FINALE(2));
idxXc3Nom = (t_xc3_nom >= FEN_FINALE(1)) & (t_xc3_nom <= FEN_FINALE(2));
idxXc1F1  = (t_xc1_f1  >= FEN_FINALE(1)) & (t_xc1_f1  <= FEN_FINALE(2));
idxXc2F1  = (t_xc2_f1  >= FEN_FINALE(1)) & (t_xc2_f1  <= FEN_FINALE(2));
idxXc3F1  = (t_xc3_f1  >= FEN_FINALE(1)) & (t_xc3_f1  <= FEN_FINALE(2));

decompositions = { ...
    'NOMINAL', mean(Kp_nom(idxFinaleNom)), Ki_finale_nom, mean(Kd_nom(idxFinaleNom)), ...
        max(abs(xc1_nom(idxXc1Nom))), max(abs(xc2_nom(idxXc2Nom))), max(abs(xc3_nom(idxXc3Nom))); ...
    'F1',      mean(Kp_f1(idxFinaleKi)),  Ki_finale_moy, mean(Kd_f1(idxFinaleKi)), ...
        max(abs(xc1_f1(idxXc1F1))),  max(abs(xc2_f1(idxXc2F1))),  max(abs(xc3_f1(idxXc3F1)))  ...
};
for i = 1:size(decompositions, 1)
    label = decompositions{i,1};
    kp_moy = decompositions{i,2}; ki_moy = decompositions{i,3}; kd_moy = decompositions{i,4};
    xc1_absmax = decompositions{i,5}; xc2_absmax = decompositions{i,6}; xc3_absmax = decompositions{i,7};
    contrib_kp = abs(kp_moy * xc1_absmax);
    contrib_ki = abs(ki_moy * xc2_absmax);
    contrib_kd = abs(kd_moy * xc3_absmax);
    contrib_totale = contrib_kp + contrib_ki + contrib_kd;
    fprintf('[%s]\n', label);
    fprintf('  Kp1*xc1 (majorant) : %.4e  (%5.2f%% du total)\n', contrib_kp, 100*contrib_kp/contrib_totale);
    fprintf('  Ki1*xc2 (majorant) : %.4e  (%5.2f%% du total)\n', contrib_ki, 100*contrib_ki/contrib_totale);
    fprintf('  Kd1*xc3 (majorant) : %.4e  (%5.2f%% du total)\n', contrib_kd, 100*contrib_kd/contrib_totale);
    if contrib_kd / contrib_totale < 0.01
        fprintf('  OK : contribution de Kd < 1%% du total, seuil de negligeabilite retenu au memoire respecte.\n\n');
    else
        fprintf(['  ATTENTION : contribution de Kd >= 1%% du total pour ce scenario -- le seuil de negligeabilite\n' ...
            '  retenu (verifie uniquement en regime nominal a [0.98,1.00]s dans Test_Validation_Fuzzy_PID_\n' ...
            '  Nominal.m) ne tient PAS ici sans reserve ; a documenter explicitement avant toute affirmation\n' ...
            '  generale sur la negligeabilite de Kd au memoire.\n\n']);
    end
end
fprintf(['LECTURE : si Ki*xc2 domine et Kp*xc1/Kd*xc3 restent sous 1%% dans les DEUX lignes ci-dessus, la\n' ...
    'hierarchie de contribution decrite a la section 6.2 (a partir du seul regime nominal) generalise bien a F1\n' ...
    '; si Kd (ou Kp) depasse 1%% pour F1 specifiquement, la section 6.2 doit etre nuancee comme scenario-\n' ...
    'dependante, exactement comme cela a deja ete fait pour le sens de derive de Kd a la section 6.3.\n']);

function [t, vals] = extraire_temps_valeurs(donnee, nomAffiche)
% Identique a la fonction du meme nom dans Test_Validation_Fuzzy_PID_
% Nominal.m et Analyse_mu_F2_vs_Nominal.m -- extraction robuste quel que
% soit le SaveFormat reel du bloc "To Workspace".
    if isa(donnee, 'timeseries')
        t = donnee.Time;
        vals = squeeze(donnee.Data);
    elseif isstruct(donnee) && isfield(donnee, 'time') && isfield(donnee, 'signals')
        t = donnee.time;
        vals = squeeze(donnee.signals.values);
    elseif isnumeric(donnee)
        vals = donnee;
        if evalin('base', 'exist(''tout'', ''var'')')
            t = evalin('base', 'tout');
        else
            error(['"%s" est un tableau numerique brut (SaveFormat=Array) mais aucune variable ' ...
                   '"tout" n''a ete trouvee pour lui associer un axe de temps.'], nomAffiche);
        end
    else
        error('Format de "%s" non reconnu (classe : %s) -- extraction impossible sans inspection manuelle.', ...
            nomAffiche, class(donnee));
    end
    vals = vals(:);
    t = t(:);
end
