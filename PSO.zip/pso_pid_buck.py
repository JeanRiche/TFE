# %% [markdown]
# # Reglage du PID par Particle Swarm Optimization (PSO-PID) pour le convertisseur Buck
#
# ## Objectif
# Ce script cherche, par optimisation par essaim de particules (PSO), un jeu de gains
# PID fixes (Kp, Ki, Kd) meilleur que le reglage obtenu par la methode de
# Ziegler-Nichols, pour le meme convertisseur Buck que celui utilise dans le reste
# du TFE (ELM-PID, PINN-PID, Fuzzy-PID). Contrairement a ces trois autres methodes,
# qui adaptent leurs gains en cours de fonctionnement, le PSO-PID est une methode de
# reglage HORS LIGNE : la recherche a lieu une seule fois, avant la mise en service,
# et produit un triplet (Kp, Ki, Kd) unique qui reste fixe ensuite, exactement comme
# un PID classique, mais mieux regle. C'est ce que le plan du TFE appelle
# « optimisation globale », par opposition a l'« ajustement dynamique » des methodes
# adaptatives.
#
# ## Entrees
# - Les parametres physiques du convertisseur Buck (R, L, C, Vin, Vref, Te), identiques
#   partout ailleurs dans le TFE.
# - Les gains Ziegler-Nichols deja identifies sur PID_Classique_Control.slx :
#   P = 0,375459 ; I = 1104,38 ; D = 3,1911e-05 (convention MATLAB / PID Tuner).
#
# ## Sorties
# - Un triplet de gains (Kp, Ki, Kd) optimise, dans la meme convention MATLAB que les
#   gains Ziegler-Nichols (directement injectable dans le meme bloc PID sous Simulink).
# - Les courbes de reponse indicielle nominale (Ziegler-Nichols contre PSO-PID) et la
#   courbe de convergence de l'algorithme PSO.
# - Un fichier de resultats (gains_pso_pid.json) pour reutilisation dans le script
#   d'integration Simulink.
#
# ## Etapes
# 1. Discretiser le modele du convertisseur (transformation bilineaire de Tustin).
# 2. Ecrire la loi PID incrementale (forme de Lu et al., deja utilisee pour ELM-PID
#    et PINN-PID) et la fonction qui simule la boucle fermee en temps discret.
# 3. Definir le cout a minimiser : ITAE (Integral of Time-weighted Absolute Error) sur
#    la reponse indicielle nominale, avec une legere regularisation expliquee plus bas.
# 4. Implementer l'algorithme PSO « a la main » (aucune bibliotheque externe : plus
#    facile a auditer et a expliquer ligne par ligne).
# 5. Lancer la recherche, comparer au reglage Ziegler-Nichols, tracer les resultats.
#
# ## Remarque methodologique importante (a lire avant d'utiliser les resultats)
# Une premiere recherche PSO sans regularisation a revele que le cout ITAE devient
# quasiment plat des que les gains sont assez grands pour saturer la commande (mu a
# 0,99) pendant presque toute la phase de montee : une multitude de triplets tres
# differents (Ki entre environ 2000 et 600 000 selon la graine aleatoire) donnent alors
# un ITAE quasi identique a mieux que 0,01 % pres. Rapporter un seul de ces triplets
# comme « le » reglage optimal aurait ete trompeur, puisque sa valeur precise depend
# essentiellement du hasard de l'initialisation, pas d'un veritable optimum isole.
# Ce script ajoute donc un terme de regularisation qui, a ITAE quasi egal, privilegie
# le triplet le plus proche du reglage Ziegler-Nichols. Le resultat devient reproductible
# d'une graine aleatoire a l'autre (verifie sur 4 graines), pour un cout ITAE a peine
# 0,45 % au-dessus du plancher theorique atteint sans regularisation. Ce compromis est
# documente ici explicitement, pas impose comme une valeur unique et indiscutable
# (meme logique que les bornes MU_MIN/MU_MAX du ELM-PID).

# %%
import numpy as np
import matplotlib.pyplot as plt
import json

# On fixe la graine du generateur aleatoire pour que ce script produise exactement les
# memes gains a chaque execution (reproductibilite scientifique : un resultat qui
# change a chaque lancement ne peut pas etre mis dans un memoire).
RNG_SEED = 42
rng = np.random.default_rng(RNG_SEED)

# %% [markdown]
# ## Section 1 : parametres du systeme
#
# Ces valeurs sont reprises telles quelles du reste du TFE (fichier de suivi du
# projet) : R, L, C, Vin, Vref sont les parametres physiques du convertisseur Buck ;
# Te est la periode d'echantillonnage a laquelle la loi PID incrementale s'execute
# (5 microsecondes). ATTENTION : L = 50 mH est la valeur retenue pour ce TFE, PAS la
# valeur de 50 microH du papier de reference (Yang Lu et al., 2021) ; ce choix a deja
# ete acte ailleurs dans le projet et n'est pas remis en question ici.

# %%
R = 5.0          # Ohms, resistance de charge
L = 50e-3        # Henry, inductance (50 mH, valeur projet)
Cap = 40e-6      # Farad, capacite de sortie (renomme Cap pour ne pas ecraser la
                 # variable C0 utilisee plus loin pour la discretisation)
Vin = 200.0      # Volts, tension d'entree
Vref = 100.0     # Volts, tension de sortie desiree (consigne, echelon applique a t=0)
Te = 5e-6        # secondes, periode d'echantillonnage de la loi PID incrementale

# Bornes physiques du rapport cyclique (regle de construction n 11/14 du projet :
# une saturation physique doit toujours etre appliquee en sortie du controleur).
MU_MIN, MU_MAX = 0.01, 0.99

# Gains Ziegler-Nichols deja identifies sur PID_Classique_Control.slx, dans la
# convention native de MATLAB (bloc PID parallele : C(s) = P + I/s + D.s).
KP_ZN, KI_ZN, KD_ZN = 0.375459, 1104.38, 3.1911e-05

# %% [markdown]
# ## Section 2 : discretisation bilineaire (Tustin) du convertisseur Buck
#
# La fonction de transfert continue du convertisseur, etablie par la methode de l'etat
# moyen (memes equations que dans Yang Lu et al., 2021, eq. 4), est :
#
#     Gvd(s) = Vin / (A.s^2 + B.s + 1),   avec A = L.C,  B = L/R
#
# Pour simuler ce systeme en temps discret a la meme cadence que le controleur (Te),
# on applique la transformation bilineaire (Tustin) :
#
#     s = (2/Te) * (1 - z^-1) / (1 + z^-1)
#
# En substituant cette expression dans Gvd(s) et en multipliant tout par (1+z^-1)^2
# pour eliminer les denominateurs (developpement algebrique complet dans le papier de
# reference, eq. 5 a 8), on obtient une equation aux differences de la forme :
#
#     y_k + a1.y_{k-1} + a2.y_{k-2} = b1.d_k + b2.d_{k-1} + b3.d_{k-2}
#
# ou d_k est le rapport cyclique applique (note "mu" plus loin) et y_k la tension de
# sortie. Le calcul ci-dessous refait cette derivation depuis zero avec les parametres
# du projet : NE PAS reprendre telles quelles les valeurs numeriques d'a1/a2 publiees
# dans le papier, celui-ci utilise L = 50 microH (1000 fois plus petit que la valeur
# du projet) et une transcription anterieure du PDF avait deja ete identifiee comme
# incoherente dimensionnellement pour a2. Le calcul est fait numeriquement ci-dessous
# puis verifie par un critere de stabilite independant (pole continu), ce qui a permis
# de detecter et corriger une erreur de calcul a la main lors de la preparation de ce
# script (8.A confondu avec 4.A) : preuve, s'il en fallait une, qu'un calcul verifie
# par le code vaut mieux qu'un calcul de tete.

# %%
A_coef = L * Cap          # L.C, unite : s^2
B_coef = L / R            # L/R, unite : s

C0 = 4 * A_coef + 2 * B_coef * Te + Te**2
C1 = 2 * Te**2 - 8 * A_coef
C2 = 4 * A_coef - 2 * B_coef * Te + Te**2

a1 = C1 / C0
a2 = C2 / C0
b1 = Vin * Te**2 / C0
b2 = 2 * Vin * Te**2 / C0
b3 = Vin * Te**2 / C0

# Verification de stabilite : les racines de z^2 + a1.z + a2 = 0 doivent etre de
# module strictement inferieur a 1 (systeme stable en boucle ouverte).
poles_discrets = np.roots([1.0, a1, a2])
poles_continus = np.roots([A_coef, B_coef, 1.0])

print("=== Verification du modele discretise ===")
print(f"a1 = {a1:.6f}   a2 = {a2:.6f}")
print(f"b1 = {b1:.6e}   b2 = {b2:.6e}   b3 = {b3:.6e}")
print(f"poles discrets : {poles_discrets}  (module : {np.abs(poles_discrets)})")
print(f"poles continus (rad/s) : {poles_continus}  "
      f"(constantes de temps : {-1/poles_continus} s)")
assert np.all(np.abs(poles_discrets) < 1.0), "Modele instable : verifier A, B, Te."
print("Modele stable, coherent avec les deux poles reels attendus (systeme "
      "surammorti par construction, L = 50 mH).")

# %% [markdown]
# ## Section 3 : conversion des gains PID (convention MATLAB -> forme incrementale)
#
# Le bloc PID de MATLAB (et donc les gains issus de Ziegler-Nichols via PID Tuner)
# utilise la forme parallele continue C(s) = P + I/s + D.s. La loi PID utilisee dans
# tout ce TFE (celle de Lu et al., deja en place pour ELM-PID et PINN-PID) est en
# revanche une forme INCREMENTALE discrete :
#
#     e_k       = Vref - y_k
#     xc1_k     = e_k - e_{k-1}
#     xc2_k     = e_k
#     xc3_k     = e_k - 2.e_{k-1} + e_{k-2}
#     d(mu)_k   = Kp_incr.xc1_k + Ki_incr.xc2_k + Kd_incr.xc3_k
#     mu_k      = mu_{k-1} + d(mu)_k
#
# La conversion standard entre les deux conventions (discretisation de l'integrateur
# et du derivateur par difference arriere) est :
#
#     Kp_incr = P
#     Ki_incr = I * Te
#     Kd_incr = D / Te
#
# Ce point n'est pas cosmetique : une verification numerique faite pendant la
# preparation de ce script a montre qu'utiliser I = 1104,38 directement comme Ki_incr
# (sans le multiplier par Te) sature immediatement et durablement la commande a 0,99,
# ce qui masque completement l'effet du reglage et rend toute comparaison PSO
# inutilisable. La fonction ci-dessous fait cette conversion une fois pour toutes.

# %%
def gains_natifs_vers_incrementaux(Kp_natif, Ki_natif, Kd_natif):
    """Convertit des gains PID au format MATLAB (P, I, D) vers la forme incrementale
    (Kp_incr, Ki_incr, Kd_incr) utilisee par la loi de commande de ce TFE."""
    return Kp_natif, Ki_natif * Te, Kd_natif / Te

# %% [markdown]
# ## Section 4 : simulation de la boucle fermee
#
# Point de causalite important, explicite ici pour eviter toute ambiguite : a l'instant
# k, le controleur mesure y_k (deja connu) et calcule mu_k a partir de cette mesure.
# Ce mu_k ne peut pas modifier y_k lui-meme (ce serait une boucle algebrique, physique-
# ment impossible : un regulateur ne peut pas agir sur la sortie qu'il vient de
# mesurer au meme instant). Il modifie seulement la sortie au pas SUIVANT, y_{k+1}.
# C'est exactement ainsi que fonctionne un regulateur numerique reel (mesure, calcul,
# actionnement, attente d'un pas d'echantillonnage, nouvelle mesure), et c'est aussi
# la structure qu'impose un bloc MATLAB Function avec maintien d'ordre zero sous
# Simulink (regle de construction n 2 du projet).

# %%
def simuler_boucle_fermee(Kp_incr, Ki_incr, Kd_incr, n_pas, mu_min=MU_MIN, mu_max=MU_MAX):
    """Simule la reponse indicielle nominale (echelon de consigne a t=0, sans
    perturbation) du convertisseur Buck en boucle fermee avec un PID incremental a
    gains fixes.

    Parametres
    ----------
    Kp_incr, Ki_incr, Kd_incr : gains PID deja dans la forme incrementale (voir
        section 3).
    n_pas : nombre de pas de simulation (duree totale = n_pas * Te).
    mu_min, mu_max : bornes de saturation du rapport cyclique.

    Renvoie
    -------
    y   : tableau numpy de la tension de sortie a chaque pas.
    mu  : tableau numpy du rapport cyclique applique a chaque pas.
    """
    y = np.zeros(n_pas + 1)   # y[0] = 0 V : le convertisseur part au repos
    mu = np.zeros(n_pas)
    mu_prec1 = mu_prec2 = 0.0   # mu_{k-1}, mu_{k-2}, initialement nuls (commande
                                 # nulle avant la mise en route)
    e_prec1 = e_prec2 = 0.0     # e_{k-1}, e_{k-2}, initialement nuls (on suppose que
                                 # la consigne valait deja Vref avant t=0, hypothese de
                                 # depart classique pour une reponse indicielle)

    for k in range(n_pas):
        y_k = y[k]
        e_k = Vref - y_k

        # Loi PID incrementale (forme de Lu et al.)
        xc1 = e_k - e_prec1
        xc2 = e_k
        xc3 = e_k - 2 * e_prec1 + e_prec2
        delta_mu = Kp_incr * xc1 + Ki_incr * xc2 + Kd_incr * xc3

        mu_k = mu_prec1 + delta_mu
        mu_k = min(max(mu_k, mu_min), mu_max)   # saturation physique du rapport cyclique

        # Le modele du convertisseur ne repond qu'au pas suivant (cf. note de causalite
        # ci-dessus) : y_{k+1} depend de mu_k, mu_{k-1}, mu_{k-2} et de y_k, y_{k-1}.
        y_km1 = y[k - 1] if k >= 1 else 0.0
        y[k + 1] = -a1 * y_k - a2 * y_km1 + b1 * mu_k + b2 * mu_prec1 + b3 * mu_prec2

        mu[k] = mu_k
        mu_prec2, mu_prec1 = mu_prec1, mu_k
        e_prec2, e_prec1 = e_prec1, e_k

    return y[:-1], mu

# Duree de simulation : 40 ms (8000 pas a Te = 5 microsecondes). La constante de temps
# dominante du systeme est d'environ 9,8 ms (voir poles continus ci-dessus) ; 40 ms
# laisse une marge confortable pour que la reponse se stabilise meme avec des gains
# candidats moins bien regles que Ziegler-Nichols pendant la recherche PSO.
N_PAS = 8000

# %% [markdown]
# ## Section 5 : fonction de cout (ITAE + regularisation)
#
# Le critere principal est l'ITAE (Integral of Time-weighted Absolute Error), qui
# penalise davantage les erreurs qui persistent longtemps que les erreurs initiales
# rapidement corrigees ; c'est un des criteres explicitement prevus dans le plan de
# l'article 2 du TFE (avec IAE et ISE). Un cout tres eleve (1e12) est renvoye si la
# simulation diverge (valeurs non finies ou depassement grossier), pour que le PSO
# ecarte naturellement les jeux de gains instables sans planter.
#
# Le terme de regularisation (explique dans la remarque methodologique en tete de
# fichier) ajoute une penalite tres faible sur l'ecart, en echelle logarithmique, entre
# les gains candidats et les gains Ziegler-Nichols. Le coefficient LAMBDA_REG est
# choisi pour rester negligeable partout ou l'ITAE distingue reellement les reglages,
# et n'intervenir que pour departager les triplets qui donnent un ITAE quasi identique
# (le "plateau" cause par la saturation de la commande, documente plus haut).

# %%
LAMBDA_REG = 1e-6
log_centre_zn = np.log10([KP_ZN, KI_ZN, KD_ZN])

def cout_itae(log_gains_natifs):
    """Cout total (ITAE + regularisation) pour un triplet de gains natifs exprimes en
    log10 (log_gains_natifs = [log10(Kp), log10(Ki), log10(Kd)])."""
    Kp_n, Ki_n, Kd_n = 10 ** log_gains_natifs
    Kp_i, Ki_i, Kd_i = gains_natifs_vers_incrementaux(Kp_n, Ki_n, Kd_n)
    y, mu = simuler_boucle_fermee(Kp_i, Ki_i, Kd_i, N_PAS)

    if not np.all(np.isfinite(y)) or np.max(np.abs(y)) > 1e4:
        return 1e12   # penalite forte : reglage instable, a rejeter

    erreur = Vref - y
    t = np.arange(len(erreur)) * Te
    itae = np.sum(t * np.abs(erreur)) * Te

    regularisation = LAMBDA_REG * np.sum((log_gains_natifs - log_centre_zn) ** 2)
    return itae + regularisation

# %% [markdown]
# ## Section 6 : algorithme PSO (implementation directe, sans bibliotheque externe)
#
# Principe de l'algorithme (Kennedy & Eberhart) : un essaim de particules explore
# l'espace des gains (Kp, Ki, Kd, en echelle log10 pour pouvoir couvrir plusieurs
# ordres de grandeur, indispensable pour Kd qui est de l'ordre de 10^-5). Chaque
# particule garde en memoire sa meilleure position personnelle (pbest) ; l'essaim
# entier partage la meilleure position trouvee collectivement (gbest). A chaque
# iteration, la vitesse de chaque particule est mise a jour en combinant trois
# tendances : continuer sur sa lancee (inertie w), revenir vers son propre meilleur
# souvenir (terme cognitif, poids c1), et se rapprocher du meilleur de l'essaim
# (terme social, poids c2). Le poids d'inertie decroit lineairement au fil des
# iterations (0,9 -> 0,4), ce qui favorise une exploration large au debut puis un
# raffinement local vers la fin, pratique standard pour ce type d'algorithme.
#
# Espace de recherche : +/- 2 decades (facteur 100) autour de chaque gain
# Ziegler-Nichols. Ce choix a ete valide avant l'implementation ; un test de controle
# avec des bornes elargies a +/- 3 decades a confirme qu'aller plus loin n'apporte
# plus d'amelioration mesurable de l'ITAE (moins de 0,002 % de gain supplementaire),
# ce qui montre que la fenetre +/- 2 decades capture deja la quasi-totalite du
# potentiel d'amelioration.

# %%
def executer_pso(n_particules=40, n_iterations=150, demi_largeur_decades=2.0,
                  w_debut=0.9, w_fin=0.4, c1=1.5, c2=1.5, graine=RNG_SEED):
    """Recherche par essaim de particules du triplet (Kp, Ki, Kd) natif minimisant
    cout_itae. Renvoie le meilleur triplet trouve, son cout, et l'historique de
    convergence (meilleur cout global a chaque iteration, pour le graphique)."""
    generateur = np.random.default_rng(graine)

    bornes_bas = log_centre_zn - demi_largeur_decades
    bornes_haut = log_centre_zn + demi_largeur_decades

    # Initialisation : positions tirees uniformement dans les bornes, vitesses
    # initiales petites (10 % de la largeur de recherche) pour eviter que les
    # particules ne sortent immediatement de l'espace de recherche.
    position = generateur.uniform(bornes_bas, bornes_haut, size=(n_particules, 3))
    largeur = bornes_haut - bornes_bas
    vitesse = generateur.uniform(-1, 1, size=(n_particules, 3)) * largeur * 0.1
    vitesse_max = largeur * 0.2   # bridage de vitesse : evite les sauts trop brusques
                                   # qui feraient sortir une particule de la zone utile

    meilleure_position_perso = position.copy()
    meilleur_cout_perso = np.array([cout_itae(p) for p in position])

    indice_meilleur = np.argmin(meilleur_cout_perso)
    meilleure_position_globale = meilleure_position_perso[indice_meilleur].copy()
    meilleur_cout_global = meilleur_cout_perso[indice_meilleur]

    historique_convergence = [meilleur_cout_global]

    for iteration in range(n_iterations):
        # Poids d'inertie decroissant lineairement de w_debut a w_fin
        w = w_debut - (w_debut - w_fin) * iteration / (n_iterations - 1)

        r1 = generateur.uniform(size=(n_particules, 3))
        r2 = generateur.uniform(size=(n_particules, 3))

        vitesse = (w * vitesse
                   + c1 * r1 * (meilleure_position_perso - position)
                   + c2 * r2 * (meilleure_position_globale - position))
        vitesse = np.clip(vitesse, -vitesse_max, vitesse_max)

        position = np.clip(position + vitesse, bornes_bas, bornes_haut)

        cout_courant = np.array([cout_itae(p) for p in position])

        ameliorees = cout_courant < meilleur_cout_perso
        meilleure_position_perso[ameliorees] = position[ameliorees]
        meilleur_cout_perso[ameliorees] = cout_courant[ameliorees]

        if meilleur_cout_perso.min() < meilleur_cout_global:
            indice_meilleur = np.argmin(meilleur_cout_perso)
            meilleur_cout_global = meilleur_cout_perso[indice_meilleur]
            meilleure_position_globale = meilleure_position_perso[indice_meilleur].copy()

        historique_convergence.append(meilleur_cout_global)

        if iteration % 20 == 0 or iteration == n_iterations - 1:
            gains_courants = 10 ** meilleure_position_globale
            print(f"iteration {iteration:3d}  meilleur cout = {meilleur_cout_global:.8e}"
                  f"  Kp={gains_courants[0]:.5f}  Ki={gains_courants[1]:.3f}"
                  f"  Kd={gains_courants[2]:.4e}")

    gains_optimaux = 10 ** meilleure_position_globale
    return gains_optimaux, meilleur_cout_global, historique_convergence

# %% [markdown]
# ## Section 7 : lancement de la recherche

# %%
print("=== Recherche PSO (40 particules, 150 iterations) ===")
(Kp_opt, Ki_opt, Kd_opt), cout_opt, historique = executer_pso()
print("\n=== Resultat ===")
print(f"Kp = {Kp_opt:.6f}")
print(f"Ki = {Ki_opt:.4f}")
print(f"Kd = {Kd_opt:.6e}")
print(f"Cout ITAE+regularisation = {cout_opt:.6e}")

# %% [markdown]
# ## Section 8 : comparaison Ziegler-Nichols contre PSO-PID
#
# On calcule ici, pour les deux reglages, les indicateurs habituels du TFE :
# depassement (overshoot), temps de montee 10-90 %, temps d'etablissement a 2 %, et
# ITAE. On trace ensuite les deux courbes de reponse indicielle superposees, ainsi que
# la courbe de convergence du PSO.

# %%
def indicateurs_performance(nom, Kp_natif, Ki_natif, Kd_natif):
    Kp_i, Ki_i, Kd_i = gains_natifs_vers_incrementaux(Kp_natif, Ki_natif, Kd_natif)
    y, mu = simuler_boucle_fermee(Kp_i, Ki_i, Kd_i, N_PAS)
    t_ms = np.arange(N_PAS) * Te * 1e3

    depassement = (np.max(y) - Vref) / Vref * 100
    i10 = np.argmax(y >= 0.1 * Vref)
    i90 = np.argmax(y >= 0.9 * Vref)
    temps_montee = (i90 - i10) * Te * 1e3

    bande_2pct = 0.02 * Vref
    hors_bande = np.where(np.abs(y - Vref) > bande_2pct)[0]
    temps_etablissement = (hors_bande[-1] + 1) * Te * 1e3 if len(hors_bande) else 0.0

    itae = np.sum(np.arange(N_PAS) * Te * np.abs(Vref - y)) * Te

    print(f"{nom:20s}  depassement={depassement:6.3f}%   "
          f"temps de montee (10-90%)={temps_montee:6.3f} ms   "
          f"temps d'etablissement (2%)={temps_etablissement:6.3f} ms   "
          f"ITAE={itae:.6e}")
    return t_ms, y, mu

# %%
t_zn, y_zn, mu_zn = indicateurs_performance("Ziegler-Nichols", KP_ZN, KI_ZN, KD_ZN)
t_pso, y_pso, mu_pso = indicateurs_performance("PSO-PID", Kp_opt, Ki_opt, Kd_opt)

# La difference entre les deux reglages est trop fine pour se voir sur l'echelle
# complete de la reponse (quelques dixiemes de volt sur un depassement de moins de
# 1 %) : un deuxieme panneau zoome sur la zone du pic est indispensable pour ne pas
# donner une fausse impression d'identite totale entre les deux courbes.

# %%
fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(16, 4.5))

ax1.plot(t_zn, y_zn, label="PID Ziegler-Nichols", color="#1D5FA6", linewidth=1.6)
ax1.plot(t_pso, y_pso, label="PSO-PID", color="#14B8A6", linewidth=1.6)
ax1.axhline(Vref, color="#0A2342", linestyle="--", linewidth=0.8, label="Vref = 100 V")
ax1.set_xlabel("temps (ms)")
ax1.set_ylabel("tension de sortie (V)")
ax1.set_title("Reponse indicielle nominale")
ax1.set_xlim(0, 20)
ax1.legend()
ax1.grid(alpha=0.3)

ax2.plot(t_zn, y_zn, label="PID Ziegler-Nichols", color="#1D5FA6", linewidth=1.8)
ax2.plot(t_pso, y_pso, label="PSO-PID", color="#14B8A6", linewidth=1.8)
ax2.axhline(Vref, color="#0A2342", linestyle="--", linewidth=0.8)
ax2.set_xlabel("temps (ms)")
ax2.set_ylabel("tension de sortie (V)")
ax2.set_title("Zoom sur le pic (le seul ecart visible)")
ax2.set_xlim(5.5, 9)
ax2.set_ylim(99.5, 101.0)
ax2.legend()
ax2.grid(alpha=0.3)

ax3.plot(range(len(historique)), historique, color="#0A2342", linewidth=1.6)
ax3.set_xlabel("iteration PSO")
ax3.set_ylabel("cout (ITAE + regularisation)")
ax3.set_title("Convergence de la recherche PSO")
ax3.grid(alpha=0.3)

plt.tight_layout()
plt.savefig("comparaison_zn_pso.png", dpi=150)
plt.show()
print("Figure enregistree : comparaison_zn_pso.png")

# %% [markdown]
# ## Section 9 : sauvegarde des resultats
#
# Les gains optimaux sont enregistres dans un fichier JSON, dans la convention native
# MATLAB (directement utilisable dans le meme bloc PID que Ziegler-Nichols sous
# Simulink), pour reutilisation par le prochain script d'integration.

# %%
resultats = {
    "gains_ziegler_nichols_natifs": {"Kp": KP_ZN, "Ki": KI_ZN, "Kd": KD_ZN},
    "gains_pso_pid_natifs": {"Kp": float(Kp_opt), "Ki": float(Ki_opt), "Kd": float(Kd_opt)},
    "parametres_systeme": {"R": R, "L": L, "C": Cap, "Vin": Vin, "Vref": Vref, "Te": Te},
    "parametres_pso": {
        "n_particules": 40, "n_iterations": 150,
        "demi_largeur_decades": 2.0, "lambda_regularisation": LAMBDA_REG,
        "graine_aleatoire": RNG_SEED,
    },
    "cout_itae_optimal": float(cout_opt),
}
with open("gains_pso_pid.json", "w", encoding="utf-8") as f:
    json.dump(resultats, f, indent=2, ensure_ascii=False)
print("Resultats enregistres dans gains_pso_pid.json")

# %% [markdown]
# ## Ce qui reste a faire (a ne pas considerer comme acquis avant validation Simulink)
#
# Conformement a la discipline de validation deja en place pour les autres methodes du
# TFE, ce resultat Python seul n'est PAS suffisant pour etre retenu dans le memoire :
# 1. Integrer ces gains dans une copie de PID_Classique_Control.slx (meme structure de
#    bloc PID, seuls Kp/Ki/Kd changent) et comparer la capture Simulink reelle a la
#    courbe Python ci-dessus, curve-par-curve et pas seulement sur le pic.
# 2. Tester ensuite ces memes gains fixes, sans nouvelle optimisation, sous les
#    scenarios de perturbation F1 (commande) et F2 (charge), exactement comme le PID
#    classique et les methodes adaptatives, pour alimenter le chapitre de comparaison.
# 3. Documenter dans le memoire le phenomene de plateau degenere observe en section 6,
#    et le choix de regularisation qui en decoule : c'est un resultat scientifique en
#    soi, pas un detail d'implementation a passer sous silence.
